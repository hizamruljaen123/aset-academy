-- Generated Random Data for Academy Lite
-- Generated on: 2025-09-16 17:36:28
SET FOREIGN_KEY_CHECKS = 0;
INSERT INTO `users` (`id`, `username`, `password`, `nama_lengkap`, `email`, `role`, `level`, `department`, `status`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 'bajraginhidayat1', '7c6a180b36896a0a8c02787eeafb0e4c', 'Usyi Pertiwi', 'iswahyudicengkir@example.com', 'siswa', '4', 'CV Hartati Marpaung', 'Aktif', '2025-03-27 18:24:06', '2025-04-23 11:03:54', '2025-02-08 19:59:18'),
(2, 'novitasariazalea2', '6cb75f652a9b52798eb6cf2201057c73', 'Ilsa Lestari', 'lulut48@example.net', 'user', '5', 'CV Prakasa Hutagalung (Persero) Tbk', 'Tidak Aktif', '2025-01-19 13:36:45', '2025-01-14 03:49:40', '2025-04-27 18:26:15'),
(3, 'setiawancapa3', '819b0643d6b89dc9b579fdfc9094f28e', 'dr. Genta Hidayanto', 'luwesirawan@example.com', 'admin', '2', NULL, 'Aktif', '2025-04-06 09:15:58', '2025-01-21 12:26:33', '2025-03-29 05:39:18'),
(4, 'widodoharimurti4', '34cc93ece0ba9e3f6f235d4af979b16c', 'Fitriani Wijayanti', 'adriansyahzalindra@example.org', 'super_admin', '1', 'PT Rahmawati Tbk', 'Aktif', NULL, '2025-02-08 09:10:27', '2025-05-11 11:03:09'),
(5, 'niyagausamah5', 'db0edd04aaac4506f7edab03ac855d56', 'R. Paris Oktaviani, S.Pd', 'ssantoso@example.com', 'siswa', '4', NULL, 'Tidak Aktif', '2025-04-22 08:21:17', '2025-08-21 14:19:26', '2025-04-11 10:58:45'),
(6, 'spradipta6', '218dd27aebeccecae69ad8408d9a36bf', 'Dr. Tina Suwarno', 'banara40@example.org', 'user', '5', NULL, 'Tidak Aktif', NULL, '2025-09-11 05:22:19', '2025-01-24 23:48:41'),
(7, 'mahendrabagas7', '00cdb7bb942cf6b290ceb97d6aca64a3', 'Narji Dongoran, M.TI.', 'fmandasari@example.net', 'admin', '2', NULL, 'Aktif', '2025-02-05 12:53:22', '2025-07-23 10:54:56', '2025-04-01 19:30:35'),
(8, 'imam548', 'b25ef06be3b6948c0bc431da46c2c738', 'R. Diah Lailasari', 'carubprasetyo@example.org', 'admin', '2', NULL, 'Tidak Aktif', '2025-08-25 17:56:06', '2025-07-16 19:56:27', '2025-09-11 10:50:00'),
(9, 'hwidiastuti9', '5d69dd95ac183c9643780ed7027d128a', 'Daliman Sinaga', 'aslijanmaryadi@example.org', 'user', '5', 'UD Pangestu Budiyanto Tbk', 'Tidak Aktif', NULL, '2025-09-05 06:02:17', '2025-09-05 22:38:44'),
(10, 'zulaikhapermadi10', '87e897e3b54a405da144968b2ca19b45', 'Dr. Paramita Rajasa, S.IP', 'unjaniprasetyo@example.com', 'guru', '3', NULL, 'Tidak Aktif', '2025-03-10 18:09:20', '2025-02-17 23:51:06', '2025-06-15 13:21:27'),
(11, 'karsa0811', '1e5c2776cf544e213c3d279c40719643', 'Rini Thamrin', 'usyi34@example.com', 'admin', '2', 'CV Wasita Wibisono', 'Tidak Aktif', '2025-08-14 00:10:59', '2025-08-16 12:24:50', '2025-08-31 14:21:03'),
(12, 'xwinarno12', 'c24a542f884e144451f9063b79e7994e', 'Kawaya Ardianto', 'devi85@example.com', 'user', '5', 'CV Prasetya (Persero) Tbk', 'Tidak Aktif', NULL, '2025-06-02 08:40:09', '2025-05-07 21:57:22'),
(13, 'hasanhidayat13', 'ee684912c7e588d03ccb40f17ed080c9', 'Cornelia Simanjuntak', 'rnashiruddin@example.net', 'user', '5', NULL, 'Tidak Aktif', '2025-06-10 07:07:53', '2025-01-27 12:20:45', '2025-03-02 03:17:02'),
(14, 'vicky6714', '8ee736784ce419bd16554ed5677ff35b', 'R. Radika Saputra', 'safitritaufan@example.net', 'siswa', '4', 'UD Mangunsong Hutapea (Persero) Tbk', 'Tidak Aktif', NULL, '2025-06-30 16:50:08', '2025-06-26 04:50:03'),
(15, 'yuliawacana15', '9141fea0574f83e190ab7479d516630d', 'Padma Gunawan', 'suwarnobalijan@example.net', 'user', '5', NULL, 'Tidak Aktif', '2025-04-07 09:09:47', '2025-02-17 00:20:00', '2025-02-09 02:59:42'),
(16, 'hmaulana16', '2b40aaa979727c43411c305540bbed50', 'Dt. Umay Lazuardi', 'baktiadipermadi@example.net', 'user', '5', 'UD Sihotang (Persero) Tbk', 'Tidak Aktif', '2025-03-21 22:05:58', '2025-07-14 23:52:02', '2025-05-12 19:04:46'),
(17, 'kenziewaluyo17', 'a63f9709abc75bf8bd8f6e1ba9992573', 'Caraka Narpati', 'dwijaya@example.org', 'super_admin', '1', NULL, 'Tidak Aktif', '2025-03-04 13:53:52', '2025-08-14 23:17:01', '2025-07-01 18:04:26'),
(18, 'ywulandari18', '80b8bdceb474b5127b6aca386bb8ce14', 'H. Tomi Suartini', 'vrajasa@example.org', 'user', '5', 'Perum Suryono (Persero) Tbk', 'Aktif', '2025-04-18 17:47:16', '2025-04-08 02:43:51', '2025-08-19 15:05:20'),
(19, 'qsitompul19', 'e532ae6f28f4c2be70b500d3d34724eb', 'Yance Pradana', 'ikhsanfirgantoro@example.org', 'super_admin', '1', 'UD Wacana Tbk', 'Aktif', '2025-01-23 14:09:48', '2025-04-03 19:04:37', '2025-07-05 05:13:02'),
(20, 'puspaanggraini20', 'aee67d9bb569ad1562f7b67cfccbd2ef', 'Adika Hasanah', 'legalestari@example.com', 'admin', '2', 'Perum Pranowo Rajata', 'Aktif', '2025-03-17 05:34:03', '2025-06-01 13:53:31', '2025-07-24 13:01:30'),
(21, 'jaeman4121', '568c31f0f2406ab70255a1d83291220f', 'Faizah Fujiati', 'najwa22@example.net', 'admin', '2', NULL, 'Tidak Aktif', '2025-07-24 05:48:47', '2025-05-31 18:03:10', '2025-05-21 11:20:33'),
(22, 'wahyudinkarsa22', '069103d83d40b742a336dee5fb92f4e5', 'Damar Pratama', 'isuwarno@example.com', 'user', '5', NULL, 'Tidak Aktif', '2025-01-16 15:13:18', '2025-05-14 13:33:39', '2025-03-04 15:32:37'),
(23, 'jayadi0823', '1f82cdf9195b31244721c6026587fb78', 'H. Cager Andriani', 'jaeman06@example.com', 'admin', '2', NULL, 'Tidak Aktif', '2025-06-22 05:30:18', '2025-08-11 05:15:28', '2025-06-16 03:56:46'),
(24, 'pudjiastutibaktianto24', '58bad6b697dff48f4927941962f23e90', 'Oni Haryanti, S.IP', 'qthamrin@example.com', 'super_admin', '1', NULL, 'Tidak Aktif', '2025-01-03 15:03:26', '2025-09-15 23:28:17', '2025-09-07 12:09:05'),
(25, 'zmelani25', '6982e82c0b21af5526754d83df2d1635', 'drg. Siti Saragih', 'susantiayu@example.net', 'siswa', '4', 'Perum Suwarno', 'Aktif', NULL, '2025-06-21 16:10:10', '2025-04-09 16:14:06'),
(26, 'usyimarpaung26', 'dc2d937cba912f093445d008f0461c83', 'Wani Saputra', 'nasyiahsetya@example.net', 'super_admin', '1', NULL, 'Tidak Aktif', NULL, '2025-09-13 08:52:11', '2025-07-18 04:17:49'),
(27, 'budiyantounjani27', 'ccf08fd9a560b266470bf8ab97fc7c26', 'Qori Nainggolan', 'belindasetiawan@example.com', 'super_admin', '1', NULL, 'Aktif', '2025-05-29 12:25:20', '2025-04-21 17:23:28', '2025-07-02 04:58:20'),
(28, 'ivan3328', '3b635d4df2c9ece93b97759531d6ed01', 'Dian Winarsih', 'nasyiahdarmana@example.net', 'admin', '2', NULL, 'Aktif', NULL, '2025-05-22 05:17:13', '2025-04-08 13:54:18'),
(29, 'nainggolandina29', '926742e502de7d22686bb1d4a07fe635', 'Labuh Aryani', 'darmanlailasari@example.net', 'siswa', '4', 'PD Budiman Napitupulu (Persero) Tbk', 'Aktif', '2025-03-09 14:37:00', '2025-01-29 13:50:39', '2025-01-20 14:23:53'),
(30, 'eardianto30', '3dc94727dbba08bdd21d7b318b410600', 'Asmianto Winarno', 'gadingpratama@example.org', 'siswa', '4', NULL, 'Aktif', NULL, '2025-05-29 00:20:56', '2025-07-13 13:19:04'),
(31, 'safina4331', '0c75f443030c092d82b67ef876fa4e4e', 'Ganep Maheswara', 'uprakasa@example.com', 'siswa', '4', 'PD Fujiati', 'Tidak Aktif', '2025-03-19 13:21:12', '2025-01-02 15:44:16', '2025-07-26 13:21:45'),
(32, 'tugiman9832', 'f849618fac31084ff0bafe6f877562e3', 'KH. Ismail Oktaviani, M.Farm', 'verahalimah@example.net', 'admin', '2', NULL, 'Tidak Aktif', '2025-06-28 20:18:00', '2025-04-10 22:46:45', '2025-01-28 11:02:16'),
(33, 'dasa3233', 'd61af90de34e181dcb619fdc9c9f817d', 'Drs. Najwa Mayasari, S.E.I', 'czulaika@example.com', 'siswa', '4', NULL, 'Tidak Aktif', '2025-09-11 00:58:05', '2025-07-19 21:44:18', '2025-04-18 10:13:59'),
(34, 'rsimbolon34', '7aa4106f8d30c77db0517e813ace4a3b', 'Violet Mahendra', 'prayoga52@example.com', 'guru', '3', NULL, 'Tidak Aktif', '2025-03-12 18:03:09', '2025-06-15 21:35:32', '2025-09-01 07:27:07'),
(35, 'juliasitumorang35', '48ad74b74844fadd28274afd5c617ccf', 'Ellis Wulandari', 'kuwais@example.net', 'super_admin', '1', NULL, 'Aktif', '2025-03-06 19:55:26', '2025-01-30 04:47:31', '2025-06-17 19:49:32'),
(36, 'ratih5336', '8ba4260f47598cece4813a294952f7f3', 'Tugiman Adriansyah', 'ina01@example.net', 'admin', '2', 'PT Anggraini (Persero) Tbk', 'Aktif', '2025-02-21 01:33:46', '2025-05-22 19:20:44', '2025-03-01 15:00:29'),
(37, 'dasasihombing37', '9ab4b766ba920fca672112a4d81464df', 'Damar Hastuti', 'gadangpradipta@example.org', 'admin', '2', 'PT Wibowo Hutagalung', 'Aktif', '2025-03-10 03:15:46', '2025-03-27 15:42:38', '2025-01-01 06:36:06'),
(38, 'vino8638', 'b30628ea30edfe26e7650e7bd89cc8a1', 'Sadina Usada', 'ynurdiyanti@example.net', 'siswa', '4', NULL, 'Tidak Aktif', '2025-07-19 10:56:30', '2025-09-04 23:51:15', '2025-05-02 08:54:10'),
(39, 'prahimah39', 'be961c906e3b375dced446d4cf0b6856', 'Ayu Kusumo', 'karmahalim@example.com', 'guru', '3', 'PT Firgantoro Uyainah', 'Tidak Aktif', '2025-02-28 07:41:31', '2025-06-02 18:07:33', '2025-02-14 11:05:58'),
(40, 'wulanwastuti40', '831fc3acf61a6ac7f44f73287ece2942', 'Mila Lestari', 'kusumadabukke@example.org', 'super_admin', '1', 'PD Samosir', 'Tidak Aktif', '2025-03-13 21:18:28', '2025-04-02 23:01:08', '2025-06-10 02:03:53'),
(41, 'fitriani7741', 'decb7cb773821f0e6486650c6f062be5', 'Pia Haryanti', 'cakrajiyautami@example.net', 'admin', '2', 'Perum Rahimah', 'Tidak Aktif', '2025-06-12 13:10:32', '2025-06-08 22:44:00', '2025-07-29 23:52:58'),
(42, 'kamaria9442', 'b1a6a20d781fde908b1dd9af34deb8ea', 'Nurul Habibi', 'cakrajiya07@example.org', 'guru', '3', NULL, 'Aktif', NULL, '2025-05-07 23:09:55', '2025-06-02 02:56:59'),
(43, 'prakasabakidin43', 'a5669b4e80cfb179cdd36be6eeada2cd', 'Bakda Sudiati', 'yaninamaga@example.com', 'user', '5', NULL, 'Tidak Aktif', '2025-01-10 17:25:49', '2025-05-12 00:33:03', '2025-04-08 11:27:23'),
(44, 'ahalim44', '9608e3da7f00ffa26507d1aa9a575197', 'Vanya Puspita, S.Psi', 'gsuryatmi@example.com', 'super_admin', '1', 'UD Sitompul', 'Aktif', '2025-01-09 11:51:51', '2025-04-12 06:24:05', '2025-08-30 02:43:48'),
(45, 'pertiwimakuta45', '0009fa95022c5c2c1276227121652c60', 'Cici Halimah', 'mmegantara@example.net', 'user', '5', NULL, 'Tidak Aktif', '2025-02-20 02:12:33', '2025-01-09 03:52:43', '2025-04-15 04:38:20'),
(46, 'qsiregar46', '6ea84fafdeb8b3857abe9410c7144ccb', 'Karimah Sudiati', 'fnamaga@example.com', 'super_admin', '1', NULL, 'Tidak Aktif', '2025-01-12 09:12:45', '2025-05-07 20:37:47', '2025-07-24 15:35:57'),
(47, 'mansurcemani47', 'ea716d443f74ecc54957c884c0d05612', 'Melinda Wulandari', 'widya09@example.net', 'super_admin', '1', NULL, 'Tidak Aktif', NULL, '2025-03-11 01:06:56', '2025-01-13 20:01:02'),
(48, 'kuncara2348', '458c7a67e7b9126ae7a9df4b821ea745', 'Cindy Mayasari', 'bwasita@example.org', 'admin', '2', NULL, 'Aktif', '2025-04-11 08:29:28', '2025-04-17 13:15:51', '2025-07-30 21:10:21'),
(49, 'mitra8549', '0659a802af127843be2e35e0e36c310a', 'Iriana Rahayu', 'enashiruddin@example.net', 'siswa', '4', NULL, 'Tidak Aktif', '2025-03-16 11:04:12', '2025-07-21 11:38:59', '2025-08-18 15:45:46'),
(50, 'gutama50', 'ed645bbf72d0c71176142d93c99942c2', 'Manah Palastri', 'lidyarajata@example.com', 'admin', '2', NULL, 'Tidak Aktif', '2025-06-08 15:33:57', '2025-04-14 15:51:02', '2025-08-13 01:38:03');

INSERT INTO `siswa` (`id`, `nis`, `nama_lengkap`, `email`, `no_telepon`, `kelas`, `jurusan`, `alamat`, `foto_profil`, `tanggal_lahir`, `jenis_kelamin`, `status`, `created_at`, `updated_at`) VALUES
(1, '807303', 'Dalima Gunawan', 'kania62@example.com', '+62 (734) 449-4958', 'XII Teknik Informatika', 'Manajemen Informatika', 'Jalan R.E Martadinata No. 3
Tangerang, RI 96660', '/uploads/profiles/student_1.jpg', '2007-10-18', 'P', 'Aktif', '2025-07-12 01:25:40', '2025-07-22 20:40:07'),
(2, '386021', 'Nilam Rajasa', 'balapati87@example.net', '0838546636', 'X Manajemen Informatika', 'Teknik Informatika', 'Gang HOS. Cokroaminoto No. 3
Kendari, SR 06354', '/uploads/profiles/student_2.jpg', '2002-03-02', 'L', 'Tidak Aktif', '2025-01-28 09:23:17', '2025-05-30 08:44:07'),
(3, '274965', 'Jamal Saefullah', 'kfirgantoro@example.net', '+62-066-269-0876', 'XI Sistem Informasi', 'Teknik Informatika', 'Gang Rajiman No. 960
Depok, JB 94520', '/uploads/profiles/student_3.jpg', '2002-12-20', 'L', 'Tidak Aktif', '2025-09-03 16:55:38', '2025-08-06 05:10:53'),
(4, '528876', 'Oskar Hartati', 'oktavianimargana@example.org', '+62-0467-083-6274', 'XI Teknik Komputer', 'Teknik Informatika', 'Gg. Merdeka No. 659
Subulussalam, RI 78946', NULL, '2003-05-01', 'L', 'Tidak Aktif', '2025-08-20 03:25:13', '2025-03-20 09:52:10'),
(5, '892023', 'Jasmin Hutapea, S.E.', 'kemalusada@example.org', '+62 (165) 513 4613', 'XII Sistem Informasi', 'Sistem Informasi', 'Gg. Cihampelas No. 20
Tangerang, Bengkulu 89756', '/uploads/profiles/student_5.jpg', '2007-06-28', 'P', 'Lulus', '2025-03-09 13:58:36', '2025-05-12 10:39:32'),
(6, '948318', 'Karna Setiawan', 'bahuwarnamandasari@example.net', '+62 (084) 041-4001', 'XI Sistem Informasi', 'Sistem Informasi', 'Gg. Moch. Ramdan No. 18
Sukabumi, PA 11725', '/uploads/profiles/student_6.jpg', '2002-01-11', 'L', 'Tidak Aktif', '2025-09-05 01:47:55', '2025-03-02 06:18:54'),
(7, '399100', 'Galak Latupono', 'malika96@example.net', '+62 (010) 724-3558', 'XI Teknik Informatika', 'Sistem Informasi', 'Gg. Jamika No. 46
Lubuklinggau, Sumatera Selatan 12901', '/uploads/profiles/student_7.jpg', '2004-08-09', 'L', 'Tidak Aktif', '2025-04-30 01:27:18', '2025-02-23 03:05:51'),
(8, '955695', 'Ir. Marsito Maheswara', 'yprasetyo@example.net', '088 837 0029', 'XI Manajemen Informatika', 'Sistem Informasi', 'Jalan Waringin No. 5
Jambi, JK 71245', '/uploads/profiles/student_8.jpg', '2000-10-16', 'P', 'Tidak Aktif', '2025-03-15 02:46:48', '2025-03-13 22:34:59'),
(9, '481870', 'Nova Laksita', 'usman74@example.net', '+62 (078) 675 7734', 'XII Teknik Komputer', 'Teknik Komputer', 'Gang S. Parman No. 759
Pagaralam, Sumatera Selatan 07758', '/uploads/profiles/student_9.jpg', '2003-12-01', 'P', 'Aktif', '2025-06-12 22:40:35', '2025-08-22 18:20:43'),
(10, '951306', 'Emin Pranowo', 'agustinachandra@example.com', '+62 (084) 006 3612', 'XII Teknik Informatika', 'Teknik Komputer', 'Jalan Tebet Barat Dalam No. 696
Surabaya, Aceh 90311', '/uploads/profiles/student_10.jpg', '2005-08-20', 'P', 'Lulus', '2025-02-20 04:16:02', '2025-05-09 23:29:37'),
(11, '811326', 'Puti Wulan Winarno', 'oskar59@example.com', '(0971) 265 1429', 'XII Teknik Informatika', 'Sistem Informasi', 'Gg. Raya Ujungberung No. 241
Bogor, Sulawesi Selatan 46846', NULL, '2005-09-18', 'L', 'Lulus', '2025-04-10 21:21:21', '2025-01-16 23:25:57'),
(12, '480659', 'Nadia Anggriawan', 'lalita08@example.com', '+62 (0110) 574 8175', 'X Teknik Informatika', 'Manajemen Informatika', 'Jl. Jamika No. 22
Tomohon, BA 30775', NULL, '2004-10-23', 'P', 'Lulus', '2025-03-26 10:49:36', '2025-06-19 16:45:34'),
(13, '771371', 'Wisnu Prabowo', 'luthfifirgantoro@example.net', '(0955) 731-5546', 'XII Manajemen Informatika', 'Teknik Informatika', 'Gg. Stasiun Wonokromo No. 864
Cilegon, BE 23994', NULL, '1999-10-11', 'P', 'Lulus', '2025-01-03 17:48:12', '2025-01-04 17:43:03'),
(14, '309614', 'Nrima Firgantoro, S.E.', 'damanikcemeti@example.net', '(043) 459 2712', 'XII Manajemen Informatika', 'Teknik Informatika', 'Gg. Merdeka No. 64
Makassar, DI Yogyakarta 79371', NULL, '2004-02-18', 'P', 'Aktif', '2025-04-24 18:43:29', '2025-06-19 07:43:38'),
(15, '120283', 'Siti Anggriawan, S.E.', 'putrataufik@example.org', '+62 (0706) 798 5654', 'XI Manajemen Informatika', 'Sistem Informasi', 'Gang Dr. Djunjunan No. 291
Bengkulu, Kepulauan Riau 31344', '/uploads/profiles/student_15.jpg', '2009-11-11', 'L', 'Lulus', '2025-02-26 20:42:18', '2025-05-29 13:20:29'),
(16, '744308', 'Cut Rika Wibisono', 'briyanti@example.org', '+62 (06) 749-9593', 'XII Teknik Informatika', 'Teknik Informatika', 'Jl. M.T Haryono No. 5
Palangkaraya, Sulawesi Tengah 54987', NULL, '2002-08-08', 'L', 'Tidak Aktif', '2025-07-27 12:20:24', '2025-06-22 00:18:56'),
(17, '728491', 'drg. Cagak Andriani', 'phakim@example.org', '(096) 126-4550', 'XII Sistem Informasi', 'Manajemen Informatika', 'Jl. Moch. Ramdan No. 01
Payakumbuh, Aceh 71290', NULL, '2010-05-03', 'P', 'Aktif', '2025-02-20 13:42:31', '2025-04-05 14:47:20'),
(18, '788766', 'Darmanto Farida, S.Pd', 'luwar25@example.net', '+62 (087) 866-8535', 'XI Manajemen Informatika', 'Teknik Informatika', 'Jalan Rumah Sakit No. 7
Manado, KB 35188', '/uploads/profiles/student_18.jpg', '2001-02-11', 'P', 'Tidak Aktif', '2025-03-09 12:28:03', '2025-08-21 02:40:13'),
(19, '948317', 'Prakosa Kurniawan', 'opanwasita@example.net', '+62 (583) 402-4786', 'XI Sistem Informasi', 'Teknik Komputer', 'Jalan Ahmad Yani No. 572
Banjar, Riau 37444', '/uploads/profiles/student_19.jpg', '2001-12-11', 'L', 'Tidak Aktif', '2025-04-03 13:20:27', '2025-04-16 05:05:28'),
(20, '561615', 'Clara Wibowo', 'tutama@example.net', '(030) 501 5142', 'X Teknik Komputer', 'Teknik Komputer', 'Jl. Tebet Barat Dalam No. 85
Sibolga, Jawa Barat 42782', '/uploads/profiles/student_20.jpg', '2008-10-15', 'P', 'Aktif', '2025-04-06 12:05:48', '2025-03-28 02:25:05'),
(21, '298721', 'Dt. Jono Astuti', 'anggrainirestu@example.net', '(0339) 250 1256', 'XI Sistem Informasi', 'Teknik Komputer', 'Gang Pacuan Kuda No. 525
Batu, Bengkulu 97397', '/uploads/profiles/student_21.jpg', '2000-02-02', 'P', 'Tidak Aktif', '2025-09-11 05:25:36', '2025-04-02 02:30:43'),
(22, '457602', 'Oni Prasetyo, M.M.', 'lnatsir@example.net', '+62-058-967-7660', 'XII Sistem Informasi', 'Teknik Komputer', 'Gang Pasir Koja No. 28
Sawahlunto, Sulawesi Tenggara 88743', NULL, '2007-10-07', 'P', 'Aktif', '2025-08-16 14:05:57', '2025-05-24 14:33:47'),
(23, '176803', 'KH. Kenes Agustina', 'ssantoso@example.org', '+62 (040) 227 9332', 'XII Teknik Komputer', 'Teknik Komputer', 'Gg. Waringin No. 331
Tebingtinggi, Jawa Tengah 43982', '/uploads/profiles/student_23.jpg', '2008-09-26', 'L', 'Aktif', '2025-05-29 04:40:08', '2025-06-27 02:56:02'),
(24, '145271', 'dr. Michelle Hidayat', 'ellisfirmansyah@example.net', '+62 (470) 202-5573', 'X Teknik Komputer', 'Sistem Informasi', 'Gg. Peta No. 85
Bogor, Papua Barat 12851', NULL, '2006-06-04', 'L', 'Aktif', '2025-02-16 14:19:17', '2025-02-28 01:07:45'),
(25, '440320', 'Asman Kuswoyo, S.IP', 'qsirait@example.com', '0823345780', 'X Teknik Komputer', 'Teknik Komputer', 'Jalan Ronggowarsito No. 36
Makassar, Jambi 39062', NULL, '2007-01-12', 'P', 'Aktif', '2025-08-31 00:16:28', '2025-04-26 18:49:42'),
(26, '358144', 'R. Farah Kusumo', 'ulailasari@example.net', '085 152 2134', 'XII Manajemen Informatika', 'Manajemen Informatika', 'Jalan Joyoboyo No. 242
Metro, Aceh 54647', NULL, '2000-02-03', 'P', 'Aktif', '2025-08-02 16:28:31', '2025-01-17 22:14:51'),
(27, '148546', 'T. Danu Maryati, S.T.', 'atmajaiswahyudi@example.com', '(072) 375 8191', 'XI Manajemen Informatika', 'Teknik Informatika', 'Gg. Tubagus Ismail No. 61
Batam, Gorontalo 49249', '/uploads/profiles/student_27.jpg', '2002-08-25', 'L', 'Aktif', '2025-07-10 08:21:40', '2025-09-05 06:13:21'),
(28, '334349', 'Puti Ayu Usada, S.I.Kom', 'balamantri48@example.org', '0804040752', 'XII Teknik Informatika', 'Teknik Komputer', 'Jalan Cikutra Timur No. 6
Cimahi, DKI Jakarta 59721', NULL, '2006-06-25', 'P', 'Lulus', '2025-01-21 18:56:40', '2025-01-12 11:32:51'),
(29, '977589', 'Ade Hakim', 'malapadmasari@example.net', '+62-042-405-3777', 'X Teknik Komputer', 'Sistem Informasi', 'Gang Moch. Toha No. 03
Payakumbuh, Bengkulu 59020', '/uploads/profiles/student_29.jpg', '1999-11-18', 'L', 'Aktif', '2025-02-08 13:31:14', '2025-03-03 05:13:40'),
(30, '522171', 'Hartana Pradana', 'mutia94@example.org', '(008) 232 4636', 'XII Manajemen Informatika', 'Sistem Informasi', 'Gg. Medokan Ayu No. 346
Singkawang, MA 28075', NULL, '2008-04-01', 'L', 'Lulus', '2025-01-20 12:25:29', '2025-04-21 08:41:42');

INSERT INTO `kelas_programming` (`id`, `nama_kelas`, `deskripsi`, `level`, `bahasa_program`, `durasi`, `harga`, `gambar`, `status`, `online_meet_link`, `created_at`, `updated_at`) VALUES
(1, 'Kelas C# Dasar', 'Distinctio nisi dicta minus neque. Placeat dolore eaque a. Necessitatibus deleniti consectetur officia hic sit.', 'Menengah', 'C#', 80, 4622709.51, NULL, 'Aktif', NULL, '2025-05-04 22:22:03', '2025-07-30 02:05:10'),
(2, 'Kelas JavaScript Lanjutan', 'Harum nobis porro dolor.', 'Dasar', 'C++', 80, 849112.21, '/uploads/classes/class_2.jpg', 'Tidak Aktif', NULL, '2025-01-06 22:56:08', '2025-07-02 13:50:55'),
(3, 'Kelas PHP Lanjutan', 'Explicabo quam alias delectus quidem. Assumenda asperiores voluptate veniam. Inventore quaerat sapiente explicabo ea nostrum nesciunt.', 'Lanjutan', 'C++', 71, 3963810.85, NULL, 'Aktif', NULL, '2025-09-03 23:44:40', '2025-06-12 23:34:18'),
(4, 'Kelas C# Lanjutan', 'Cupiditate suscipit natus natus possimus tempore. Praesentium perspiciatis laborum dolorem.', 'Menengah', 'Python', 30, 1378927.04, NULL, 'Tidak Aktif', NULL, '2025-02-08 13:10:04', '2025-05-16 12:01:31'),
(5, 'Kelas JavaScript Menengah', 'Ea quia doloribus odio voluptatem occaecati. Natus explicabo velit ipsam nulla sunt. Ipsum optio quod dolor non ipsa.', 'Lanjutan', 'Ruby', 53, 2314970.36, NULL, 'Tidak Aktif', NULL, '2025-04-05 20:20:34', '2025-08-10 06:34:21'),
(6, 'Kelas Go Dasar', 'Atque sapiente excepturi maiores voluptatum magnam nihil. Minus pariatur quos. Voluptatum labore labore et illo delectus quas. Iure ipsam sequi accusantium molestiae.', 'Menengah', 'Ruby', 61, 2072852.66, '/uploads/classes/class_6.jpg', 'Tidak Aktif', NULL, '2025-06-23 07:34:05', '2025-02-25 02:13:21'),
(7, 'Kelas Python Lanjutan', 'Sint voluptate repellendus illo. Inventore numquam amet rerum. Inventore omnis sapiente vitae ducimus veniam.', 'Lanjutan', 'C#', 89, 4054427.2, '/uploads/classes/class_7.jpg', 'Aktif', NULL, '2025-04-10 16:01:36', '2025-02-28 15:45:50'),
(9, 'Kelas Go Menengah', 'Occaecati culpa magnam possimus nisi repellat aliquam nihil. Autem labore voluptatibus fugit.', 'Menengah', 'JavaScript', 87, 2353255.44, '/uploads/classes/class_9.jpg', 'Aktif', NULL, '2025-05-27 23:04:15', '2025-06-21 13:13:14'),
(10, 'Kelas PHP Menengah', 'Impedit tempora explicabo adipisci iste. Deleniti omnis velit.', 'Dasar', 'PHP', 80, 4465725.08, '/uploads/classes/class_10.jpg', 'Tidak Aktif', NULL, '2025-04-23 05:19:14', '2025-01-01 16:48:24');

INSERT INTO `jadwal_kelas` (`id`, `kelas_id`, `pertemuan_ke`, `class_type`, `guru_id`, `judul_pertemuan`, `tanggal_pertemuan`, `waktu_mulai`, `waktu_selesai`, `created_at`, `updated_at`) VALUES
(1, 1, 6, 'premium', NULL, 'In non optio quo velit nisi.', '2025-08-13', '1900-01-01', '1900-01-01', '2025-02-16 16:16:04', '2025-04-14 16:08:53'),
(2, 10, 14, 'gratis', 34, 'Ex occaecati eveniet occaecati.', '2025-08-24', '1900-01-01', '1900-01-01', '2025-01-19 12:44:41', '2025-07-21 12:39:25'),
(3, 7, 13, NULL, 10, 'Assumenda tempora deleniti recusandae nihil eaque ex.', '2025-03-02', '1900-01-01', '1900-01-01', '2025-04-02 21:51:19', '2025-08-09 03:13:00'),
(4, 6, 3, 'premium', NULL, 'Molestiae velit vel possimus deserunt sequi ut.', '2025-03-26', '1900-01-01', '1900-01-01', '2025-05-13 01:38:31', '2025-09-11 19:01:16'),
(5, 7, 18, 'gratis', NULL, 'Laborum deserunt eum laudantium quasi.', '2025-05-19', '1900-01-01', '1900-01-01', '2025-03-26 16:56:59', '2025-05-02 15:59:30'),
(6, 10, 3, 'gratis', NULL, 'Quis aut soluta placeat.', '2025-08-24', '1900-01-01', '1900-01-01', '2025-02-09 06:55:37', '2025-08-04 17:54:34'),
(7, 10, 10, NULL, NULL, 'Iusto dicta veritatis beatae impedit.', '2025-08-09', '1900-01-01', '1900-01-01', '2025-07-10 09:42:56', '2025-01-11 08:31:30'),
(8, 9, 2, NULL, NULL, 'Quam consequatur rem corporis cumque.', '2025-05-27', '1900-01-01', '1900-01-01', '2025-03-21 17:58:26', '2025-09-15 17:30:17'),
(9, 4, 4, NULL, NULL, 'Non necessitatibus dignissimos sunt.', '2025-06-16', '1900-01-01', '1900-01-01', '2025-03-25 19:46:07', '2025-04-21 23:00:19'),
(10, 8, 4, NULL, NULL, 'Ipsa perferendis rerum quo.', '2025-07-09', '1900-01-01', '1900-01-01', '2025-04-20 03:16:47', '2025-01-10 12:44:20'),
(11, 4, 15, NULL, 42, 'Occaecati consectetur quae cumque quo.', '2025-06-07', '1900-01-01', '1900-01-01', '2025-03-20 14:02:31', '2025-03-27 18:48:25'),
(12, 5, 7, 'gratis', NULL, 'Occaecati necessitatibus minima eaque iste culpa hic.', '2025-05-20', '1900-01-01', '1900-01-01', '2025-06-07 10:30:31', '2025-05-06 23:00:17'),
(13, 6, 20, 'gratis', NULL, 'Sequi temporibus vitae culpa illum sequi reprehenderit distinctio.', '2025-01-03', '1900-01-01', '1900-01-01', '2025-06-29 05:03:15', '2025-04-29 00:32:28'),
(14, 1, 10, NULL, NULL, 'Non ipsum a fugiat perferendis enim minus.', '2025-04-08', '1900-01-01', '1900-01-01', '2025-01-13 06:30:20', '2025-01-19 02:41:57'),
(15, 9, 7, NULL, 42, 'Distinctio eveniet id animi possimus voluptatum dolorem.', '2025-03-29', '1900-01-01', '1900-01-01', '2025-04-05 13:15:02', '2025-02-23 10:08:22'),
(16, 9, 1, 'gratis', NULL, 'Assumenda neque corporis unde.', '2025-02-14', '1900-01-01', '1900-01-01', '2025-07-30 13:43:01', '2025-04-24 19:59:32'),
(17, 2, 10, 'gratis', NULL, 'Deserunt consectetur consequatur dicta accusamus quia.', '2025-08-03', '1900-01-01', '1900-01-01', '2025-01-16 13:39:37', '2025-02-10 21:24:17'),
(18, 7, 14, 'gratis', 39, 'Nulla ipsum saepe rem veniam magni.', '2025-06-22', '1900-01-01', '1900-01-01', '2025-04-14 23:39:07', '2025-02-24 21:32:41'),
(19, 5, 11, NULL, NULL, 'Deserunt iusto distinctio dolorum.', '2025-09-04', '1900-01-01', '1900-01-01', '2025-06-11 21:43:08', '2025-08-29 04:22:05'),
(20, 9, 14, NULL, NULL, 'Cum quae illo aperiam odit aliquid.', '2025-04-16', '1900-01-01', '1900-01-01', '2025-02-05 11:37:58', '2025-05-18 21:50:59'),
(21, 8, 6, 'premium', 42, 'Dicta autem nisi pariatur.', '2025-07-04', '1900-01-01', '1900-01-01', '2025-07-23 16:25:35', '2025-01-26 13:18:54'),
(22, 10, 2, 'gratis', NULL, 'Nulla illo excepturi enim harum quas similique.', '2025-06-15', '1900-01-01', '1900-01-01', '2025-01-21 02:28:20', '2025-09-08 13:57:42'),
(23, 7, 7, 'premium', NULL, 'Eum inventore ea deleniti aspernatur iure.', '2025-03-14', '1900-01-01', '1900-01-01', '2025-06-23 17:06:53', '2025-01-26 19:47:49'),
(24, 1, 4, 'gratis', 34, 'Veniam sequi natus quae atque.', '2025-05-12', '1900-01-01', '1900-01-01', '2025-06-07 07:26:50', '2025-04-25 01:07:01'),
(25, 9, 18, 'gratis', 34, 'Eveniet libero labore vero porro optio quam sequi.', '2025-05-27', '1900-01-01', '1900-01-01', '2025-05-25 07:20:51', '2025-07-06 01:14:23'),
(26, 10, 15, 'premium', NULL, 'Voluptate illo voluptatibus sunt id illo.', '2025-05-03', '1900-01-01', '1900-01-01', '2025-07-29 06:25:23', '2025-06-30 22:16:16'),
(27, 3, 4, 'gratis', 34, 'Perferendis dolores ratione eius in.', '2025-03-24', '1900-01-01', '1900-01-01', '2025-07-01 06:57:03', '2025-03-11 18:18:32'),
(28, 7, 7, NULL, NULL, 'Laborum voluptate ut cum.', '2025-05-11', '1900-01-01', '1900-01-01', '2025-06-13 03:07:28', '2025-04-13 20:34:08'),
(29, 3, 15, 'gratis', NULL, 'Asperiores nesciunt tenetur quis voluptatum blanditiis dolorem.', '2025-08-27', '1900-01-01', '1900-01-01', '2025-09-05 17:44:54', '2025-08-02 13:37:23'),
(30, 10, 10, 'premium', NULL, 'Repellendus perferendis occaecati labore debitis facere.', '2025-03-18', '1900-01-01', '1900-01-01', '2025-06-01 13:10:50', '2025-05-07 01:33:25'),
(31, 5, 11, NULL, NULL, 'Commodi amet nam itaque aliquam ut quae.', '2025-05-20', '1900-01-01', '1900-01-01', '2025-05-24 02:50:20', '2025-02-15 10:40:54'),
(32, 5, 7, NULL, NULL, 'Quo placeat delectus quam.', '2025-05-31', '1900-01-01', '1900-01-01', '2025-03-20 21:26:21', '2025-09-01 08:29:50'),
(33, 1, 17, 'premium', NULL, 'Corporis nisi laborum doloremque explicabo fuga.', '2025-01-18', '1900-01-01', '1900-01-01', '2025-08-21 06:57:18', '2025-01-04 13:14:06'),
(34, 5, 3, 'premium', NULL, 'Asperiores in aliquid adipisci nobis alias ab.', '2025-09-05', '1900-01-01', '1900-01-01', '2025-08-20 13:49:27', '2025-02-03 06:11:36'),
(35, 1, 18, 'gratis', NULL, 'Reiciendis non aut totam eos.', '2025-07-10', '1900-01-01', '1900-01-01', '2025-05-13 18:27:28', '2025-06-23 16:46:16'),
(36, 4, 4, 'gratis', NULL, 'Repellendus deleniti illo sunt maxime sunt quod culpa.', '2025-09-09', '1900-01-01', '1900-01-01', '2025-04-04 05:06:19', '2025-01-30 16:28:16'),
(37, 2, 5, 'gratis', 10, 'Harum adipisci dolore harum ea perspiciatis amet.', '2025-06-13', '1900-01-01', '1900-01-01', '2025-07-30 03:31:08', '2025-08-18 12:30:48'),
(38, 9, 2, 'premium', NULL, 'Ut dolor praesentium aliquid dolorem quasi earum fugiat.', '2025-05-18', '1900-01-01', '1900-01-01', '2025-01-22 09:37:05', '2025-08-24 08:25:58'),
(39, 1, 8, NULL, NULL, 'Dolor fugiat atque placeat dicta.', '2025-04-26', '1900-01-01', '1900-01-01', '2025-01-01 04:29:32', '2025-07-20 07:13:57'),
(40, 9, 1, 'premium', 34, 'Ad aspernatur laboriosam quibusdam excepturi totam amet.', '2025-08-31', '1900-01-01', '1900-01-01', '2025-05-31 13:46:26', '2025-04-17 21:05:52'),
(41, 7, 16, 'gratis', NULL, 'Velit excepturi necessitatibus fuga tempore eaque ullam.', '2025-06-08', '1900-01-01', '1900-01-01', '2025-05-28 00:09:49', '2025-06-30 22:51:53'),
(42, 4, 17, NULL, 39, 'Cupiditate rerum laboriosam aliquid repudiandae enim cumque.', '2025-03-10', '1900-01-01', '1900-01-01', '2025-04-18 15:32:25', '2025-09-14 20:50:24'),
(43, 4, 20, 'premium', 10, 'Perspiciatis quisquam ducimus illum.', '2025-08-04', '1900-01-01', '1900-01-01', '2025-07-01 18:42:47', '2025-05-15 18:55:22'),
(44, 1, 4, 'premium', NULL, 'Provident amet quisquam amet officiis enim.', '2025-05-28', '1900-01-01', '1900-01-01', '2025-06-11 06:58:53', '2025-08-21 03:15:25'),
(45, 1, 11, 'premium', NULL, 'Perferendis soluta maxime neque ut.', '2025-08-04', '1900-01-01', '1900-01-01', '2025-07-25 01:00:52', '2025-07-04 03:39:13'),
(46, 8, 4, NULL, NULL, 'Provident excepturi beatae quas nostrum ex.', '2025-08-06', '1900-01-01', '1900-01-01', '2025-08-30 19:03:38', '2025-03-16 19:11:54'),
(47, 3, 6, NULL, NULL, 'Ea neque non nesciunt vero debitis.', '2025-07-21', '1900-01-01', '1900-01-01', '2025-06-02 05:20:53', '2025-01-06 09:42:33'),
(48, 2, 15, 'premium', NULL, 'Natus nostrum suscipit deserunt doloribus cupiditate.', '2025-02-16', '1900-01-01', '1900-01-01', '2025-09-14 07:33:37', '2025-03-19 18:57:48'),
(49, 6, 5, 'gratis', NULL, 'Eveniet perferendis doloribus sequi.', '2025-08-31', '1900-01-01', '1900-01-01', '2025-01-27 11:23:36', '2025-08-01 16:38:07'),
(50, 3, 19, NULL, NULL, 'Labore beatae assumenda voluptate at voluptatum.', '2025-07-06', '1900-01-01', '1900-01-01', '2025-01-21 02:36:33', '2025-03-04 14:44:54');

INSERT INTO `absensi` (`id`, `jadwal_id`, `siswa_id`, `status`, `catatan`, `created_at`, `updated_at`) VALUES
(1, 3, 13, 'Sakit', 'Dicta consequuntur et hic expedita maiores.', '2025-02-11 15:54:34', '2025-02-11 14:56:16'),
(2, 19, 19, 'Izin', NULL, '2025-07-26 03:08:57', '2025-03-15 00:29:18'),
(3, 28, 15, 'Sakit', NULL, '2025-08-04 04:10:48', '2025-04-12 19:18:11'),
(4, 11, 9, 'Hadir', NULL, '2025-05-21 02:26:52', '2025-01-15 00:17:35'),
(5, 6, 8, 'Sakit', NULL, '2025-06-14 23:55:44', '2025-03-14 12:58:37'),
(6, 43, 18, 'Izin', NULL, '2025-01-18 01:38:25', '2025-05-30 12:03:20'),
(7, 17, 8, 'Hadir', 'Beatae recusandae nesciunt occaecati.', '2025-07-11 02:20:46', '2025-04-12 13:01:22'),
(8, 28, 7, 'Izin', 'Possimus voluptatibus omnis necessitatibus eum perferendis.', '2025-03-28 21:13:17', '2025-05-08 02:26:49'),
(9, 32, 22, 'Hadir', NULL, '2025-02-04 10:50:37', '2025-01-21 14:49:54'),
(10, 44, 25, 'Sakit', NULL, '2025-04-20 18:57:18', '2025-09-12 23:02:54'),
(11, 35, 8, 'Sakit', NULL, '2025-03-23 19:24:01', '2025-08-11 10:24:39'),
(12, 45, 7, 'Hadir', 'Quidem officiis aliquid odio facilis perspiciatis delectus ad.', '2025-06-06 18:34:39', '2025-05-06 04:37:01'),
(13, 32, 19, 'Izin', NULL, '2025-05-16 04:50:12', '2025-03-14 07:45:16'),
(14, 31, 1, 'Hadir', 'Autem cum earum dolores.', '2025-09-15 05:35:48', '2025-03-06 05:26:25'),
(15, 11, 21, 'Alpa', 'Ab eius saepe repellat aut alias libero.', '2025-07-13 15:08:10', '2025-06-11 16:13:36'),
(16, 40, 30, 'Hadir', NULL, '2025-05-14 02:24:57', '2025-02-25 08:27:42'),
(17, 49, 16, 'Hadir', NULL, '2025-06-20 07:44:03', '2025-05-26 16:04:36'),
(18, 16, 10, 'Alpa', 'Perspiciatis repudiandae optio voluptates officia nesciunt quas.', '2025-03-21 17:25:03', '2025-07-10 19:38:10'),
(19, 37, 30, 'Sakit', 'Repellendus necessitatibus nesciunt ab doloremque consequuntur velit.', '2025-09-04 17:49:59', '2025-07-26 14:34:48'),
(20, 47, 12, 'Hadir', NULL, '2025-06-04 23:08:35', '2025-02-27 11:21:58'),
(21, 2, 3, 'Sakit', NULL, '2025-03-10 18:21:19', '2025-01-20 16:03:11'),
(22, 23, 26, 'Alpa', NULL, '2025-07-08 08:38:48', '2025-04-07 15:31:40'),
(23, 44, 6, 'Alpa', NULL, '2025-08-02 04:56:58', '2025-07-28 10:17:15'),
(24, 16, 14, 'Hadir', NULL, '2025-07-12 20:46:35', '2025-09-06 23:27:19'),
(25, 15, 18, 'Sakit', 'Placeat officiis provident velit.', '2025-03-28 11:57:36', '2025-05-02 12:46:01'),
(26, 30, 16, 'Izin', 'Quae adipisci id saepe.', '2025-03-27 11:53:21', '2025-09-10 01:15:49'),
(27, 42, 1, 'Hadir', NULL, '2025-04-27 22:16:02', '2025-04-06 02:45:12'),
(28, 18, 22, 'Izin', 'Deserunt asperiores odio dolore quae optio tempore.', '2025-02-18 07:01:57', '2025-06-09 04:27:35'),
(29, 1, 15, 'Izin', 'Accusantium possimus nihil vero.', '2025-03-27 02:40:08', '2025-08-06 19:23:07'),
(30, 30, 30, 'Sakit', 'Inventore veniam quidem quisquam molestiae vel.', '2025-01-07 19:40:23', '2025-07-23 05:45:38'),
(31, 49, 29, 'Izin', 'Soluta soluta libero optio harum laboriosam dolores.', '2025-08-30 18:30:56', '2025-08-20 03:50:08'),
(32, 4, 29, 'Hadir', NULL, '2025-02-02 18:12:55', '2025-03-05 12:32:38'),
(33, 32, 18, 'Sakit', NULL, '2025-04-27 06:31:34', '2025-05-30 02:00:47'),
(34, 39, 18, 'Izin', 'Dolores tenetur error eos amet nobis veritatis.', '2025-08-12 13:10:58', '2025-05-09 09:04:32'),
(35, 39, 30, 'Alpa', NULL, '2025-04-26 16:07:07', '2025-02-24 16:57:35'),
(36, 27, 14, 'Sakit', 'Ad beatae laudantium odit explicabo saepe.', '2025-04-18 01:43:48', '2025-07-26 18:29:57'),
(37, 18, 1, 'Hadir', NULL, '2025-04-30 18:55:46', '2025-03-17 05:27:28'),
(38, 22, 28, 'Izin', NULL, '2025-06-03 17:57:18', '2025-08-31 01:52:09'),
(39, 35, 12, 'Alpa', NULL, '2025-03-28 11:09:20', '2025-06-08 11:43:33'),
(40, 9, 7, 'Hadir', NULL, '2025-02-27 10:40:27', '2025-05-17 03:20:44'),
(41, 16, 22, 'Izin', 'Sequi magnam voluptates provident ut.', '2025-01-20 20:53:04', '2025-05-03 20:38:53'),
(42, 27, 3, 'Alpa', NULL, '2025-02-27 21:33:21', '2025-05-08 15:47:21'),
(43, 7, 27, 'Alpa', 'Explicabo ipsa adipisci impedit quis illo temporibus.', '2025-06-15 21:55:52', '2025-01-12 01:47:10'),
(44, 41, 15, 'Alpa', NULL, '2025-02-08 00:58:19', '2025-07-16 09:09:10'),
(45, 12, 3, 'Sakit', 'Harum et est est molestias.', '2025-06-13 16:25:37', '2025-05-21 05:33:10'),
(46, 46, 18, 'Sakit', 'Molestias fugiat nemo.', '2025-05-20 13:04:38', '2025-06-01 11:56:42'),
(47, 3, 15, 'Sakit', 'Deserunt nulla necessitatibus ea magni optio.', '2025-03-03 08:59:32', '2025-07-02 11:02:56'),
(48, 25, 15, 'Alpa', NULL, '2025-06-17 13:47:21', '2025-05-23 18:42:09'),
(49, 47, 10, 'Hadir', 'Sed fugit nulla repudiandae.', '2025-02-23 00:23:38', '2025-04-17 03:12:39'),
(50, 49, 28, 'Alpa', NULL, '2025-09-02 01:18:23', '2025-04-06 23:04:35'),
(51, 29, 1, 'Alpa', 'Amet aut dolorem nisi rem dolores minima.', '2025-05-26 03:08:43', '2025-03-04 16:12:05'),
(52, 35, 16, 'Alpa', NULL, '2025-08-01 00:11:14', '2025-01-26 00:51:19'),
(53, 6, 3, 'Alpa', 'Ut dignissimos esse architecto.', '2025-08-31 07:52:47', '2025-08-21 13:20:49'),
(54, 32, 9, 'Alpa', 'Quae vero ullam rerum id.', '2025-05-01 19:32:49', '2025-06-26 18:55:47'),
(55, 42, 18, 'Alpa', NULL, '2025-07-21 21:14:16', '2025-01-25 03:13:00'),
(56, 32, 8, 'Alpa', NULL, '2025-02-02 11:43:25', '2025-07-14 00:31:01'),
(57, 1, 2, 'Sakit', NULL, '2025-01-08 00:12:01', '2025-02-08 21:38:28'),
(58, 21, 8, 'Izin', NULL, '2025-08-11 00:33:37', '2025-05-14 16:59:25'),
(59, 32, 11, 'Sakit', 'Atque est quo sint.', '2025-08-17 03:58:42', '2025-03-14 10:18:57'),
(60, 33, 13, 'Hadir', NULL, '2025-06-04 08:25:44', '2025-07-05 11:39:29'),
(61, 3, 22, 'Izin', NULL, '2025-05-10 01:16:10', '2025-03-08 13:04:27'),
(62, 24, 24, 'Hadir', 'Ipsa enim corporis quibusdam deserunt.', '2025-08-13 22:24:18', '2025-07-25 23:48:58'),
(63, 33, 20, 'Sakit', 'Eligendi incidunt magnam nostrum.', '2025-05-29 21:01:52', '2025-03-05 15:07:29'),
(64, 37, 1, 'Sakit', 'At iste assumenda odio modi.', '2025-09-12 14:10:50', '2025-08-06 00:43:34'),
(65, 19, 10, 'Sakit', 'Maiores hic ducimus aspernatur dolores velit delectus.', '2025-06-26 17:02:22', '2025-06-02 03:33:53'),
(66, 11, 18, 'Hadir', 'Molestiae qui occaecati cupiditate nostrum.', '2025-05-11 17:37:55', '2025-09-04 11:30:02'),
(67, 6, 21, 'Izin', 'Veniam laudantium cum omnis voluptate possimus asperiores.', '2025-06-02 05:11:18', '2025-08-27 22:32:04'),
(68, 33, 1, 'Alpa', 'Harum eos maxime ut dolores omnis commodi.', '2025-05-09 22:31:58', '2025-06-19 11:34:50'),
(69, 25, 17, 'Izin', NULL, '2025-07-26 20:21:36', '2025-04-21 05:27:30'),
(70, 38, 6, 'Alpa', NULL, '2025-01-30 23:39:47', '2025-05-19 03:41:02'),
(71, 40, 5, 'Hadir', 'Dolores praesentium tempora veritatis.', '2025-01-20 15:20:32', '2025-02-13 11:13:36'),
(72, 46, 7, 'Alpa', NULL, '2025-01-26 23:16:00', '2025-01-31 08:06:25'),
(73, 2, 9, 'Sakit', NULL, '2025-06-06 16:29:45', '2025-07-29 23:25:24'),
(74, 9, 17, 'Izin', NULL, '2025-09-10 02:48:38', '2025-09-13 10:41:09'),
(75, 17, 23, 'Hadir', 'Laboriosam illum labore.', '2025-01-29 05:27:35', '2025-03-22 23:39:25'),
(76, 21, 26, 'Izin', NULL, '2025-08-07 14:17:05', '2025-07-02 19:11:21'),
(77, 24, 24, 'Izin', NULL, '2025-03-17 11:16:25', '2025-09-02 15:42:19'),
(78, 31, 29, 'Alpa', 'Iste quidem exercitationem reprehenderit.', '2025-01-27 20:13:57', '2025-01-12 02:24:59'),
(79, 47, 26, 'Izin', NULL, '2025-08-07 17:12:21', '2025-06-15 11:31:00'),
(80, 13, 7, 'Sakit', NULL, '2025-04-06 16:35:56', '2025-06-18 22:37:46'),
(81, 34, 10, 'Sakit', 'Nisi beatae vitae deleniti aut.', '2025-07-01 01:52:13', '2025-07-23 19:44:24'),
(82, 7, 12, 'Hadir', 'Excepturi deserunt repudiandae amet tenetur vitae nulla.', '2025-02-25 20:57:21', '2025-06-16 15:16:47'),
(83, 28, 21, 'Izin', 'Consequatur quasi odio esse officiis quia.', '2025-03-21 17:50:47', '2025-05-24 04:23:41'),
(84, 3, 27, 'Alpa', 'Iure eum quas aut eligendi sequi ab.', '2025-02-04 06:41:56', '2025-07-15 01:39:21'),
(85, 20, 30, 'Izin', NULL, '2025-08-14 13:51:20', '2025-03-06 13:33:42'),
(86, 26, 13, 'Hadir', 'Est consequuntur enim nulla labore incidunt eius.', '2025-01-30 22:49:19', '2025-02-17 22:12:25'),
(87, 27, 5, 'Sakit', 'Ipsum autem debitis quas ratione.', '2025-04-02 12:21:41', '2025-05-13 13:02:10'),
(88, 48, 11, 'Hadir', 'Doloremque at iure consectetur sapiente.', '2025-04-08 01:17:31', '2025-02-12 21:27:06'),
(89, 3, 23, 'Alpa', 'Voluptates vitae cupiditate officia odio commodi.', '2025-03-15 16:06:11', '2025-05-18 04:41:00'),
(90, 6, 1, 'Izin', 'Optio dicta nemo.', '2025-06-06 00:58:57', '2025-01-21 12:20:54'),
(91, 32, 1, 'Hadir', NULL, '2025-02-14 03:04:47', '2025-04-03 01:58:01'),
(92, 42, 3, 'Alpa', 'Labore placeat esse minima nemo reiciendis.', '2025-03-31 05:28:56', '2025-06-07 19:03:02'),
(93, 44, 17, 'Izin', 'Cupiditate at molestias corrupti nostrum.', '2025-09-10 23:11:41', '2025-02-17 04:55:02'),
(94, 43, 7, 'Sakit', 'Inventore possimus commodi iusto perspiciatis.', '2025-07-04 01:35:32', '2025-06-16 05:34:07'),
(95, 43, 16, 'Izin', 'Incidunt voluptatem et impedit pariatur quisquam ut.', '2025-01-29 03:40:27', '2025-08-24 20:02:38'),
(96, 22, 18, 'Sakit', NULL, '2025-07-19 22:00:11', '2025-08-17 08:22:40'),
(97, 13, 27, 'Izin', 'Ea hic necessitatibus delectus.', '2025-08-24 00:49:03', '2025-03-17 04:51:25'),
(98, 5, 30, 'Izin', NULL, '2025-07-06 09:30:30', '2025-06-27 18:16:39'),
(99, 6, 12, 'Hadir', NULL, '2025-05-23 06:49:33', '2025-07-22 05:22:28'),
(100, 26, 20, 'Izin', NULL, '2025-06-05 23:26:01', '2025-02-18 14:07:53'),
(101, 14, 24, 'Alpa', NULL, '2025-03-22 05:55:54', '2025-08-15 11:25:39'),
(102, 17, 12, 'Izin', NULL, '2025-01-07 07:31:38', '2025-05-23 01:35:38'),
(103, 7, 17, 'Izin', 'Suscipit harum veritatis corrupti porro.', '2025-05-26 01:20:01', '2025-07-25 21:31:13'),
(104, 30, 2, 'Izin', NULL, '2025-07-07 01:42:39', '2025-05-31 13:14:10'),
(105, 14, 19, 'Sakit', NULL, '2025-02-28 16:35:37', '2025-02-23 20:13:38'),
(106, 34, 12, 'Hadir', 'Repudiandae nostrum molestias sequi voluptates dolor.', '2025-05-06 16:46:55', '2025-03-09 02:58:21'),
(107, 19, 11, 'Alpa', NULL, '2025-08-05 07:32:42', '2025-07-13 13:40:50'),
(108, 23, 30, 'Izin', 'Cum dolor iste dicta repellat ut.', '2025-08-24 13:47:51', '2025-05-28 16:02:18'),
(109, 22, 12, 'Izin', NULL, '2025-02-22 05:22:50', '2025-01-06 23:01:37'),
(110, 42, 1, 'Izin', 'Repellat dolor magnam dolor.', '2025-04-18 19:10:42', '2025-04-16 05:40:04'),
(111, 46, 21, 'Hadir', NULL, '2025-08-11 04:51:31', '2025-07-30 11:51:42'),
(112, 20, 19, 'Alpa', 'Autem ad eum ullam.', '2025-05-17 08:24:49', '2025-07-18 01:45:39'),
(113, 18, 12, 'Hadir', NULL, '2025-07-24 12:40:31', '2025-03-11 16:14:26'),
(114, 48, 8, 'Sakit', NULL, '2025-03-19 07:55:35', '2025-01-01 19:07:43'),
(115, 25, 14, 'Hadir', NULL, '2025-07-29 16:20:56', '2025-02-28 11:28:57'),
(116, 3, 20, 'Izin', NULL, '2025-02-02 11:07:17', '2025-01-12 17:54:17'),
(117, 6, 6, 'Izin', 'Autem qui deleniti.', '2025-05-03 12:55:25', '2025-01-02 23:39:16'),
(118, 44, 11, 'Sakit', NULL, '2025-09-02 18:13:14', '2025-04-06 01:48:29'),
(119, 28, 25, 'Izin', NULL, '2025-07-12 01:52:42', '2025-03-02 14:49:15'),
(120, 11, 14, 'Hadir', NULL, '2025-08-06 11:53:16', '2025-02-11 16:26:47'),
(121, 28, 19, 'Sakit', 'Delectus aut cupiditate.', '2025-07-05 17:22:24', '2025-04-10 14:50:16'),
(122, 29, 3, 'Izin', NULL, '2025-08-31 10:20:00', '2025-09-05 00:26:18'),
(123, 29, 25, 'Hadir', NULL, '2025-05-04 20:19:27', '2025-08-29 15:39:43'),
(124, 31, 22, 'Izin', NULL, '2025-07-16 21:34:10', '2025-08-26 22:04:28'),
(125, 49, 22, 'Hadir', 'Ipsa nisi quae.', '2025-06-04 13:41:58', '2025-09-14 10:24:21'),
(126, 36, 15, 'Izin', NULL, '2025-06-06 20:00:57', '2025-08-08 13:36:11'),
(127, 19, 7, 'Izin', 'Culpa laudantium maiores sunt aut illo.', '2025-05-04 19:59:24', '2025-07-22 00:07:14'),
(128, 31, 5, 'Alpa', 'Voluptatum adipisci voluptatum magni perspiciatis illum minima.', '2025-06-11 20:47:03', '2025-02-16 15:29:39'),
(129, 36, 20, 'Alpa', NULL, '2025-06-02 03:49:01', '2025-02-10 02:51:05'),
(130, 14, 1, 'Sakit', NULL, '2025-08-16 19:08:15', '2025-02-24 12:20:36'),
(131, 4, 16, 'Hadir', NULL, '2025-01-06 10:56:41', '2025-04-23 16:42:18'),
(132, 25, 18, 'Hadir', 'Quidem deserunt neque.', '2025-06-01 17:26:00', '2025-01-06 13:19:37'),
(133, 48, 19, 'Alpa', 'Nostrum doloremque quos eaque expedita minima.', '2025-06-13 07:17:24', '2025-02-06 11:17:01'),
(134, 39, 1, 'Hadir', 'Perferendis illum cumque rerum.', '2025-02-20 11:47:56', '2025-02-08 21:11:51'),
(135, 11, 28, 'Alpa', NULL, '2025-09-08 06:33:17', '2025-01-27 22:35:22'),
(136, 40, 18, 'Sakit', NULL, '2025-02-18 03:43:04', '2025-01-24 16:49:00'),
(137, 16, 16, 'Sakit', NULL, '2025-06-23 12:11:32', '2025-03-29 11:01:57'),
(138, 37, 12, 'Sakit', 'Ullam repellendus magnam alias culpa architecto occaecati sed.', '2025-08-24 20:42:25', '2025-05-06 00:57:04'),
(139, 40, 2, 'Izin', 'A quibusdam expedita vero impedit et.', '2025-05-07 23:35:44', '2025-05-10 02:10:41'),
(140, 23, 6, 'Izin', 'Laboriosam eveniet delectus explicabo doloremque enim labore.', '2025-03-22 04:55:22', '2025-04-20 13:59:03'),
(141, 22, 3, 'Hadir', NULL, '2025-06-11 14:46:56', '2025-02-25 22:43:50'),
(142, 10, 10, 'Hadir', NULL, '2025-04-11 12:16:50', '2025-04-23 20:25:36'),
(143, 24, 12, 'Sakit', 'Quia dignissimos nostrum reprehenderit consectetur.', '2025-09-09 17:37:59', '2025-03-15 22:39:47'),
(144, 32, 26, 'Izin', 'Veritatis minus modi eos ipsum distinctio eveniet voluptate.', '2025-04-30 03:32:16', '2025-06-22 09:05:28'),
(145, 17, 18, 'Hadir', 'Voluptatem corrupti accusantium possimus praesentium velit.', '2025-08-09 18:58:37', '2025-06-08 05:10:24'),
(146, 39, 3, 'Sakit', 'Deleniti cupiditate odio perferendis dolores perspiciatis sed.', '2025-05-25 21:00:33', '2025-02-01 17:13:11'),
(147, 42, 7, 'Alpa', 'Molestiae ex sapiente tempora facere error fuga consectetur.', '2025-08-26 19:43:54', '2025-06-29 08:51:51'),
(148, 25, 17, 'Alpa', NULL, '2025-01-20 09:53:25', '2025-06-26 11:29:06'),
(149, 28, 14, 'Hadir', NULL, '2025-03-22 04:33:28', '2025-01-17 09:22:06'),
(150, 40, 23, 'Alpa', NULL, '2025-05-05 12:30:40', '2025-08-14 06:23:44'),
(151, 1, 21, 'Izin', NULL, '2025-07-29 23:12:21', '2025-02-21 21:26:54'),
(152, 42, 15, 'Alpa', NULL, '2025-04-20 15:48:27', '2025-01-12 04:29:26'),
(153, 23, 13, 'Alpa', NULL, '2025-06-12 04:35:33', '2025-02-08 01:48:53'),
(154, 49, 16, 'Hadir', NULL, '2025-04-13 16:11:58', '2025-04-04 04:28:04'),
(155, 8, 24, 'Alpa', 'Adipisci ipsa voluptate provident.', '2025-05-01 21:14:44', '2025-01-03 05:43:32'),
(156, 44, 14, 'Alpa', NULL, '2025-04-18 04:46:26', '2025-04-25 16:29:05'),
(157, 24, 16, 'Izin', NULL, '2025-09-04 09:15:25', '2025-01-19 09:13:59'),
(158, 37, 24, 'Alpa', 'Itaque architecto placeat reprehenderit.', '2025-03-17 13:16:53', '2025-08-17 05:01:57'),
(159, 14, 22, 'Sakit', 'Impedit repudiandae odit delectus veritatis dolores.', '2025-01-26 01:14:48', '2025-04-17 11:14:51'),
(160, 27, 12, 'Hadir', NULL, '2025-06-14 13:59:09', '2025-03-23 21:44:52'),
(161, 19, 3, 'Sakit', 'Quam sequi eligendi molestiae.', '2025-03-20 10:49:28', '2025-07-29 03:59:13'),
(162, 50, 23, 'Izin', NULL, '2025-02-01 09:19:55', '2025-05-08 07:24:20'),
(163, 49, 20, 'Sakit', NULL, '2025-05-09 03:23:08', '2025-06-25 12:11:19'),
(164, 29, 28, 'Sakit', NULL, '2025-07-01 21:27:38', '2025-09-15 04:09:16'),
(165, 33, 4, 'Alpa', NULL, '2025-07-22 23:00:07', '2025-06-24 21:11:11'),
(166, 43, 7, 'Sakit', 'Id pariatur ipsa ipsam nesciunt mollitia molestiae.', '2025-08-05 02:09:14', '2025-03-06 02:43:00'),
(167, 38, 5, 'Izin', 'Fugiat repellendus at debitis consectetur.', '2025-01-08 03:57:59', '2025-01-20 15:59:23'),
(168, 18, 8, 'Alpa', 'Tenetur placeat deleniti corporis.', '2025-01-04 22:48:25', '2025-08-05 09:59:40'),
(169, 39, 26, 'Izin', NULL, '2025-02-17 11:52:29', '2025-02-10 11:41:09'),
(170, 27, 7, 'Sakit', 'Officia et accusamus libero minima.', '2025-01-28 14:43:37', '2025-03-23 12:21:05'),
(171, 42, 10, 'Hadir', 'Vero unde laudantium veniam eos error.', '2025-08-26 13:55:50', '2025-06-04 04:16:40'),
(172, 44, 8, 'Izin', NULL, '2025-06-24 04:10:36', '2025-04-21 19:37:37'),
(173, 41, 17, 'Alpa', 'Sit aliquam commodi accusantium libero.', '2025-02-23 13:30:14', '2025-04-25 04:50:06'),
(174, 2, 13, 'Izin', 'Minus ratione velit nulla explicabo dicta ex placeat.', '2025-03-08 12:24:06', '2025-03-25 04:51:34'),
(175, 24, 16, 'Sakit', NULL, '2025-05-30 15:35:22', '2025-07-06 03:57:54'),
(176, 8, 3, 'Izin', 'Minima eum omnis architecto sequi.', '2025-01-01 16:52:03', '2025-06-12 19:58:07'),
(177, 30, 19, 'Hadir', 'Quis fuga consequuntur earum vitae.', '2025-06-16 22:31:41', '2025-07-02 16:11:05'),
(178, 37, 18, 'Alpa', 'Ab error atque quibusdam est voluptatem.', '2025-06-24 14:54:22', '2025-08-11 01:31:25'),
(179, 31, 21, 'Izin', 'Inventore rem quae adipisci reprehenderit dolorum tempore nobis.', '2025-04-25 15:37:37', '2025-07-23 06:43:26'),
(180, 44, 28, 'Izin', 'Aperiam debitis minima dolore sint minus.', '2025-03-14 22:21:00', '2025-03-22 23:22:55'),
(181, 30, 27, 'Izin', NULL, '2025-03-17 10:30:08', '2025-03-30 15:49:59'),
(182, 34, 19, 'Alpa', 'Excepturi eius nesciunt occaecati cumque beatae reiciendis.', '2025-03-16 22:26:57', '2025-08-03 00:09:07'),
(183, 2, 22, 'Izin', NULL, '2025-08-18 08:58:16', '2025-07-21 04:16:39'),
(184, 41, 8, 'Hadir', NULL, '2025-01-09 06:45:21', '2025-01-16 19:06:47'),
(185, 25, 10, 'Hadir', 'Incidunt blanditiis tempora placeat omnis dolorem voluptatibus.', '2025-01-18 00:43:58', '2025-07-25 06:59:53'),
(186, 1, 14, 'Izin', 'Deserunt ad reprehenderit blanditiis ducimus.', '2025-05-11 10:34:50', '2025-06-25 23:06:12'),
(187, 7, 28, 'Sakit', NULL, '2025-05-20 19:43:42', '2025-03-20 03:48:51'),
(188, 25, 30, 'Hadir', 'Porro maxime officia ipsam quaerat quos.', '2025-05-22 18:39:35', '2025-03-03 21:05:11'),
(189, 6, 8, 'Hadir', NULL, '2025-01-01 21:49:27', '2025-05-04 19:44:32'),
(190, 37, 13, 'Alpa', 'Quaerat fuga ex consequuntur ducimus.', '2025-01-14 01:29:09', '2025-01-26 16:26:34'),
(191, 2, 14, 'Hadir', NULL, '2025-07-14 02:32:40', '2025-01-09 11:31:25'),
(192, 39, 2, 'Sakit', NULL, '2025-01-11 19:27:45', '2025-01-04 00:58:38'),
(193, 20, 22, 'Hadir', 'Laudantium aliquam dolorem asperiores earum.', '2025-05-08 02:36:51', '2025-08-17 09:15:31'),
(194, 43, 16, 'Alpa', NULL, '2025-07-23 18:44:26', '2025-05-17 20:21:02'),
(195, 45, 29, 'Alpa', NULL, '2025-01-13 12:31:34', '2025-08-14 01:10:52'),
(196, 30, 17, 'Alpa', NULL, '2025-01-14 03:10:53', '2025-09-13 15:46:14'),
(197, 6, 4, 'Hadir', NULL, '2025-05-07 01:08:38', '2025-07-03 02:41:42'),
(198, 18, 13, 'Sakit', 'Minus impedit temporibus sit.', '2025-02-10 12:10:32', '2025-02-26 23:59:25'),
(199, 34, 8, 'Hadir', NULL, '2025-02-09 10:33:20', '2025-06-16 12:32:54'),
(200, 39, 27, 'Alpa', NULL, '2025-02-03 18:01:43', '2025-03-20 00:16:59');

INSERT INTO `absensi_guru` (`id`, `jadwal_id`, `guru_id`, `status`, `catatan`, `waktu_absensi`) VALUES
(1, 13, 10, 'Tidak Hadir', NULL, '2025-02-13 00:12:33'),
(2, 1, 10, 'Tidak Hadir', 'Amet labore aperiam itaque ducimus quasi.', '2025-03-14 06:13:10'),
(3, 28, 42, 'Tidak Hadir', NULL, '2025-04-06 03:58:24'),
(4, 10, 10, 'Hadir', 'Sint odit suscipit incidunt error.', '2025-08-24 01:28:22'),
(5, 32, 39, 'Hadir', NULL, '2025-06-29 00:27:40'),
(6, 20, 42, 'Hadir', NULL, '2025-05-13 04:08:39'),
(7, 33, 34, 'Tidak Hadir', 'Possimus quam in odio earum voluptatem.', '2025-06-05 02:05:07'),
(8, 8, 10, 'Tidak Hadir', NULL, '2025-07-06 15:16:20'),
(9, 4, 34, 'Hadir', NULL, '2025-07-14 00:32:59'),
(10, 42, 10, 'Hadir', NULL, '2025-01-02 19:51:54'),
(11, 43, 34, 'Tidak Hadir', NULL, '2025-06-12 04:59:17'),
(12, 25, 10, 'Tidak Hadir', 'Sed qui exercitationem repudiandae.', '2025-08-03 15:16:11'),
(13, 24, 39, 'Tidak Hadir', 'Et natus distinctio.', '2025-03-07 06:50:34'),
(14, 28, 42, 'Tidak Hadir', NULL, '2025-09-15 21:50:41'),
(15, 47, 42, 'Tidak Hadir', NULL, '2025-08-12 02:12:02'),
(16, 29, 39, 'Hadir', NULL, '2025-03-30 04:24:19'),
(17, 39, 39, 'Hadir', NULL, '2025-07-19 03:54:08'),
(18, 8, 34, 'Hadir', 'Ipsam voluptate doloribus.', '2025-04-05 15:54:59'),
(19, 24, 34, 'Hadir', 'Impedit soluta ab consequatur sapiente tempore at.', '2025-03-08 07:04:23'),
(20, 24, 34, 'Tidak Hadir', NULL, '2025-07-30 05:08:28'),
(21, 42, 10, 'Tidak Hadir', NULL, '2025-01-18 10:04:26'),
(22, 23, 42, 'Hadir', 'Quia deserunt molestiae totam.', '2025-08-20 01:38:49'),
(23, 3, 42, 'Tidak Hadir', NULL, '2025-03-07 13:55:18'),
(24, 22, 10, 'Tidak Hadir', NULL, '2025-06-19 12:18:18'),
(25, 20, 42, 'Hadir', 'Mollitia debitis quae distinctio ipsa.', '2025-08-22 13:32:46'),
(26, 49, 39, 'Tidak Hadir', 'Quis occaecati soluta possimus animi excepturi temporibus.', '2025-04-04 12:17:17'),
(27, 28, 10, 'Tidak Hadir', 'Odit rerum ex est repellat atque aut iusto.', '2025-03-12 03:34:00'),
(28, 40, 42, 'Hadir', 'Culpa velit deleniti laboriosam commodi tempore.', '2025-02-13 19:21:20'),
(29, 47, 34, 'Hadir', NULL, '2025-08-19 22:37:19'),
(30, 18, 10, 'Tidak Hadir', 'Quam reiciendis quia.', '2025-01-15 16:26:27'),
(31, 17, 42, 'Tidak Hadir', NULL, '2025-01-11 17:12:00'),
(32, 12, 34, 'Hadir', NULL, '2025-04-25 17:37:56'),
(33, 39, 34, 'Tidak Hadir', NULL, '2025-04-27 06:19:07'),
(34, 14, 42, 'Hadir', 'Occaecati quis illum iure repellat esse.', '2025-05-17 07:51:07'),
(35, 10, 42, 'Tidak Hadir', NULL, '2025-03-26 01:57:28'),
(36, 48, 42, 'Hadir', 'Rerum provident occaecati repudiandae temporibus eos fugit.', '2025-01-23 20:34:23'),
(37, 22, 10, 'Hadir', 'Voluptates porro suscipit distinctio expedita corrupti.', '2025-02-18 10:43:16'),
(38, 25, 10, 'Hadir', 'Adipisci commodi cupiditate error.', '2025-01-18 18:44:50'),
(39, 44, 10, 'Hadir', 'Eligendi cum quos ex ea.', '2025-08-23 14:01:30'),
(40, 17, 42, 'Hadir', NULL, '2025-08-18 10:23:30'),
(41, 3, 42, 'Tidak Hadir', 'Sunt neque consequuntur.', '2025-01-17 01:07:52'),
(42, 46, 10, 'Tidak Hadir', 'Temporibus officiis quo fugit veritatis provident earum.', '2025-04-30 03:20:11'),
(43, 28, 39, 'Tidak Hadir', 'Earum eveniet iusto perferendis laborum optio natus.', '2025-01-27 21:28:24'),
(44, 30, 10, 'Hadir', 'Fugit ipsum ex assumenda nostrum adipisci.', '2025-07-15 19:21:04'),
(45, 33, 42, 'Tidak Hadir', NULL, '2025-03-13 09:15:24'),
(46, 19, 34, 'Tidak Hadir', NULL, '2025-01-20 14:48:31'),
(47, 26, 34, 'Tidak Hadir', NULL, '2025-09-08 19:16:20'),
(48, 20, 39, 'Tidak Hadir', NULL, '2025-05-25 10:54:26'),
(49, 26, 34, 'Hadir', 'Rem libero possimus architecto soluta.', '2025-01-11 15:27:28'),
(50, 27, 39, 'Tidak Hadir', NULL, '2025-01-17 18:51:56'),
(51, 12, 39, 'Hadir', NULL, '2025-05-21 07:32:15'),
(52, 34, 39, 'Tidak Hadir', 'Suscipit amet quae voluptate.', '2025-07-22 23:57:55'),
(53, 19, 10, 'Hadir', NULL, '2025-05-24 22:21:41'),
(54, 17, 42, 'Tidak Hadir', NULL, '2025-07-01 07:04:57'),
(55, 6, 34, 'Hadir', 'Doloribus quibusdam rerum id laudantium.', '2025-08-02 21:34:59'),
(56, 30, 42, 'Hadir', NULL, '2025-09-16 15:56:43'),
(57, 33, 34, 'Tidak Hadir', NULL, '2025-04-06 19:08:38'),
(58, 13, 10, 'Tidak Hadir', 'Nisi amet magni.', '2025-07-14 07:54:41'),
(59, 5, 42, 'Tidak Hadir', NULL, '2025-07-02 06:37:04'),
(60, 42, 42, 'Tidak Hadir', 'Minus corrupti ullam mollitia odio aliquam.', '2025-01-05 15:59:38'),
(61, 24, 10, 'Hadir', NULL, '2025-04-23 17:34:32'),
(62, 47, 42, 'Tidak Hadir', 'Aliquam accusamus repellat natus corrupti necessitatibus laboriosam minima.', '2025-04-19 10:41:11'),
(63, 19, 39, 'Hadir', NULL, '2025-01-17 00:57:56'),
(64, 11, 10, 'Hadir', 'Fugiat magnam ut minus aut.', '2025-08-27 10:53:42'),
(65, 1, 42, 'Tidak Hadir', NULL, '2025-08-15 12:41:02'),
(66, 2, 42, 'Hadir', NULL, '2025-07-08 23:31:37'),
(67, 9, 39, 'Tidak Hadir', NULL, '2025-07-05 21:48:30'),
(68, 30, 39, 'Hadir', NULL, '2025-01-20 16:27:34'),
(69, 2, 39, 'Tidak Hadir', 'Iusto corporis totam totam.', '2025-04-24 04:21:12'),
(70, 43, 10, 'Tidak Hadir', NULL, '2025-03-06 10:30:14'),
(71, 44, 42, 'Tidak Hadir', NULL, '2025-07-16 22:35:12'),
(72, 49, 39, 'Tidak Hadir', 'Impedit reiciendis mollitia cum cum consequuntur neque quasi.', '2025-09-13 06:27:06'),
(73, 42, 10, 'Hadir', 'Illo molestiae ea assumenda explicabo velit sequi.', '2025-03-27 21:18:21'),
(74, 10, 39, 'Tidak Hadir', 'Pariatur nostrum similique aliquam ducimus sequi fugit.', '2025-07-06 04:39:43'),
(75, 38, 10, 'Tidak Hadir', NULL, '2025-07-16 16:44:44'),
(76, 39, 10, 'Tidak Hadir', NULL, '2025-09-07 09:23:49'),
(77, 19, 42, 'Tidak Hadir', 'Quo consequatur natus architecto tempore.', '2025-01-10 20:46:30'),
(78, 10, 34, 'Hadir', NULL, '2025-04-30 21:44:11'),
(79, 2, 39, 'Tidak Hadir', NULL, '2025-02-06 17:50:27'),
(80, 5, 42, 'Tidak Hadir', 'Placeat magnam est.', '2025-08-21 13:40:50'),
(81, 20, 42, 'Hadir', NULL, '2025-07-05 02:22:12'),
(82, 11, 39, 'Tidak Hadir', NULL, '2025-09-07 03:33:32'),
(83, 31, 39, 'Tidak Hadir', 'Assumenda minima quia enim culpa suscipit.', '2025-02-07 14:23:36'),
(84, 32, 39, 'Hadir', 'Quae est placeat aliquam unde vitae rem nemo.', '2025-01-26 17:50:40'),
(85, 43, 42, 'Tidak Hadir', NULL, '2025-01-11 02:34:33'),
(86, 31, 39, 'Hadir', NULL, '2025-03-23 05:25:19'),
(87, 24, 39, 'Tidak Hadir', 'Explicabo dolorem illum aut itaque.', '2025-08-13 06:50:00'),
(88, 7, 34, 'Hadir', NULL, '2025-09-16 05:49:26'),
(89, 35, 10, 'Hadir', 'Quam pariatur nesciunt illum officiis quia veniam.', '2025-03-07 20:42:11'),
(90, 49, 10, 'Hadir', 'Delectus dolore quos sunt pariatur harum illum.', '2025-01-14 08:55:05'),
(91, 6, 34, 'Hadir', NULL, '2025-06-17 22:07:34'),
(92, 46, 10, 'Hadir', 'Ipsam quae porro magnam.', '2025-04-06 09:23:56'),
(93, 3, 10, 'Hadir', NULL, '2025-09-06 03:15:39'),
(94, 4, 39, 'Hadir', NULL, '2025-04-09 16:30:44'),
(95, 50, 42, 'Hadir', NULL, '2025-03-11 09:21:17'),
(96, 24, 34, 'Tidak Hadir', 'Aliquam assumenda iste beatae doloremque quis quisquam officia.', '2025-08-10 21:20:55'),
(97, 16, 10, 'Hadir', 'Ad optio quos corporis possimus fugiat tempore.', '2025-01-03 21:27:12'),
(98, 29, 39, 'Hadir', 'Pariatur tempore facilis minima vero.', '2025-08-30 00:31:09'),
(99, 36, 42, 'Tidak Hadir', 'Repellat vitae fugiat eum nihil.', '2025-06-29 16:49:14'),
(100, 20, 42, 'Tidak Hadir', 'Amet error explicabo sint eius minus.', '2025-07-17 02:19:36');

INSERT INTO `payments` (`id`, `user_id`, `class_id`, `amount`, `payment_method`, `bank_name`, `account_number`, `payment_proof`, `status`, `enrollment_status`, `verified_by`, `verified_at`, `notes`, `enrollment_notes`, `created_at`, `updated_at`) VALUES
(1, 39, 10, 807655.58, 'Cash', NULL, NULL, NULL, 'Verified', 'Enrolled', NULL, NULL, 'Sequi quia fugit non quaerat. Eligendi molestias eligendi dolorem repellat accusantium tempora. Quam excepturi laboriosam corrupti quod.', NULL, '2025-01-22 22:19:46', '2025-02-23 03:14:52'),
(2, 4, 2, 2212788.49, 'Cash', NULL, 'GB08TMQD298101613926', NULL, 'Rejected', 'Access Revoked', 31, NULL, 'Suscipit autem architecto omnis harum neque. Soluta error illum inventore fuga quas.', 'Error consequatur quaerat eveniet at harum mollitia.', '2025-02-18 09:53:29', '2025-02-05 08:16:04'),
(3, 32, 3, 3423002.35, 'Cash', NULL, 'GB07WMQZ937111504789', '/uploads/payments/proof_3.jpg', 'Pending', 'Not Enrolled', 10, NULL, 'Libero ratione aspernatur quis aspernatur nulla perspiciatis ipsa. Dolorum corrupti deleniti consequuntur illo est.', 'Beatae illo fugit non adipisci voluptate.', '2025-06-05 21:01:00', '2025-08-24 23:48:11'),
(4, 35, 9, 4412084.71, 'Transfer', 'UD Rahayu (Persero) Tbk', 'GB88RDIQ392172080292', NULL, 'Rejected', 'Enrolled', NULL, '2025-07-17 18:39:58', 'Quam atque illum deserunt nobis vero eos magni. Sit nam tempora voluptate corrupti. Vitae eaque magnam.', 'Quidem dolore quam praesentium officiis.', '2025-04-21 10:42:24', '2025-03-17 23:16:14'),
(5, 29, 10, 1758447.31, 'Transfer', NULL, 'GB64TTBC973831396871', NULL, 'Rejected', 'Access Revoked', NULL, '2025-06-20 21:51:15', 'Vitae tenetur harum possimus. Ipsa provident harum doloremque tenetur eveniet consequuntur. Voluptates quae autem illo.', 'Similique consectetur assumenda delectus aliquam sequi asperiores.', '2025-05-16 06:19:12', '2025-01-01 21:32:46'),
(6, 30, 10, 3095006.15, 'Other', NULL, 'GB73OOZH380156210910', NULL, 'Pending', 'Enrolled', NULL, '2025-03-10 00:37:22', 'Quibusdam libero minus omnis. Doloremque aliquam fugit illo. Voluptatem reprehenderit illum doloremque.', NULL, '2025-05-22 00:21:14', '2025-07-24 11:08:27'),
(7, 42, 10, 4403751.67, 'Other', 'Perum Najmudin Pradana (Persero) Tbk', 'GB12OHYV132521454410', NULL, 'Rejected', 'Enrolled', 23, '2025-06-15 07:58:11', 'Accusamus ad assumenda repellat officiis. Alias mollitia accusantium vero ratione dicta. Ratione delectus vel qui.', 'Earum in vero suscipit.', '2025-07-28 15:40:45', '2025-08-18 13:57:43'),
(8, 1, 1, 1840868.68, 'Other', 'UD Utami Handayani', NULL, '/uploads/payments/proof_8.jpg', 'Pending', 'Access Revoked', 15, '2025-08-23 22:51:56', NULL, 'Cumque totam corrupti rem quidem.', '2025-03-07 11:15:21', '2025-02-28 07:10:03'),
(9, 39, 8, 4278717.19, 'Other', NULL, 'GB78AHEK508553384567', NULL, 'Verified', 'Not Enrolled', 21, NULL, NULL, 'Odio perferendis eum a exercitationem voluptate.', '2025-04-07 19:42:37', '2025-04-15 08:52:37'),
(10, 25, 2, 2321370.33, 'Cash', 'Perum Habibi', NULL, NULL, 'Rejected', 'Not Enrolled', 41, NULL, NULL, NULL, '2025-02-16 07:25:02', '2025-02-13 23:56:30'),
(11, 32, 6, 2275704.9, 'Transfer', 'CV Nashiruddin Wibowo', 'GB11JEXH352293448160', NULL, 'Pending', 'Enrolled', NULL, NULL, 'Aut reprehenderit quaerat quaerat dignissimos. Nobis alias voluptatum perferendis optio dolores facere. Ducimus earum corporis iure rem. Magni esse aliquid quidem excepturi omnis.', NULL, '2025-06-21 02:11:57', '2025-01-04 05:43:59'),
(12, 45, 7, 2175736.33, 'Other', 'CV Prayoga', 'GB77CNDG875053985285', NULL, 'Verified', 'Enrolled', 34, '2025-03-11 05:09:07', NULL, 'Excepturi dolorem velit voluptatum.', '2025-02-24 18:51:59', '2025-09-12 22:02:38'),
(13, 13, 4, 882069.18, 'Other', 'Perum Susanti', NULL, NULL, 'Verified', 'Not Enrolled', NULL, '2025-09-05 04:33:13', 'Magni assumenda laboriosam laudantium odio vitae. Ab ab aperiam eius. Error alias necessitatibus.', 'Saepe maxime eligendi.', '2025-07-15 08:33:49', '2025-06-27 09:02:27'),
(14, 35, 1, 1526729.15, 'Transfer', 'Perum Lailasari Hasanah', 'GB74LUPN255161318593', '/uploads/payments/proof_14.jpg', 'Rejected', 'Access Revoked', NULL, NULL, 'Illo ea commodi fugit iure assumenda. Libero pariatur libero beatae amet.', 'Voluptas sunt eveniet totam maxime cupiditate vero.', '2025-01-19 19:19:21', '2025-03-28 01:43:46'),
(15, 16, 3, 1457593.9, 'Cash', NULL, NULL, '/uploads/payments/proof_15.jpg', 'Rejected', 'Access Revoked', 32, NULL, 'Sapiente rem ad perspiciatis. Dignissimos laboriosam asperiores aliquam. Recusandae voluptatibus maiores quo quisquam commodi.', 'Ipsum blanditiis quasi maiores voluptas delectus ratione iste.', '2025-01-18 23:53:38', '2025-01-26 05:29:15'),
(16, 10, 10, 4283853.63, 'Transfer', NULL, NULL, NULL, 'Pending', 'Enrolled', NULL, NULL, 'Facere saepe laudantium esse repellendus doloribus culpa. Corporis odit ullam ab tempora soluta.', 'Esse amet sunt sunt ea.', '2025-04-09 15:57:51', '2025-03-11 11:00:08'),
(17, 32, 1, 644321.11, 'Cash', 'PD Mulyani Rajasa Tbk', NULL, NULL, 'Pending', 'Access Revoked', NULL, '2025-08-05 17:29:17', 'Dicta saepe quam asperiores veritatis ex dolores. Vero quia odit corrupti dicta illo. Velit quisquam dolore ipsam officiis.', 'Aspernatur molestias quod dicta ab quis amet mollitia.', '2025-07-19 19:01:10', '2025-03-12 23:40:45'),
(18, 46, 3, 4281762.65, 'Cash', 'PD Budiman Nainggolan', NULL, NULL, 'Verified', 'Not Enrolled', 37, NULL, 'Quaerat in similique quod repellat eligendi. Animi quod deleniti soluta magni.', 'Ratione occaecati corrupti accusantium earum.', '2025-05-20 08:01:51', '2025-07-26 17:48:55'),
(19, 50, 6, 1154502.08, 'Other', 'CV Sinaga Tbk', 'GB94IVUZ262891561523', NULL, 'Verified', 'Enrolled', NULL, '2025-06-20 07:52:09', 'Architecto est expedita veritatis porro tenetur hic. Odio repellat architecto.', 'Odio eligendi aspernatur beatae eum quasi corrupti.', '2025-09-16 16:25:29', '2025-02-04 17:21:06'),
(20, 8, 7, 4240199.47, 'Transfer', 'PT Pudjiastuti Saragih Tbk', 'GB07SINA070164002674', '/uploads/payments/proof_20.jpg', 'Pending', 'Access Revoked', 21, NULL, 'Doloremque impedit laudantium impedit. Similique assumenda maxime dolores. Asperiores minus quisquam neque.', NULL, '2025-01-14 22:19:12', '2025-09-02 15:21:47');

INSERT INTO `premium_class_enrollments` (`id`, `class_id`, `student_id`, `payment_id`, `enrollment_date`, `status`, `access_granted_by`, `access_granted_at`, `access_expires_at`, `progress`, `completion_date`, `notes`, `created_at`, `updated_at`) VALUES
(1, 5, 40, 8, '2025-02-06 08:00:41', 'Cancelled', 33, NULL, '2025-07-19 09:26:49', 91, NULL, 'Facere beatae sapiente nisi ab eum recusandae. Et occaecati minima quae ad doloribus. Commodi at ullam voluptates quisquam quo voluptatum.', '2025-09-15 02:58:24', '2025-05-25 14:09:19'),
(2, 3, 50, 16, '2025-01-08 06:54:30', 'Pending', 39, NULL, '2025-09-01 16:42:49', 42, NULL, 'Ipsum consequuntur non natus officiis minima quo. Quae magnam commodi cum velit.', '2025-04-03 15:16:57', '2025-05-28 11:58:03'),
(3, 8, 3, 18, '2025-02-23 08:18:56', 'Completed', NULL, '2025-06-08 05:07:07', '2025-08-27 09:28:45', 24, NULL, 'Neque quos dolorem labore dignissimos. Suscipit fugiat possimus. Molestiae molestias perferendis reprehenderit.', '2025-03-24 08:04:04', '2025-07-14 07:00:54'),
(4, 1, 25, 20, '2025-04-26 10:23:12', 'Suspended', 34, NULL, '2025-07-02 12:02:56', 4, '2025-06-30 04:22:01', 'Id libero quas ea recusandae. Eveniet in quae eius est eos.', '2025-09-07 09:55:09', '2025-05-30 06:11:39'),
(5, 4, 6, 17, '2025-05-27 13:19:18', 'Pending', NULL, '2025-08-01 18:28:01', '2025-04-10 03:18:39', 50, NULL, 'Ea non omnis nostrum. Vero ex velit officia perspiciatis.', '2025-08-24 14:10:45', '2025-08-30 01:32:24'),
(6, 10, 2, 3, '2025-08-14 03:20:01', 'Pending', 16, '2025-09-07 13:09:58', '2025-07-02 14:08:18', 100, NULL, 'Magni consequuntur repudiandae beatae ipsum.', '2025-01-17 01:23:54', '2025-09-15 20:11:47'),
(7, 9, 2, 2, '2025-06-08 09:06:01', 'Completed', NULL, NULL, NULL, 32, '2025-02-14 21:28:00', 'Est perspiciatis occaecati laboriosam porro officiis. Quos sit eaque rem culpa unde. Accusamus possimus saepe eveniet voluptas repellat error.', '2025-04-02 13:41:59', '2025-03-12 13:34:23'),
(8, 7, 2, 8, '2025-05-25 19:17:54', 'Cancelled', 8, NULL, NULL, 1, '2025-07-26 00:10:58', 'Voluptate dolores culpa libero autem praesentium quam. Itaque perspiciatis porro quas tenetur nostrum. Alias quae voluptatum.', '2025-07-29 09:45:19', '2025-06-14 13:44:01'),
(9, 8, 22, 10, '2025-03-31 18:08:47', 'Active', NULL, '2025-01-23 22:35:23', NULL, 88, '2025-08-01 10:27:36', 'Quis sint at labore iusto cum. Ipsum unde est doloribus soluta. Tenetur laboriosam laudantium nobis.', '2025-02-15 21:23:21', '2025-08-30 08:12:34'),
(10, 10, 38, 2, '2025-08-06 22:19:43', 'Pending', NULL, NULL, '2025-06-03 11:49:35', 79, NULL, NULL, '2025-08-28 14:48:12', '2025-03-24 13:06:41'),
(11, 10, 9, 8, '2025-08-13 15:20:53', 'Active', NULL, NULL, '2025-03-22 01:37:23', 85, NULL, 'Labore pariatur eligendi dolores. Neque voluptatibus accusantium. Repellat quasi necessitatibus doloribus inventore ad.', '2025-01-22 10:00:18', '2025-09-07 23:02:31'),
(12, 4, 13, 9, '2025-04-27 03:48:49', 'Completed', NULL, '2025-03-30 19:36:22', '2025-07-27 00:04:41', 82, NULL, NULL, '2025-05-19 05:11:24', '2025-04-03 10:42:24'),
(13, 1, 36, 10, '2025-09-05 00:06:36', 'Suspended', 39, '2025-05-06 08:09:31', '2025-04-22 15:08:17', 90, NULL, 'Libero tempora excepturi. Neque quisquam impedit quod sint. Ullam consequuntur odit eaque sit reiciendis error.', '2025-05-20 11:37:37', '2025-07-19 23:08:44'),
(14, 10, 17, 20, '2025-02-06 05:04:58', 'Active', NULL, NULL, '2025-05-30 04:03:42', 27, '2025-02-15 22:11:55', NULL, '2025-05-13 06:09:12', '2025-08-14 22:37:42'),
(15, 8, 42, 11, '2025-04-25 21:00:32', 'Active', 40, NULL, '2025-05-23 11:57:50', 2, NULL, 'Esse architecto tempore. Alias possimus consequatur pariatur rerum voluptatum. Aspernatur voluptatem molestias corporis eos quibusdam.', '2025-09-06 03:02:34', '2025-01-25 07:44:23'),
(16, 1, 2, 12, '2025-05-13 06:00:38', 'Completed', NULL, NULL, '2025-02-02 09:04:59', 61, '2025-07-01 13:29:37', 'Excepturi ex temporibus rem vitae quidem tempore. In magnam necessitatibus eligendi ducimus impedit molestias. Culpa fugiat pariatur perspiciatis.', '2025-06-05 15:14:22', '2025-01-29 04:11:46'),
(17, 4, 27, 20, '2025-03-14 10:57:46', 'Active', 15, NULL, NULL, 87, '2025-05-23 18:12:24', 'Dicta repellendus magni mollitia maxime qui cupiditate eaque.', '2025-03-18 00:51:25', '2025-02-25 06:53:01'),
(18, 10, 35, 3, '2025-01-15 22:38:43', 'Cancelled', NULL, '2025-06-09 03:57:50', NULL, 59, NULL, NULL, '2025-07-03 07:50:45', '2025-01-01 06:39:08'),
(19, 5, 49, 19, '2025-01-04 21:34:10', 'Suspended', NULL, NULL, NULL, 35, NULL, 'Amet similique quis quaerat repellat. Rerum voluptatem eaque nostrum non tempora harum.', '2025-03-15 11:19:07', '2025-08-10 23:02:13'),
(20, 4, 39, 15, '2025-05-28 15:17:38', 'Pending', NULL, NULL, '2025-09-12 05:17:34', 68, '2025-05-04 22:45:26', NULL, '2025-04-30 21:28:13', '2025-07-18 12:10:08'),
(21, 4, 10, 9, '2025-07-25 23:22:29', 'Active', NULL, NULL, '2025-08-02 07:47:00', 74, '2025-05-10 11:06:06', 'Accusamus veniam sapiente est mollitia. Reprehenderit excepturi nulla ad veritatis delectus eaque.', '2025-05-29 13:01:52', '2025-07-07 18:13:03'),
(22, 1, 38, 5, '2025-03-19 10:20:37', 'Active', 46, '2025-09-06 11:30:55', NULL, 40, '2025-07-04 06:50:30', NULL, '2025-08-15 11:56:16', '2025-04-12 14:18:22'),
(23, 7, 32, 11, '2025-09-13 18:45:45', 'Active', NULL, '2025-03-10 12:54:26', '2025-03-29 22:23:36', 94, NULL, 'Itaque rem voluptatem. Amet nostrum fugit repudiandae recusandae.', '2025-04-04 16:10:50', '2025-07-22 02:44:04'),
(24, 5, 4, 17, '2025-07-09 20:45:55', 'Suspended', NULL, '2025-04-17 06:32:15', NULL, 71, '2025-04-24 15:01:05', 'Earum provident a exercitationem distinctio facere. Impedit eaque cum facere nesciunt.', '2025-01-29 16:22:10', '2025-01-28 21:33:53'),
(25, 2, 46, 19, '2025-02-25 23:20:26', 'Cancelled', NULL, NULL, '2025-02-16 17:59:50', 36, NULL, 'Dolore earum assumenda ullam consectetur. Tenetur cum temporibus voluptatum suscipit voluptates.', '2025-02-11 18:31:30', '2025-08-03 05:53:42'),
(26, 3, 10, 15, '2025-04-07 01:22:14', 'Active', 48, NULL, '2025-01-06 13:08:09', 53, NULL, NULL, '2025-05-10 19:47:57', '2025-07-13 18:06:18'),
(27, 1, 30, 10, '2025-01-26 06:01:42', 'Active', 7, NULL, '2025-03-27 13:18:55', 88, '2025-02-12 02:41:28', 'Quas quod ipsa quia omnis ab. Sint sed quis maiores placeat. Fugit suscipit deserunt quos. Totam libero hic quo autem.', '2025-07-22 05:35:21', '2025-05-28 21:43:10'),
(28, 1, 4, 12, '2025-09-01 00:07:36', 'Cancelled', 40, NULL, '2025-05-18 21:24:14', 11, NULL, NULL, '2025-07-30 11:30:32', '2025-03-05 23:09:13'),
(29, 10, 39, 3, '2025-08-18 19:21:25', 'Completed', NULL, '2025-08-02 22:46:36', '2025-04-06 00:33:40', 33, NULL, 'Ducimus at omnis ad nemo. Omnis maxime eligendi debitis iste. Dolores ut rerum dignissimos fuga accusantium voluptates. Quod repellendus fugit.', '2025-02-02 12:12:18', '2025-02-18 16:29:34'),
(30, 8, 10, 6, '2025-04-09 15:48:01', 'Cancelled', 37, NULL, '2025-03-07 21:37:56', 86, '2025-06-26 17:07:33', 'Deserunt suscipit eaque suscipit tenetur. Vel assumenda ratione nobis dicta.', '2025-02-06 12:48:00', '2025-06-25 03:46:23');

INSERT INTO `forum_categories` (`id`, `name`, `description`, `slug`, `created_at`) VALUES
(1, 'Pembahasan Umum', 'Excepturi magnam repudiandae sint perspiciatis. Doloremque iste tempore praesentium exercitationem aspernatur voluptatem. Odio reprehenderit quidem sed aperiam ut quas velit.', 'side-again-year', '2025-01-03 09:39:51'),
(2, 'Pertanyaan Teknis', 'Doloremque quidem sit illum ipsum culpa. Nihil soluta ratione excepturi accusamus adipisci.', 'think-young-scene', '2025-02-02 22:22:22'),
(3, 'Proyek', 'Odio quibusdam dicta accusantium. Quisquam maiores nemo mollitia nihil.', 'easy-hotel-artist', '2025-09-09 13:59:38'),
(4, 'Tips dan Trik', 'Nisi cupiditate officia dignissimos reprehenderit. Incidunt fugiat minus dolores nisi.', 'room-reach-well', '2025-06-29 04:00:15'),
(5, 'Pengumuman', 'Sed molestiae placeat occaecati totam quas veritatis repudiandae. Ratione sequi culpa id. Nostrum perspiciatis ipsa recusandae veritatis fugiat dolor.', 'conference-cause', '2025-07-11 09:41:10');

INSERT INTO `forum_threads` (`id`, `user_id`, `category_id`, `title`, `content`, `views`, `is_pinned`, `created_at`, `updated_at`, `slug`) VALUES
(1, 23, 2, 'Ab nobis id.', 'Velit et eius amet adipisci. Veritatis porro distinctio minima distinctio reiciendis architecto.

Ipsum temporibus architecto saepe delectus nobis. Quae at recusandae.

Tenetur commodi minus omnis nam. Nulla reprehenderit harum totam rerum molestias. Quaerat inventore voluptate amet iusto quo.', 357, 0, '2025-02-05 12:04:11', '2025-02-14 10:32:38', 'rise-serious-great'),
(2, 22, 1, 'Aperiam perferendis quia illo.', 'Blanditiis tenetur aliquid. Tempore voluptatibus quidem quia officiis distinctio a non. Fugiat et autem libero eaque facere dignissimos sunt.

Quaerat cupiditate consectetur error dolorum at iure. Consectetur molestiae soluta harum culpa nisi eius.

Nam perferendis perspiciatis eaque odio accusantium dolorum. Iste recusandae repellendus sunt sunt voluptate deleniti. Facere placeat odit quibusdam fugiat consequuntur doloribus similique.', 924, 1, '2025-03-19 16:31:10', '2025-02-24 22:41:46', 'skin-ten-here'),
(3, 7, 5, 'Sunt hic natus.', 'Pariatur maxime sequi voluptatem. Consectetur voluptas aut facilis pariatur recusandae suscipit. Blanditiis veniam ex vel. Consequatur mollitia necessitatibus ea inventore nesciunt adipisci.

Ipsam sit consequatur. Aspernatur eaque quasi quod et. Laudantium quisquam rem dolorem. Quisquam quibusdam ipsum qui quod corrupti id.

Temporibus hic laboriosam. Vero adipisci nobis nemo accusantium officia quos fuga. Quo nihil omnis magni asperiores nesciunt delectus id. Autem explicabo nulla illo quidem veritatis totam.', 790, 1, '2025-01-07 16:48:30', '2025-03-10 19:51:58', 'scientist'),
(4, 39, 5, 'Cumque ad possimus quia laborum.', 'Ab nostrum eius alias excepturi minus. Aut voluptate illum libero atque. Modi repudiandae explicabo laudantium porro facilis dignissimos.

Animi animi dolor.

Quia fuga consequatur accusamus. Inventore perspiciatis id recusandae necessitatibus.', 579, 0, '2025-04-28 01:29:30', '2025-02-13 11:10:14', 'break-sometimes'),
(5, 11, 4, 'Minus quos cumque soluta.', 'Placeat vitae voluptatem non iusto cumque. Est sunt distinctio cupiditate. Eligendi ratione nihil tempora iste doloribus sapiente.

Ducimus maiores laboriosam possimus magni ut doloribus. Dignissimos aliquid reprehenderit officia possimus id quam. Ea maxime itaque eos ipsum quaerat in praesentium.

Magnam nostrum reiciendis in eum modi. Consequuntur repellat recusandae explicabo. Eveniet nisi architecto velit necessitatibus.', 820, 1, '2025-08-12 18:13:39', '2025-04-10 23:02:56', 'respond-hotel'),
(6, 1, 5, 'Consequuntur adipisci officiis sequi eaque quod sed nihil.', 'Quaerat corporis non. Sunt deserunt autem aliquid. Voluptatibus iure sit accusamus.

Atque velit cum. Culpa blanditiis odit neque repellendus.

Illum suscipit dignissimos beatae porro enim nam. Ducimus accusantium voluptate rerum perspiciatis tempora. Atque dolorem dolorum minus.', 83, 1, '2025-04-14 06:27:08', '2025-03-11 08:55:45', 'model-investment'),
(7, 5, 1, 'Maxime libero dignissimos tenetur.', 'Nam facere perspiciatis fugit rerum provident error. Temporibus facilis beatae. Voluptates cumque ex sapiente.

Nostrum quibusdam repellat laboriosam fugiat facilis. Quo at dolorum asperiores aspernatur dolorum. Unde ex exercitationem voluptates rem ut molestiae.

Saepe animi maxime ratione magni. Animi magnam at quasi ipsam delectus. Illum et ea consequuntur. Accusantium rem assumenda dolore iusto placeat ea aliquam.', 406, 1, '2025-01-30 03:48:36', '2025-06-03 23:30:41', 'series-will-foreign'),
(8, 4, 3, 'Occaecati quisquam eveniet cumque.', 'Aliquam quam harum natus debitis et est. Ea atque quasi facere vitae alias. Et dolorem voluptate magni similique quasi quod voluptatum.

Maiores distinctio occaecati necessitatibus aperiam suscipit voluptatibus. Vero nobis architecto nulla vitae dolorum.

Debitis qui porro rem neque qui quos. Autem nesciunt recusandae doloribus eaque.', 340, 1, '2025-07-07 21:41:51', '2025-01-28 16:52:24', 'bill-position'),
(9, 10, 5, 'Inventore sed magni vitae.', 'Minus doloremque ratione sed perferendis rerum. Minima velit accusamus magnam omnis. Eligendi porro voluptatibus.

Sint similique illum est. Atque corrupti natus at. Nulla veniam reprehenderit at reprehenderit.

Ut vitae accusamus et. Mollitia provident enim nostrum nostrum vitae.', 252, 1, '2025-07-31 02:21:30', '2025-02-26 19:34:17', 'short-how-parent'),
(10, 41, 1, 'Asperiores vitae dolorum error impedit explicabo praesentium.', 'Architecto ducimus labore qui quod delectus corrupti suscipit. Doloribus labore nulla illo commodi. Vel iusto totam repellendus adipisci aspernatur.

Dignissimos sed maiores aut officia. Neque magni voluptatum velit rem.

Tenetur hic maiores quo labore accusantium et. Laborum ex accusantium asperiores laboriosam nesciunt.', 766, 1, '2025-09-04 18:42:04', '2025-04-28 07:52:19', 'require-everything'),
(11, 8, 5, 'Eligendi adipisci rerum id.', 'Repellat assumenda voluptatum aliquam tempore voluptas voluptas.

Non dolorum deserunt dolor dolores fugiat. Numquam quos illum natus enim.

Dolorem molestiae quod tenetur. Magnam labore aut ad quos temporibus eius. Et assumenda sunt accusantium.', 799, 0, '2025-02-18 11:03:05', '2025-05-12 06:50:13', 'buy-environment'),
(12, 10, 5, 'Officiis magnam quas officia eos in iusto.', 'Adipisci adipisci corrupti nisi eum voluptas esse. Natus nihil velit nulla.

Cum tempore laudantium quia. Nisi voluptas ratione a voluptatem quis.

Error repellendus maxime aspernatur ea doloribus numquam delectus. Reprehenderit officiis ipsam veritatis officia modi cum dignissimos. Quibusdam officiis iure illum odit cupiditate quae.', 487, 1, '2025-04-09 19:18:18', '2025-02-16 15:24:45', 'out-data-leave'),
(13, 5, 3, 'Suscipit natus alias ab quidem quidem.', 'Facilis quod numquam quia. Perferendis rerum quisquam assumenda deleniti.

Eius dolores voluptatum sapiente saepe consequuntur. Excepturi laboriosam veritatis similique cum reiciendis aperiam voluptatem.

Eaque dolorum debitis laborum velit. Perspiciatis inventore ullam debitis sed facere. Placeat tenetur itaque reprehenderit fugit sunt deserunt.', 169, 0, '2025-05-23 11:52:14', '2025-01-07 09:58:06', 'bit-environmental'),
(14, 48, 3, 'Dignissimos vero iure dolore impedit cumque deserunt excepturi.', 'Illum hic dolor eos fugit nam doloremque. Ipsa incidunt nobis maxime mollitia ut.

In tempora recusandae sed ex dolores. Velit expedita minus nemo nostrum pariatur.

Mollitia tempore blanditiis exercitationem. Officia molestias assumenda non placeat ipsa.', 704, 0, '2025-06-21 08:57:04', '2025-04-28 06:00:48', 'become-age-indeed'),
(15, 22, 1, 'Cum expedita nisi ipsa exercitationem.', 'Harum voluptatibus hic laboriosam libero harum.

Architecto illum veritatis vel ad fugiat. Aliquid repudiandae necessitatibus mollitia natus.

Sequi eveniet voluptate est tenetur nemo temporibus. Repellendus pariatur in doloribus placeat.', 101, 1, '2025-07-07 21:55:56', '2025-03-20 02:57:11', 'believe-us-game'),
(16, 6, 5, 'Saepe autem laborum hic atque quod.', 'Hic quaerat suscipit distinctio. Exercitationem atque quibusdam placeat rem quis.

Alias ipsam asperiores. Voluptatum velit tempore dolores delectus.

Sed dolorum possimus.', 68, 1, '2025-02-28 00:23:42', '2025-01-24 02:07:23', 'see-research-such'),
(17, 20, 2, 'Natus quo fuga totam deserunt laudantium praesentium.', 'Magnam mollitia saepe consequuntur hic.

Sunt beatae quaerat.

Illum fugiat autem hic labore nulla. Dignissimos nesciunt sint dolorem nihil ducimus itaque.', 175, 1, '2025-07-20 04:34:45', '2025-03-11 10:37:06', 'either-your-he-than'),
(18, 23, 4, 'Placeat ipsum praesentium ullam modi ratione.', 'Officia eius velit error. Dolores nostrum optio facere architecto ipsa vero. Voluptates cumque quod illum omnis.

Ab velit odit similique optio occaecati. Architecto blanditiis modi.

Placeat doloremque id nulla aliquid. Architecto nulla corrupti suscipit assumenda a modi.', 315, 0, '2025-07-24 02:12:32', '2025-08-30 00:35:29', 'attorney-music'),
(19, 29, 2, 'Officia totam doloribus officiis necessitatibus eveniet.', 'Vero adipisci porro deserunt eligendi illum velit. Maiores aliquid sit consequuntur.

Commodi soluta iusto dicta molestiae possimus eum. Minus quam numquam nulla beatae dolorum.

Autem libero corrupti minima est harum. Sequi animi repellat sint molestias non hic. Velit sint commodi provident.', 697, 0, '2025-04-08 01:33:12', '2025-08-06 23:41:35', 'put-fly-character'),
(20, 50, 2, 'Aperiam praesentium praesentium perferendis minus.', 'Quae a dolorum molestias totam illo occaecati earum. Atque nulla amet.

Ullam quo voluptatem perferendis rem. Quod dicta reiciendis officiis consequatur deserunt laborum. Explicabo id magnam vitae.

Reprehenderit pariatur molestiae hic expedita. Accusamus voluptates sit animi. Aut eum nostrum ut. Dignissimos enim enim tempore.', 516, 0, '2025-05-16 23:30:48', '2025-07-14 10:29:43', 'rather-through');

INSERT INTO `forum_posts` (`id`, `thread_id`, `user_id`, `parent_id`, `content`, `created_at`, `updated_at`) VALUES
(1, 18, 16, NULL, 'Laudantium tenetur corrupti dolores nesciunt. A quam officiis beatae.', '2025-06-07 06:04:34', '2025-06-19 20:04:32'),
(2, 14, 10, NULL, 'Ea non asperiores nostrum aut necessitatibus. Laboriosam ipsa quibusdam necessitatibus. Cupiditate animi minima ducimus quia odio.', '2025-03-20 21:04:21', '2025-05-07 13:31:09'),
(3, 12, 33, NULL, 'Exercitationem explicabo ipsum consectetur. Ducimus quos cupiditate inventore animi sapiente.', '2025-01-08 23:53:29', '2025-01-16 03:57:10'),
(4, 8, 35, NULL, 'Quae et doloremque fuga nesciunt maiores veniam.', '2025-05-22 01:27:14', '2025-02-24 10:52:40'),
(5, 9, 20, 3, 'Saepe laborum ratione similique deserunt ducimus deserunt. Harum perferendis ex asperiores.', '2025-02-10 13:22:44', '2025-02-21 23:13:13'),
(6, 1, 36, NULL, 'Aspernatur cupiditate tempore recusandae quo.', '2025-06-07 10:10:32', '2025-06-23 06:33:46'),
(7, 6, 43, NULL, 'Hic sequi reprehenderit aliquid molestias animi. Est itaque blanditiis incidunt facilis reiciendis dolore enim. Rem recusandae sit adipisci quis autem nulla.', '2025-06-25 21:51:18', '2025-01-24 14:11:44'),
(8, 16, 48, NULL, 'Eveniet adipisci eligendi quibusdam. Inventore molestiae asperiores repudiandae architecto. Ad suscipit ullam nam laudantium ab beatae expedita.', '2025-07-31 23:57:34', '2025-09-10 16:55:33'),
(9, 13, 3, NULL, 'Expedita ut animi doloribus vel vitae dolorum. Earum maxime modi et. Aperiam at possimus nihil hic maiores incidunt.', '2025-05-07 06:31:43', '2025-06-16 17:39:37'),
(10, 20, 50, NULL, 'Dolore quisquam dicta eius hic minima assumenda voluptate. Ab quibusdam officiis unde nobis distinctio facilis. Ullam cumque dolore eligendi laboriosam rerum.', '2025-02-12 14:31:08', '2025-04-09 03:23:00'),
(11, 9, 48, 7, 'Quidem voluptatum temporibus illo ullam.', '2025-01-03 19:27:26', '2025-05-08 19:28:43'),
(12, 8, 24, NULL, 'Omnis at enim est nostrum aliquam.', '2025-06-10 18:18:58', '2025-09-04 13:18:33'),
(13, 9, 25, 8, 'Autem omnis nisi. Ab esse itaque ab amet asperiores. Tempora officiis ullam recusandae veniam nostrum harum laudantium.', '2025-06-24 21:34:31', '2025-07-22 18:06:50'),
(14, 4, 49, 7, 'Quis aspernatur mollitia ad recusandae officia. Inventore ad fugit ab deserunt adipisci iure dignissimos. Nobis optio impedit atque ipsam enim. Et iste cupiditate quam voluptates non.', '2025-03-29 20:26:14', '2025-08-25 05:24:09'),
(15, 18, 31, NULL, 'Suscipit reiciendis nam dolorem magnam. Rerum reprehenderit similique.', '2025-08-01 18:26:53', '2025-02-15 23:09:50'),
(16, 4, 42, 4, 'Eligendi consequatur aliquam. Beatae voluptatem deleniti eligendi quibusdam cupiditate corrupti ipsa.', '2025-07-01 20:23:27', '2025-09-05 05:04:31'),
(17, 5, 26, 11, 'Reprehenderit accusantium facilis omnis reiciendis unde. Debitis repellat possimus veniam.', '2025-06-18 12:58:06', '2025-03-31 03:18:05'),
(18, 18, 11, NULL, 'Nemo recusandae quo sed. Inventore ex praesentium nesciunt sunt nesciunt. Laudantium optio voluptas hic in doloribus ab.', '2025-01-29 16:53:33', '2025-01-10 02:52:31'),
(19, 4, 47, NULL, 'Dolorum adipisci eum. Consequatur labore ex. Perspiciatis corrupti a.', '2025-01-28 20:30:53', '2025-01-07 06:07:07'),
(20, 5, 40, 6, 'Accusamus atque quidem quasi saepe. Alias natus architecto nihil minus. Possimus alias doloremque deleniti architecto quasi. Ducimus libero ut eligendi dolorum minima facilis.', '2025-08-24 23:51:24', '2025-03-29 19:56:09'),
(21, 9, 4, 11, 'Reiciendis cum beatae delectus officiis.', '2025-05-20 01:05:26', '2025-02-08 03:42:48'),
(22, 9, 42, NULL, 'Qui sunt et eligendi mollitia. Sequi vel illum accusamus. Deleniti amet eaque reiciendis officia.', '2025-02-11 08:06:22', '2025-05-29 02:41:39'),
(23, 14, 41, NULL, 'Earum atque magni corrupti suscipit nemo vel. Voluptates impedit dolores nam impedit perferendis dolorem. Eius quasi iure optio.', '2025-07-28 08:01:33', '2025-05-10 17:05:09'),
(24, 3, 5, 22, 'Quos eaque saepe aut commodi voluptas consequatur. Nostrum a at distinctio iure quos.', '2025-07-17 07:20:45', '2025-07-21 15:57:13'),
(25, 4, 44, 13, 'Quae sunt optio consequuntur fuga voluptatum. Eius impedit tempore eaque quia.', '2025-01-05 00:37:04', '2025-08-09 00:11:48'),
(26, 8, 10, 20, 'Adipisci natus aspernatur reprehenderit aliquam saepe corporis. Numquam harum doloremque dolorem sint error. Harum minima doloribus accusantium omnis libero.', '2025-08-01 07:03:44', '2025-04-22 04:55:44'),
(27, 12, 19, NULL, 'Neque rerum delectus repellendus.', '2025-02-25 11:09:07', '2025-05-09 11:08:19'),
(28, 10, 1, NULL, 'Cumque voluptatibus quos esse nisi placeat. Ab alias cupiditate porro iusto quis accusantium nulla.', '2025-02-25 20:31:46', '2025-07-01 16:27:23'),
(29, 6, 18, 17, 'Error sint dicta consectetur voluptas temporibus iste. Inventore inventore quidem amet provident deserunt debitis. Maxime ratione fugiat doloremque esse.', '2025-02-17 02:13:05', '2025-01-29 01:42:05'),
(30, 10, 15, NULL, 'Praesentium iste nesciunt culpa autem. Ex ipsam quae illo.', '2025-02-15 16:14:04', '2025-06-12 21:02:06'),
(31, 17, 5, 9, 'Facere odio at magni eveniet possimus. Quas dicta voluptatibus impedit est. Et doloremque quod similique culpa. Minima asperiores est quae cupiditate aut voluptas.', '2025-07-08 00:26:14', '2025-08-14 17:58:13'),
(32, 16, 48, NULL, 'Culpa dolores dolor nam. Reiciendis dolor nesciunt iusto veniam veritatis ea.', '2025-02-24 05:52:58', '2025-08-28 18:32:15'),
(33, 20, 25, NULL, 'Similique architecto expedita culpa pariatur natus vel. Molestias esse nulla itaque pariatur illum.', '2025-04-30 15:23:52', '2025-04-18 21:49:04'),
(34, 16, 41, NULL, 'Iure quaerat commodi. Nam aut suscipit quo non omnis laborum. Suscipit quo iure nulla perferendis.', '2025-02-26 08:38:43', '2025-04-17 23:15:27'),
(35, 9, 45, 13, 'Architecto vitae vero occaecati pariatur dolorem minus. Tenetur atque placeat assumenda exercitationem. Placeat rerum ex nam.', '2025-03-01 23:24:05', '2025-01-12 20:38:06'),
(36, 8, 46, 24, 'Odio debitis ab aperiam dolores dolorum. Tempora repellat ut illo quis voluptate maiores. Molestias quod veritatis rem maiores numquam reiciendis.', '2025-06-25 07:42:32', '2025-05-28 09:43:39'),
(37, 5, 12, NULL, 'Saepe earum fugiat voluptas possimus sed. Dolor dolor assumenda iste similique at at.', '2025-07-04 13:27:24', '2025-07-13 05:38:57'),
(38, 11, 14, NULL, 'Deserunt ad aperiam inventore suscipit aspernatur. Rerum error voluptate reiciendis aliquid odio at. Debitis amet laboriosam voluptates error ratione harum.', '2025-04-27 23:10:37', '2025-03-19 20:11:12'),
(39, 12, 36, NULL, 'In ad ea nemo atque ullam cupiditate asperiores. Beatae similique quidem tempora laborum possimus deserunt. Dolores voluptates sit ullam.', '2025-01-28 20:19:54', '2025-07-31 09:29:48'),
(40, 3, 24, NULL, 'Nihil quis cum asperiores autem aut.', '2025-01-24 21:35:46', '2025-03-18 14:17:53'),
(41, 3, 38, NULL, 'Debitis eligendi dolor dolores odio occaecati consectetur. Numquam occaecati dolorum maiores est reiciendis fugiat. Nulla ipsum doloremque modi laborum temporibus sapiente cumque.', '2025-03-01 04:55:06', '2025-04-12 13:28:22'),
(42, 6, 42, 27, 'Enim delectus dicta. Illum commodi sunt animi magnam voluptate voluptatem.', '2025-05-15 16:25:07', '2025-02-04 12:14:34'),
(43, 10, 35, 15, 'Tempora nisi magnam ea in similique. At quam itaque delectus necessitatibus eos.', '2025-04-08 15:43:31', '2025-07-18 02:30:54'),
(44, 14, 49, NULL, 'Sint possimus optio quod tempore voluptatum quos eius.', '2025-08-27 09:07:25', '2025-05-30 20:50:50'),
(45, 19, 12, NULL, 'Fugit excepturi laudantium beatae voluptatem velit neque. Nisi itaque dolores assumenda maxime.', '2025-01-20 10:30:34', '2025-07-16 10:05:52'),
(46, 15, 17, NULL, 'Repellendus quisquam inventore quisquam incidunt. Voluptatum nobis alias omnis dolores labore velit.', '2025-02-27 19:41:59', '2025-05-21 19:31:19'),
(47, 5, 50, 21, 'Ea harum ad distinctio dolorem. Voluptas at et qui numquam recusandae quod. Modi voluptatum illum molestiae. Blanditiis dolores possimus autem facere ullam sed.', '2025-09-14 14:21:41', '2025-09-10 07:19:53'),
(48, 11, 47, NULL, 'Dolores doloremque ipsum rerum dignissimos rem vero. Qui eius delectus suscipit quidem. Accusantium voluptatibus eum enim labore animi.', '2025-02-09 19:02:02', '2025-08-30 19:56:49'),
(49, 4, 10, NULL, 'Voluptatum asperiores accusamus at recusandae. Necessitatibus quisquam eaque amet. Cumque autem a quaerat voluptates. Laborum quasi eligendi non temporibus.', '2025-07-29 17:06:33', '2025-06-17 19:25:19'),
(50, 14, 30, NULL, 'Deserunt debitis soluta quod optio voluptatibus. Repellat nisi sequi quibusdam suscipit veniam laudantium.', '2025-03-12 06:37:17', '2025-05-04 04:59:32'),
(51, 14, 31, NULL, 'Excepturi eveniet quasi sed nihil sint tempora. Autem repellat quae perspiciatis vitae illum occaecati.', '2025-08-15 05:11:57', '2025-07-04 19:28:50'),
(52, 18, 36, NULL, 'Magni asperiores aspernatur repellat accusantium. Nulla quo dolorem accusantium id harum illum.', '2025-07-01 05:07:08', '2025-02-23 05:10:51'),
(53, 9, 17, NULL, 'Deleniti illum atque. Quisquam ut tempore pariatur porro. Sapiente facilis aliquam aperiam.', '2025-08-25 15:54:41', '2025-07-04 13:54:29'),
(54, 20, 3, NULL, 'Recusandae pariatur provident occaecati sunt accusantium. Ea excepturi doloribus reprehenderit. Totam alias accusantium quas similique.', '2025-02-15 15:06:27', '2025-01-03 13:06:07'),
(55, 13, 35, NULL, 'Expedita ea praesentium vitae modi quia eaque. Temporibus ratione veritatis doloribus nam labore voluptate numquam.', '2025-08-26 15:16:29', '2025-01-12 06:19:50'),
(56, 16, 42, NULL, 'Numquam doloremque iure fugit unde explicabo quia. Aperiam enim hic quia earum aut dignissimos. Velit sunt accusantium quaerat natus harum neque.', '2025-07-20 09:57:50', '2025-04-04 04:46:17'),
(57, 2, 17, NULL, 'Unde et quam atque architecto voluptatum. Ut dolor nihil cum quisquam numquam distinctio necessitatibus.', '2025-05-13 16:11:10', '2025-03-25 12:35:54'),
(58, 5, 36, NULL, 'Tempora distinctio sint porro. Eveniet amet commodi incidunt. Delectus et voluptates perferendis.', '2025-02-25 05:11:05', '2025-01-28 19:58:41'),
(59, 15, 38, NULL, 'Quisquam unde accusamus voluptatem.', '2025-08-08 04:39:57', '2025-06-14 08:24:53'),
(60, 15, 29, NULL, 'Possimus neque culpa earum incidunt necessitatibus. Numquam asperiores reiciendis nemo consequatur. Quibusdam totam aliquid dolorem. Atque minima corrupti cupiditate dolor dolorum.', '2025-05-30 07:26:15', '2025-05-16 19:18:51'),
(61, 5, 6, NULL, 'Expedita alias deleniti eius iste.', '2025-01-06 02:07:58', '2025-03-29 08:42:49'),
(62, 19, 32, NULL, 'Praesentium doloribus quibusdam quibusdam odit. Totam voluptate aliquam provident magnam officiis nam.', '2025-08-16 08:32:12', '2025-07-15 23:46:41'),
(63, 18, 24, NULL, 'Incidunt itaque enim sequi. Consectetur animi ab.', '2025-04-13 11:49:22', '2025-02-10 00:20:25'),
(64, 17, 48, NULL, 'Natus iure ipsum natus quae. Deleniti ex voluptas aspernatur aliquid accusamus temporibus officiis.', '2025-07-03 12:59:20', '2025-04-17 05:54:14'),
(65, 3, 40, 14, 'Ipsa eius alias temporibus distinctio suscipit quasi repudiandae. In quod ad quo maxime neque fugiat suscipit.', '2025-05-22 19:32:26', '2025-06-16 02:04:33'),
(66, 20, 46, NULL, 'Dolores numquam explicabo eligendi. Cupiditate nihil porro eveniet.', '2025-04-20 09:00:06', '2025-03-01 09:39:40'),
(67, 9, 1, NULL, 'Totam nihil mollitia quo officiis at facilis. Delectus consequatur omnis maxime.', '2025-08-19 04:39:35', '2025-05-27 18:14:56'),
(68, 20, 21, NULL, 'Soluta eum doloribus culpa culpa. Id maxime adipisci incidunt ab repellendus inventore.', '2025-01-26 05:13:50', '2025-06-10 23:28:12'),
(69, 19, 43, 54, 'Nihil consequuntur tempore veniam eaque. Atque sint unde.', '2025-06-14 07:14:35', '2025-02-16 16:01:24'),
(70, 16, 38, 56, 'Assumenda modi quam odit dolore molestias. Eveniet assumenda sed quas. Consectetur repellendus dolorum reprehenderit in cupiditate maiores.', '2025-08-26 05:15:09', '2025-08-18 12:02:07'),
(71, 19, 45, NULL, 'Quibusdam quis molestiae enim modi adipisci nam. Molestias eaque assumenda quam temporibus est expedita eaque. Tempore necessitatibus sapiente voluptatum officia quod doloremque.', '2025-04-05 14:40:55', '2025-08-26 07:13:27'),
(72, 6, 23, 22, 'Nesciunt cumque eos a blanditiis quibusdam officia minus. Ipsam repellat natus.', '2025-07-12 00:49:27', '2025-07-31 22:09:44'),
(73, 12, 36, NULL, 'Magnam illo adipisci hic eligendi expedita. Dolor sapiente ut excepturi odit. Vero quod ut fuga tempora placeat aperiam.', '2025-03-20 23:39:34', '2025-04-13 14:27:36'),
(74, 20, 14, NULL, 'Laudantium accusantium amet eius eius adipisci maiores. Itaque itaque ipsam eveniet.', '2025-06-17 04:55:26', '2025-06-15 07:48:16'),
(75, 3, 50, 53, 'Natus ut temporibus ipsam inventore velit. Velit recusandae iste provident maxime neque laudantium quos.', '2025-03-17 23:20:11', '2025-03-20 06:18:48'),
(76, 13, 23, NULL, 'Consequatur magni minus iure libero. Architecto fugiat quo amet neque alias. Pariatur magni sequi.', '2025-03-03 08:28:08', '2025-01-26 02:50:07'),
(77, 7, 24, 74, 'Id error aliquam earum facere voluptatem. Cupiditate nobis assumenda numquam. Quos in cum suscipit. Adipisci recusandae tenetur.', '2025-09-12 13:47:08', '2025-03-07 19:02:08'),
(78, 13, 24, 40, 'Similique facere quisquam suscipit modi. Dolores ipsa doloribus veritatis eveniet porro.', '2025-06-07 02:28:12', '2025-09-03 14:24:37'),
(79, 1, 4, NULL, 'Unde aut eum fugit modi odio. In illo harum quas.', '2025-02-10 18:59:13', '2025-01-31 20:03:08'),
(80, 19, 23, NULL, 'In illum non neque.', '2025-08-08 19:33:45', '2025-08-29 15:44:39'),
(81, 8, 36, 64, 'Sit debitis laboriosam voluptas eos hic. Repudiandae aperiam eius quasi cupiditate nisi.', '2025-01-18 02:38:01', '2025-04-11 11:57:55'),
(82, 7, 8, NULL, 'Architecto vero cumque ea. Excepturi unde recusandae praesentium. Recusandae provident non temporibus quis laborum vel cumque.', '2025-09-02 02:43:58', '2025-04-19 03:04:20'),
(83, 3, 49, NULL, 'Nobis corrupti amet. Molestiae officiis hic.', '2025-06-16 13:51:53', '2025-08-19 02:20:21'),
(84, 9, 46, 60, 'Ad laboriosam veniam qui labore suscipit et. Quis nesciunt totam eaque qui repellendus deleniti. Repellat qui maiores rem pariatur.', '2025-05-13 12:11:29', '2025-04-28 16:25:41'),
(85, 18, 33, NULL, 'Iure magni tempora velit veniam tempore.', '2025-05-15 01:42:00', '2025-01-20 20:16:25'),
(86, 19, 36, NULL, 'Nihil quibusdam ducimus optio ullam nisi veniam. Molestias rem repellat suscipit.', '2025-01-18 17:59:45', '2025-02-19 10:51:51'),
(87, 4, 3, NULL, 'Tenetur illum eveniet consequatur ex dolorum. Excepturi atque inventore culpa fuga in aliquam facilis. Soluta sapiente temporibus at vero laudantium soluta.', '2025-06-02 09:18:29', '2025-03-25 07:06:20'),
(88, 13, 45, NULL, 'Animi beatae quidem impedit. Ratione alias voluptatem.', '2025-08-30 18:53:12', '2025-07-30 14:52:25'),
(89, 5, 10, NULL, 'Neque natus omnis officiis. Sint laudantium voluptatum ut sed fugit.', '2025-04-22 02:03:24', '2025-08-02 12:05:30'),
(90, 12, 2, NULL, 'Consectetur natus officiis dolores itaque sunt. Suscipit itaque sint vero illo eligendi amet ea.', '2025-02-27 11:45:25', '2025-02-15 04:32:07'),
(91, 20, 3, 33, 'Dolores ea recusandae quas id velit. Consequatur molestiae iste placeat harum. Eligendi provident mollitia eveniet doloremque.', '2025-09-07 16:24:31', '2025-01-09 10:58:52'),
(92, 5, 34, 46, 'Repellendus deserunt totam velit velit unde impedit. Tempora quidem corporis ullam.', '2025-03-28 02:34:26', '2025-04-11 13:30:42'),
(93, 9, 28, NULL, 'Voluptatum rerum eveniet sunt quod explicabo. Possimus soluta ratione repellat. A dolore officiis laborum.', '2025-01-10 17:31:40', '2025-04-18 07:28:02'),
(94, 11, 21, NULL, 'Numquam cumque libero molestias. Soluta fugit tenetur.', '2025-06-27 07:19:35', '2025-04-01 03:08:08'),
(95, 8, 35, 28, 'Totam quis labore cum. Inventore rerum tempore aliquid asperiores nesciunt.', '2025-04-23 00:42:21', '2025-01-12 13:39:09'),
(96, 20, 2, NULL, 'Nostrum ipsam impedit natus quos veritatis.', '2025-01-21 11:41:19', '2025-01-15 20:49:56'),
(97, 9, 30, NULL, 'Dolores officiis repellat consequatur totam optio. Aliquam molestias animi iusto dicta rerum aliquam quas.', '2025-08-11 09:23:27', '2025-09-04 21:26:20'),
(98, 14, 33, 46, 'Nihil explicabo expedita ipsum temporibus. Corrupti perspiciatis commodi.', '2025-05-25 03:03:41', '2025-07-05 22:44:35'),
(99, 1, 46, NULL, 'Quisquam iure aperiam inventore recusandae. Mollitia totam similique ipsum consequatur.', '2025-08-20 22:57:37', '2025-08-30 12:27:25'),
(100, 18, 16, NULL, 'Corrupti aperiam eos. Dolor eligendi adipisci placeat eius. Et earum asperiores voluptatibus itaque ab.', '2025-09-02 15:07:10', '2025-01-04 12:22:32');

INSERT INTO `free_classes` (`id`, `title`, `description`, `thumbnail`, `level`, `category`, `duration`, `mentor_id`, `max_students`, `start_date`, `end_date`, `status`, `online_meet_link`, `created_at`, `updated_at`) VALUES
(1, 'Ipsa placeat qui iure.', 'Nihil nam nemo error eum quas ducimus numquam. Delectus molestiae fuga a ullam tenetur. Porro unde est eaque deserunt quos laudantium doloremque.

Quam eum ab earum nihil. Dolore voluptatum veniam sequi non. Praesentium laudantium ducimus autem modi esse nihil.', NULL, 'Menengah', 'Python', 6, NULL, NULL, '2025-01-10', '2025-08-23', 'Archived', NULL, '2025-09-11 11:24:26', '2025-03-22 11:12:35'),
(2, 'Nemo laboriosam tempore delectus iusto ratione quisquam.', 'Alias similique dolore quasi. Earum mollitia quis ratione.

Neque officiis nihil molestiae laborum. Maxime perferendis qui ea cumque rem. Cumque minus nemo rem architecto esse voluptatum.', '/uploads/classes/free_2.jpg', 'Lanjutan', 'Python', 7, NULL, 100, '2025-07-29', '2025-05-20', 'Published', 'https://pt.my.id/', '2025-07-07 05:17:49', '2025-05-27 02:10:45'),
(3, 'Temporibus voluptatem accusamus.', 'Fugiat dolores explicabo maxime possimus. Beatae rerum quasi reiciendis vitae corporis sapiente totam. Incidunt aliquam provident aliquid accusantium.

Delectus ad impedit totam tempora deserunt. Alias quaerat nisi perspiciatis soluta placeat. A nobis vitae blanditiis.', NULL, 'Lanjutan', 'Web Development', 6, 10, NULL, '2025-05-29', '2025-09-02', 'Published', NULL, '2025-02-23 17:25:51', '2025-09-11 02:29:44'),
(4, 'Saepe vero laudantium consequatur ea corrupti expedita.', 'Iusto maxime molestias sapiente incidunt nostrum similique. Recusandae magni mollitia ipsa vero. Ex minus unde voluptates quo.

Provident nihil qui doloremque dicta adipisci consectetur. Sapiente eius accusamus cum.', '/uploads/classes/free_4.jpg', 'Menengah', 'Python', 6, NULL, 91, '2025-01-28', '2025-02-02', 'Published', NULL, '2025-08-17 20:33:55', '2025-04-12 08:39:00'),
(5, 'Fugit quos magni molestias magni hic.', 'Dolorum molestiae rerum nostrum fugit. At laudantium molestias maiores veniam nulla ut. Similique aliquid aliquid et iste.

Et ea ut ex assumenda.', '/uploads/classes/free_5.jpg', 'Menengah', 'Data Science', 6, NULL, NULL, '2025-06-07', '2025-04-01', 'Draft', NULL, '2025-04-01 17:54:03', '2025-03-16 03:19:25'),
(6, 'Odio quam ab placeat sequi illo.', 'Impedit repellendus provident nemo quo id esse. Suscipit provident quidem temporibus.

Odio facere tempora. Voluptatem quos sed dignissimos assumenda. Facilis reprehenderit quibusdam doloribus.', NULL, 'Menengah', 'Mobile Development', 1, NULL, 73, '2025-06-26', '2025-06-07', 'Published', NULL, '2025-07-18 08:26:14', '2025-02-13 06:20:00'),
(7, 'In doloribus mollitia dolores.', 'Sit necessitatibus impedit minus. Quae nisi vitae iste accusantium illum. Ipsa unde quos molestias inventore consectetur minus.

Sequi iure debitis iusto. Nesciunt distinctio cum amet dignissimos iure aperiam. Sint odit porro autem doloremque.', '/uploads/classes/free_7.jpg', 'Dasar', 'Web Development', 6, NULL, 28, '2025-02-23', '2025-01-23', 'Published', NULL, '2025-08-28 14:55:48', '2025-04-08 02:03:37'),
(8, 'Sit quasi vitae dicta.', 'Illum laudantium iusto quae laboriosam. Hic provident autem optio.

Occaecati dolore laboriosam esse laudantium. Error fuga ullam. Omnis ab repudiandae sit enim cum earum. Repellat suscipit ea nesciunt repellendus explicabo.', NULL, 'Dasar', 'Mobile Development', 3, NULL, NULL, '2025-07-27', '2025-01-29', 'Draft', NULL, '2025-05-14 19:01:34', '2025-06-09 21:31:40'),
(9, 'Repellat laboriosam quia explicabo aperiam dicta.', 'Tempore recusandae tenetur quae repellat fugiat. Vitae nesciunt maiores ad sequi.

Debitis asperiores necessitatibus assumenda. Occaecati nam totam dolores dolor maiores.', NULL, 'Dasar', 'Python', 3, 30, 91, '2025-07-18', '2025-03-23', 'Published', NULL, '2025-07-09 06:18:05', '2025-05-21 16:47:28'),
(10, 'Placeat asperiores provident id a.', 'Modi dolor ipsum provident quisquam ex minus. Nobis recusandae aliquid.

Magni ex laudantium nobis vel. Ad deleniti quibusdam doloremque nemo. Ratione quae repudiandae adipisci veritatis nostrum.', '/uploads/classes/free_10.jpg', 'Menengah', 'Mobile Development', 5, 12, 83, '2025-01-04', '2025-08-01', 'Draft', 'https://cv.gov/', '2025-04-29 06:12:06', '2025-05-13 03:48:57'),
(11, 'Laborum adipisci commodi alias facere odio.', 'Fugiat doloremque nostrum sit labore. Blanditiis minus atque ullam minus reiciendis optio.

Unde aliquid hic quos et atque a quasi. Temporibus possimus nemo tenetur assumenda recusandae nulla rem. Ipsa corporis earum enim eligendi. Cumque incidunt repellendus dolorum veniam.', '/uploads/classes/free_11.jpg', 'Menengah', 'Python', 3, NULL, NULL, '2025-07-28', '2025-05-29', 'Draft', NULL, '2025-04-18 00:55:55', '2025-08-09 23:50:04'),
(12, 'Hic incidunt sit natus nobis omnis.', 'Nam similique delectus id. Ratione quasi error nulla id consequuntur.

Neque cupiditate doloremque quas quidem possimus. Assumenda ipsam fuga exercitationem consequuntur. Eum ipsum eaque qui explicabo.', NULL, 'Lanjutan', 'JavaScript', 6, NULL, NULL, '2025-08-16', '2025-07-10', 'Archived', NULL, '2025-03-10 01:59:40', '2025-02-03 20:53:01'),
(13, 'Repellendus ut omnis placeat nulla cupiditate tenetur aspernatur.', 'Et assumenda atque iusto fugit nostrum architecto. Asperiores animi sint dignissimos nemo maiores. Sint beatae ea.

Provident debitis optio fugit labore nihil hic maxime. Magnam cumque inventore voluptate.', NULL, 'Menengah', 'Mobile Development', 4, NULL, 20, '2025-07-15', '2025-07-06', 'Archived', 'https://ud.ponpes.id/', '2025-05-20 05:44:13', '2025-06-25 01:37:13'),
(14, 'Quam adipisci explicabo fugit eveniet impedit cupiditate fuga.', 'Harum aspernatur quia impedit inventore assumenda cupiditate. Cum cum odio laudantium minus tempore nemo. Saepe rem perspiciatis amet distinctio.

Asperiores nulla quam itaque rerum. Veniam magni nostrum eos porro voluptatum. Eos blanditiis quo aspernatur ea.', NULL, 'Dasar', 'Mobile Development', 8, NULL, NULL, '2025-06-02', '2025-04-09', 'Archived', NULL, '2025-05-03 10:17:52', '2025-07-14 03:44:59'),
(15, 'Vel fugit tenetur officia consectetur ipsum.', 'Nemo laudantium enim earum.

Nam eum ab consectetur. Possimus quas repudiandae numquam.', NULL, 'Menengah', 'Mobile Development', 5, NULL, NULL, '2025-06-11', '2025-01-17', 'Published', NULL, '2025-05-12 19:04:33', '2025-03-04 00:17:28');

INSERT INTO `free_class_enrollments` (`id`, `class_id`, `student_id`, `enrollment_date`, `status`, `progress`, `completion_date`, `created_at`, `updated_at`) VALUES
(1, 6, 10, '2025-03-06 15:36:40', 'Dropped', 83, NULL, '2025-07-07 11:17:22', '2025-06-19 00:01:31'),
(2, 1, 49, '2025-01-26 02:46:12', 'Completed', 87, NULL, '2025-06-19 01:26:08', '2025-06-22 13:21:12'),
(3, 9, 24, '2025-04-28 15:20:17', 'Completed', 78, '2025-09-03 23:19:40', '2025-08-31 09:43:03', '2025-07-23 04:55:52'),
(4, 1, 10, '2025-04-04 11:48:18', 'Enrolled', 74, '2025-03-31 22:05:51', '2025-08-22 15:28:39', '2025-05-19 13:22:52'),
(5, 13, 18, '2025-08-02 20:07:50', 'Enrolled', 66, NULL, '2025-02-24 04:55:16', '2025-07-23 05:25:17'),
(6, 9, 43, '2025-01-15 13:43:23', 'Dropped', 34, NULL, '2025-05-14 14:11:21', '2025-07-09 09:54:21'),
(7, 8, 28, '2025-05-08 13:39:45', 'Dropped', 56, '2025-02-26 17:12:49', '2025-02-08 00:32:39', '2025-08-01 00:20:17'),
(8, 14, 27, '2025-02-16 11:58:49', 'Enrolled', 78, '2025-03-28 04:18:37', '2025-03-10 17:35:39', '2025-06-04 02:40:41'),
(9, 14, 25, '2025-01-23 08:25:18', 'Enrolled', 100, '2025-07-15 23:04:58', '2025-05-21 14:51:34', '2025-04-25 21:53:18'),
(10, 9, 40, '2025-03-15 01:49:32', 'Completed', 56, '2025-05-11 03:12:16', '2025-05-15 11:28:46', '2025-04-16 21:45:44'),
(11, 13, 7, '2025-06-14 21:18:33', 'Completed', 42, '2025-07-26 14:38:13', '2025-05-20 02:30:34', '2025-06-22 13:23:23'),
(12, 6, 6, '2025-08-22 14:25:50', 'Enrolled', 82, NULL, '2025-01-04 17:36:08', '2025-04-24 04:47:53'),
(13, 15, 5, '2025-07-11 05:38:21', 'Enrolled', 48, '2025-08-12 12:53:56', '2025-06-04 06:39:45', '2025-03-06 01:21:21'),
(14, 5, 18, '2025-09-08 01:48:34', 'Enrolled', 24, NULL, '2025-02-14 21:20:28', '2025-01-08 03:38:28'),
(15, 11, 16, '2025-02-05 09:27:16', 'Enrolled', 17, '2025-03-09 14:01:52', '2025-08-05 19:51:30', '2025-07-05 14:18:59'),
(16, 10, 45, '2025-07-30 01:24:56', 'Completed', 42, '2025-07-27 16:49:43', '2025-02-23 03:33:56', '2025-03-13 18:48:42'),
(17, 3, 2, '2025-08-31 11:15:08', 'Completed', 5, NULL, '2025-09-07 00:35:37', '2025-06-24 17:54:46'),
(18, 7, 48, '2025-06-05 07:11:25', 'Completed', 2, '2025-05-04 06:33:07', '2025-07-21 18:22:17', '2025-05-04 14:30:49'),
(19, 3, 32, '2025-04-09 03:37:23', 'Completed', 88, NULL, '2025-04-28 19:51:48', '2025-02-02 18:00:09'),
(20, 7, 50, '2025-01-05 11:55:59', 'Enrolled', 49, '2025-04-20 00:57:23', '2025-04-28 18:58:51', '2025-04-10 17:34:13'),
(21, 3, 10, '2025-08-14 23:08:25', 'Enrolled', 35, '2025-06-24 23:52:15', '2025-08-30 21:08:57', '2025-06-19 05:10:24'),
(22, 11, 35, '2025-03-11 10:36:56', 'Enrolled', 19, '2025-06-08 21:14:05', '2025-07-26 07:29:46', '2025-01-03 21:46:24'),
(23, 4, 29, '2025-01-22 19:06:28', 'Dropped', 23, NULL, '2025-07-12 19:13:08', '2025-06-07 01:02:50'),
(24, 5, 13, '2025-03-16 09:51:26', 'Completed', 88, '2025-07-03 09:25:54', '2025-05-22 06:33:00', '2025-07-01 16:24:05'),
(25, 2, 19, '2025-07-03 18:31:38', 'Completed', 21, NULL, '2025-05-03 10:47:57', '2025-01-29 02:47:16'),
(26, 12, 44, '2025-03-24 14:44:56', 'Dropped', 3, NULL, '2025-03-31 15:33:48', '2025-01-23 21:14:50'),
(27, 13, 13, '2025-01-08 02:48:29', 'Completed', 25, NULL, '2025-07-13 01:43:56', '2025-08-03 11:46:42'),
(28, 6, 26, '2025-08-11 06:02:59', 'Dropped', 34, NULL, '2025-08-16 09:27:59', '2025-07-31 21:10:11'),
(29, 9, 18, '2025-01-16 02:01:37', 'Completed', 57, '2025-09-13 13:43:47', '2025-07-17 19:18:12', '2025-02-04 19:40:05'),
(30, 9, 27, '2025-06-07 00:33:02', 'Dropped', 23, NULL, '2025-04-30 06:02:13', '2025-06-25 02:20:46'),
(31, 2, 28, '2025-01-21 10:36:55', 'Enrolled', 47, NULL, '2025-03-02 01:43:26', '2025-06-16 20:13:07'),
(32, 15, 15, '2025-05-09 07:59:22', 'Dropped', 37, '2025-06-03 14:29:38', '2025-01-23 15:20:50', '2025-02-24 02:08:42'),
(33, 13, 20, '2025-01-07 18:45:12', 'Dropped', 64, '2025-04-24 01:13:03', '2025-06-05 16:34:07', '2025-01-23 14:57:45'),
(34, 15, 40, '2025-04-21 17:59:07', 'Completed', 9, '2025-02-14 16:15:22', '2025-02-08 06:26:13', '2025-08-20 21:06:44'),
(35, 7, 1, '2025-08-30 17:43:29', 'Dropped', 26, NULL, '2025-08-14 16:15:06', '2025-03-28 07:13:43'),
(36, 3, 28, '2025-06-28 13:49:48', 'Dropped', 27, NULL, '2025-08-05 14:04:07', '2025-06-29 03:49:36'),
(37, 3, 5, '2025-03-01 15:08:44', 'Enrolled', 26, '2025-06-26 08:54:04', '2025-07-04 17:20:22', '2025-07-01 07:03:52'),
(38, 10, 31, '2025-06-07 02:20:51', 'Completed', 57, NULL, '2025-01-13 16:07:13', '2025-09-03 04:20:42'),
(39, 8, 3, '2025-03-23 19:58:29', 'Enrolled', 82, NULL, '2025-06-03 18:25:05', '2025-01-12 12:41:51'),
(40, 11, 7, '2025-06-15 16:57:35', 'Enrolled', 35, '2025-03-19 17:00:19', '2025-07-19 16:15:35', '2025-07-10 23:49:26'),
(41, 11, 19, '2025-06-16 03:50:51', 'Completed', 28, '2025-01-08 05:58:24', '2025-06-03 13:22:42', '2025-08-28 02:06:05'),
(42, 9, 11, '2025-06-03 19:42:12', 'Enrolled', 2, '2025-07-21 19:38:46', '2025-02-27 20:55:04', '2025-06-10 04:19:03'),
(43, 13, 30, '2025-02-03 21:26:10', 'Enrolled', 72, '2025-08-19 16:58:13', '2025-08-05 18:38:29', '2025-05-09 11:45:45'),
(44, 5, 48, '2025-01-17 00:59:32', 'Completed', 50, NULL, '2025-07-17 02:57:55', '2025-04-28 15:46:42'),
(45, 9, 44, '2025-02-16 12:18:39', 'Dropped', 47, '2025-06-04 06:51:05', '2025-08-11 11:26:12', '2025-05-23 02:56:32'),
(46, 5, 15, '2025-04-21 15:56:00', 'Dropped', 25, NULL, '2025-01-04 22:26:34', '2025-08-26 02:19:16'),
(47, 8, 33, '2025-04-18 22:31:35', 'Enrolled', 80, '2025-02-17 02:11:15', '2025-02-24 04:54:12', '2025-06-28 15:35:18'),
(48, 4, 12, '2025-07-29 22:36:27', 'Enrolled', 75, NULL, '2025-05-29 12:06:50', '2025-02-14 10:15:51'),
(49, 10, 22, '2025-07-15 01:33:39', 'Enrolled', 63, NULL, '2025-09-12 05:42:53', '2025-04-05 07:03:21'),
(50, 7, 1, '2025-02-21 18:41:00', 'Dropped', 39, '2025-06-26 09:23:28', '2025-09-16 10:45:17', '2025-03-23 15:14:58'),
(51, 11, 4, '2025-03-14 09:45:29', 'Completed', 72, '2025-03-04 02:54:14', '2025-04-05 07:22:14', '2025-09-11 20:11:47'),
(52, 8, 28, '2025-06-22 16:05:41', 'Dropped', 24, NULL, '2025-04-28 08:52:46', '2025-06-13 20:30:45'),
(53, 13, 1, '2025-03-11 19:29:25', 'Dropped', 28, '2025-05-29 05:23:57', '2025-06-21 22:25:40', '2025-01-22 19:03:53'),
(54, 4, 13, '2025-09-03 01:38:34', 'Enrolled', 55, '2025-02-21 21:07:32', '2025-06-24 20:17:43', '2025-05-05 05:39:01'),
(55, 10, 39, '2025-06-09 23:51:29', 'Enrolled', 43, NULL, '2025-01-27 00:50:39', '2025-06-18 12:18:17'),
(56, 14, 19, '2025-08-08 06:01:26', 'Completed', 36, '2025-05-30 19:06:13', '2025-05-14 07:18:49', '2025-08-09 03:28:49'),
(57, 2, 30, '2025-01-27 01:08:52', 'Completed', 79, '2025-02-18 00:21:54', '2025-03-16 04:18:03', '2025-02-05 08:54:12'),
(58, 11, 1, '2025-04-29 15:05:05', 'Dropped', 73, '2025-06-28 13:25:45', '2025-06-25 11:53:19', '2025-09-10 21:56:41'),
(59, 7, 22, '2025-05-25 20:03:32', 'Enrolled', 42, '2025-01-16 01:51:32', '2025-02-26 13:04:59', '2025-01-16 11:21:52'),
(60, 14, 49, '2025-05-18 05:17:19', 'Dropped', 6, '2025-03-29 04:11:11', '2025-02-25 22:09:16', '2025-08-22 03:29:06'),
(61, 5, 33, '2025-06-21 19:55:35', 'Dropped', 15, NULL, '2025-04-11 22:07:59', '2025-07-05 19:14:06'),
(62, 3, 20, '2025-04-19 15:59:52', 'Dropped', 76, '2025-04-11 13:17:45', '2025-09-06 21:06:08', '2025-07-30 08:52:49'),
(63, 2, 8, '2025-06-01 20:23:35', 'Completed', 72, NULL, '2025-09-08 20:20:37', '2025-03-24 01:42:51'),
(64, 4, 20, '2025-01-20 03:31:43', 'Enrolled', 79, NULL, '2025-02-28 09:27:02', '2025-04-02 12:46:01'),
(65, 1, 9, '2025-08-12 23:29:00', 'Dropped', 34, '2025-04-02 17:07:58', '2025-04-16 07:35:37', '2025-08-24 08:13:57'),
(66, 8, 21, '2025-08-05 14:58:36', 'Completed', 36, NULL, '2025-03-21 12:37:05', '2025-02-27 01:58:42'),
(67, 3, 22, '2025-08-28 19:53:55', 'Dropped', 81, '2025-08-15 08:18:27', '2025-07-18 19:06:35', '2025-02-03 09:59:43'),
(68, 6, 36, '2025-03-11 18:22:34', 'Completed', 40, NULL, '2025-05-09 19:19:40', '2025-01-09 13:35:53'),
(69, 10, 38, '2025-07-30 09:47:03', 'Enrolled', 31, '2025-01-27 22:24:17', '2025-08-07 07:20:52', '2025-05-01 00:49:28'),
(70, 12, 24, '2025-08-23 09:24:21', 'Enrolled', 5, '2025-04-13 02:43:21', '2025-05-10 21:06:28', '2025-07-31 13:40:27'),
(71, 13, 11, '2025-04-25 20:28:48', 'Completed', 31, '2025-05-22 12:58:21', '2025-04-22 05:05:06', '2025-01-14 10:41:24'),
(72, 5, 7, '2025-05-24 21:35:51', 'Dropped', 74, '2025-05-16 22:49:14', '2025-09-08 07:35:27', '2025-03-26 03:04:57'),
(73, 6, 35, '2025-05-06 01:42:19', 'Completed', 83, '2025-06-23 07:10:26', '2025-07-14 23:37:32', '2025-01-17 23:12:16'),
(74, 1, 1, '2025-05-08 14:48:28', 'Enrolled', 72, NULL, '2025-06-22 18:10:45', '2025-09-01 04:46:51'),
(75, 10, 15, '2025-02-27 04:47:58', 'Enrolled', 71, '2025-04-28 00:25:46', '2025-01-24 21:26:37', '2025-05-29 07:52:55'),
(76, 8, 40, '2025-09-01 15:31:16', 'Completed', 36, '2025-07-03 10:28:18', '2025-04-17 10:53:30', '2025-01-10 05:20:46'),
(77, 7, 50, '2025-08-01 07:43:00', 'Enrolled', 25, NULL, '2025-03-01 05:14:12', '2025-03-30 15:02:08'),
(78, 7, 43, '2025-06-16 21:06:55', 'Completed', 43, '2025-07-03 13:21:43', '2025-08-06 05:54:46', '2025-01-17 14:46:31'),
(79, 15, 27, '2025-03-31 11:39:31', 'Completed', 42, '2025-06-18 07:02:24', '2025-03-11 22:47:31', '2025-04-15 11:02:01'),
(80, 12, 35, '2025-04-05 17:37:39', 'Enrolled', 92, '2025-01-16 01:12:19', '2025-08-10 17:48:57', '2025-01-14 11:16:30');

INSERT INTO `workshops` (`id`, `title`, `slug`, `description`, `type`, `price`, `start_datetime`, `end_datetime`, `location`, `max_participants`, `thumbnail`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Accusamus rem eos.', 'letter-last-bad', 'Iste dolor animi necessitatibus. Asperiores voluptatibus in quam facilis a.

Nemo cupiditate sapiente sed explicabo quod sed. Laboriosam ut perspiciatis molestias quisquam. Alias modi expedita a saepe pariatur.

Corrupti fugit ducimus id aspernatur. Numquam quisquam doloremque eaque eos itaque expedita. Debitis consequuntur excepturi distinctio.', 'workshop', 182186.44, '2025-02-03 22:48:20', '2025-02-04 00:48:20', 'Gg. Veteran No. 3
Malang, MU 49148', 132, NULL, 'draft', '2025-07-26 20:52:01', NULL),
(2, 'Ducimus et nostrum nulla et.', 'when-special-return', 'Quaerat delectus aut eveniet. Pariatur repellat at saepe. Explicabo natus laudantium dolorum nemo. Rerum aliquid hic expedita.

Dolor maxime quis expedita explicabo itaque. Vitae voluptatem cupiditate ipsam eligendi.

Dolorem magnam mollitia sapiente repellendus. Explicabo sapiente veniam exercitationem illo. Delectus nobis dolor fugiat laborum et consequuntur explicabo.', 'seminar', 12920.85, '2025-07-21 11:49:51', '2025-07-21 13:49:51', 'Gang Kapten Muslihat No. 04
Sabang, SS 95837', 167, '/uploads/workshops/workshop_2.jpg', 'draft', '2025-06-26 00:28:05', '2025-08-21 17:47:27'),
(3, 'Porro quidem consequuntur dolorum dolorum officiis libero dolores.', 'later-business', 'Necessitatibus ab maxime aliquid. Fugit dolorem id ea accusamus perferendis sint.

Labore unde dolorum incidunt. Eligendi possimus ducimus sit repellendus odit dolorum.

Aliquid nihil asperiores cupiditate perspiciatis necessitatibus. Ab illum fugiat alias minus nesciunt tenetur. Molestiae veniam alias eaque incidunt aliquam ut. Nisi eaque occaecati laborum accusantium.', 'workshop', 868489.57, '2025-07-25 00:06:35', '2025-07-25 07:06:35', 'Gg. Rajawali Timur No. 4
Sorong, AC 15248', 89, '/uploads/workshops/workshop_3.jpg', 'published', '2025-02-02 05:44:56', NULL),
(4, 'Ut tempore eum doloremque neque.', 'scientist-bring', 'Atque odit tenetur velit. Voluptatibus dolor quidem aliquid neque nesciunt sunt.

Repudiandae fugiat corrupti minus. Ex temporibus cupiditate cumque vel. Iure omnis libero vel.

Dolorem quo error quis. Modi ad distinctio odio deleniti animi. Quia laboriosam blanditiis et repellendus.', 'seminar', 130334.24, '2025-02-24 05:16:01', '2025-02-24 10:16:01', 'Gang Sadang Serang No. 89
Pontianak, SU 40286', 140, NULL, 'published', '2025-07-05 16:34:11', NULL),
(5, 'Laboriosam consequatur laborum laboriosam incidunt eos veritatis a.', 'job-although', 'Qui maiores eius necessitatibus accusamus reiciendis inventore reprehenderit. Nobis suscipit animi non quia.

Dignissimos eius ea itaque libero saepe ipsam. Sed fuga possimus eveniet voluptas.

Commodi voluptates odio magni. Deleniti distinctio voluptatum cumque reprehenderit doloribus voluptate. Ipsam a doloremque quos.', 'seminar', 911095.09, '2025-07-13 19:55:16', '2025-07-14 03:55:16', 'Jl. W.R. Supratman No. 894
Prabumulih, JI 65961', 99, NULL, 'published', '2025-04-30 01:42:12', NULL),
(6, 'Harum dignissimos enim blanditiis.', 'even-form-yet', 'Unde asperiores cupiditate cum expedita soluta. Deserunt corporis ab libero voluptates dignissimos.

Temporibus illum fugit ea. Explicabo distinctio iste ad blanditiis reprehenderit. Natus ipsum laborum cum voluptatem omnis.

Ea asperiores doloribus quia quo ex. Animi quo error labore quia. Animi at voluptate explicabo praesentium.', 'workshop', 552740.7, '2025-03-26 13:31:21', '2025-03-26 21:31:21', 'Jl. Setiabudhi No. 1
Cirebon, DI Yogyakarta 03494', 51, NULL, 'draft', '2025-02-17 14:17:48', '2025-07-28 05:06:37'),
(7, 'Ex repellendus dignissimos debitis architecto beatae deleniti.', 'thank-letter-or', 'Provident quae id doloremque consectetur odit rem. Necessitatibus corrupti blanditiis dolorum officia ratione. Voluptas temporibus alias totam.

Eligendi sed quis nostrum voluptatem accusantium. Quia corrupti suscipit libero.

Reprehenderit quasi necessitatibus nemo illo.', 'seminar', 433659.3, '2025-03-20 14:05:46', '2025-03-20 16:05:46', 'Gang Stasiun Wonokromo No. 35
Pangkalpinang, SS 87531', 189, '/uploads/workshops/workshop_7.jpg', 'completed', '2025-07-05 23:18:31', '2025-01-23 23:43:17'),
(8, 'Labore sapiente in aperiam illo quibusdam.', 'yet-value-reason', 'Magni odit numquam accusantium tempore sit aut. Expedita hic ipsam ex adipisci assumenda. Sapiente vero explicabo ipsa.

Sunt aliquam illum quidem repudiandae quos. Deleniti qui nostrum fugit voluptates. Dignissimos molestias distinctio tempora voluptas laborum.

Voluptatem totam consequatur. Aliquid fugiat ut nobis eius voluptatum.', 'seminar', 683316.43, '2025-04-25 08:31:14', '2025-04-25 13:31:14', 'Jalan R.E Martadinata No. 09
Tangerang, Jawa Barat 24870', 57, '/uploads/workshops/workshop_8.jpg', 'published', '2025-05-15 20:32:18', '2025-07-11 05:03:14'),
(9, 'Perferendis ipsum fugit sunt.', 'rise-source', 'Saepe accusantium in illum quod.

A dicta amet animi aperiam molestias minus. Optio assumenda nihil odit.

Voluptate maxime optio harum cumque beatae. Vero repellendus laudantium dolorum mollitia. Laudantium adipisci a ducimus.', 'seminar', 370737.27, '2025-09-14 22:22:05', '2025-09-15 04:22:05', 'Gg. Rajiman No. 0
Bima, SU 68048', 59, '/uploads/workshops/workshop_9.jpg', 'published', '2025-05-10 21:45:20', '2025-03-21 08:14:15'),
(10, 'Laborum rerum necessitatibus suscipit totam.', 'option-civil-soon', 'Aperiam laborum voluptates. Vero adipisci ea ut illo distinctio doloribus.

Tempora inventore quia omnis provident.

Doloremque tenetur quibusdam perferendis veniam laboriosam neque saepe. Illum dolore saepe ducimus dicta nobis. Neque numquam corrupti in architecto.', 'workshop', 500779.99, '2025-08-07 17:29:38', '2025-08-07 19:29:38', 'Jl. H.J Maemunah No. 5
Tanjungbalai, Kalimantan Selatan 44656', 42, '/uploads/workshops/workshop_10.jpg', 'published', '2025-06-26 16:58:17', '2025-08-27 22:08:12');

INSERT INTO `testimonials` (`id`, `name`, `position`, `photo`, `content`, `rating`, `created_at`) VALUES
(1, 'drg. Cemplunk Pratiwi', 'Mahasiswa', NULL, 'Impedit facilis eius magnam commodi inventore. Error necessitatibus incidunt qui blanditiis ipsum soluta. Ea eveniet odit fugit quae nihil iste. Similique molestiae quaerat veniam sunt.', 5, '2025-04-20 02:18:51'),
(2, 'R. Rachel Prastuti', 'Professional', NULL, 'Aliquam inventore id minus sed. Officia ipsum earum veritatis occaecati.', 3, '2025-02-14 12:17:13'),
(3, 'Tantri Tamba', 'Professional', '/uploads/testimonials/testimonial_3.jpg', 'Sequi cum cum. Quo blanditiis libero eaque occaecati neque enim.', 3, '2025-02-12 16:11:49'),
(4, 'Lalita Suryono', 'Developer', NULL, 'Eaque harum sit officiis cum. Perspiciatis ipsam asperiores quia maiores aspernatur doloremque nobis. Culpa earum cumque mollitia aspernatur.', 5, '2025-04-07 11:07:50'),
(5, 'Citra Tampubolon', 'Professional', '/uploads/testimonials/testimonial_5.jpg', 'Vero magnam sit pariatur. Iusto quis quidem earum accusantium. Exercitationem libero nisi eos corrupti et vero earum.', 5, '2025-06-01 07:59:06'),
(6, 'Ida Wahyuni, S.Ked', 'Student', '/uploads/testimonials/testimonial_6.jpg', 'Repellat eligendi pariatur soluta animi. Expedita distinctio consectetur.', 4, '2025-06-08 21:57:19'),
(7, 'Ghani Kurniawan', 'IT Manager', '/uploads/testimonials/testimonial_7.jpg', 'Sunt excepturi ratione ut. Enim velit numquam corrupti ipsam nulla.', 5, '2025-04-15 21:09:55'),
(8, 'Dr. Titi Riyanti, M.M.', 'Student', NULL, 'Omnis accusantium assumenda sunt. Dolorum culpa assumenda totam ratione nisi aliquam error. Iure iure voluptatum maxime.', 5, '2025-08-11 16:02:15'),
(9, 'Ir. Paiman Anggriawan, S.Psi', 'Professional', NULL, 'Eos ullam odit beatae quis omnis modi. Voluptatum delectus quisquam totam quibusdam reiciendis. Libero iste facilis ea beatae reiciendis hic perferendis.', 5, '2025-03-23 16:04:02'),
(10, 'R.M. Luwes Suwarno, S.Pd', 'Developer', '/uploads/testimonials/testimonial_10.jpg', 'Occaecati harum soluta reprehenderit dolor illum atque enim. Error eius ducimus perspiciatis inventore ullam et. Ea ipsam unde officia.', 4, '2025-03-30 11:53:25');

SET FOREIGN_KEY_CHECKS = 1;
