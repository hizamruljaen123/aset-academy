<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-12 07:34:48 --> Severity: error --> Exception: syntax error, unexpected token "else", expecting end of file C:\laragon\www\aset-academy\application\views\kelas\detail.php 212
ERROR - 2025-09-12 10:49:26 --> Severity: error --> Exception: syntax error, unexpected token "else", expecting end of file C:\laragon\www\aset-academy\application\views\kelas\detail.php 212
