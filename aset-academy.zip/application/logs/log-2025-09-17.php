<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-17 04:14:11 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\laragon\www\aset-academy\system\core\URI.php 102
ERROR - 2025-09-17 04:14:11 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\laragon\www\aset-academy\system\core\Router.php 128
ERROR - 2025-09-17 04:14:11 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:11 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:11 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:11 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:11 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:11 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:11 --> Severity: 8192 --> Creation of dynamic property Home::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:11 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:11 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:11 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:11 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:11 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:11 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 397
ERROR - 2025-09-17 04:14:11 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\laragon\www\aset-academy\system\database\DB_driver.php 372
ERROR - 2025-09-17 04:14:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\laragon\www\aset-academy\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 04:14:15 --> Unable to connect to the database
ERROR - 2025-09-17 04:14:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\aset-academy\system\core\Exceptions.php:272) C:\laragon\www\aset-academy\system\core\Common.php 571
ERROR - 2025-09-17 04:14:28 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\laragon\www\aset-academy\system\core\URI.php 102
ERROR - 2025-09-17 04:14:28 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\laragon\www\aset-academy\system\core\Router.php 128
ERROR - 2025-09-17 04:14:28 --> Severity: 8192 --> Creation of dynamic property Documentation::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:28 --> Severity: 8192 --> Creation of dynamic property Documentation::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:28 --> Severity: 8192 --> Creation of dynamic property Documentation::$config is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:28 --> Severity: 8192 --> Creation of dynamic property Documentation::$log is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:28 --> Severity: 8192 --> Creation of dynamic property Documentation::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:28 --> Severity: 8192 --> Creation of dynamic property Documentation::$uri is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:28 --> Severity: 8192 --> Creation of dynamic property Documentation::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:28 --> Severity: 8192 --> Creation of dynamic property Documentation::$router is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:28 --> Severity: 8192 --> Creation of dynamic property Documentation::$output is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:28 --> Severity: 8192 --> Creation of dynamic property Documentation::$security is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:28 --> Severity: 8192 --> Creation of dynamic property Documentation::$input is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:28 --> Severity: 8192 --> Creation of dynamic property Documentation::$lang is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:28 --> Severity: 8192 --> Creation of dynamic property Documentation::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 397
ERROR - 2025-09-17 04:14:28 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\laragon\www\aset-academy\system\database\DB_driver.php 372
ERROR - 2025-09-17 04:14:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it C:\laragon\www\aset-academy\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2025-09-17 04:14:32 --> Unable to connect to the database
ERROR - 2025-09-17 04:14:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\aset-academy\system\core\Exceptions.php:272) C:\laragon\www\aset-academy\system\core\Common.php 571
ERROR - 2025-09-17 04:14:42 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\laragon\www\aset-academy\system\core\URI.php 102
ERROR - 2025-09-17 04:14:42 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\laragon\www\aset-academy\system\core\Router.php 128
ERROR - 2025-09-17 04:14:42 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:42 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:42 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:42 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:42 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:42 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:42 --> Severity: 8192 --> Creation of dynamic property Home::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:42 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:42 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:42 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:42 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:42 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:42 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 397
ERROR - 2025-09-17 04:14:42 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\laragon\www\aset-academy\system\database\DB_driver.php 372
ERROR - 2025-09-17 04:14:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 303
ERROR - 2025-09-17 04:14:44 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 328
ERROR - 2025-09-17 04:14:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 355
ERROR - 2025-09-17 04:14:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 365
ERROR - 2025-09-17 04:14:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 366
ERROR - 2025-09-17 04:14:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 367
ERROR - 2025-09-17 04:14:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 368
ERROR - 2025-09-17 04:14:44 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 426
ERROR - 2025-09-17 04:14:44 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 110
ERROR - 2025-09-17 04:14:44 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 137
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property Home::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property Home::$Kelas_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property Home::$Free_class_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property Home::$Testimonial_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Kelas_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Free_class_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:44 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Testimonial_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\laragon\www\aset-academy\system\core\URI.php 102
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\laragon\www\aset-academy\system\core\Router.php 128
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property Home::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 397
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\laragon\www\aset-academy\system\database\DB_driver.php 372
ERROR - 2025-09-17 04:14:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 303
ERROR - 2025-09-17 04:14:47 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 328
ERROR - 2025-09-17 04:14:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 355
ERROR - 2025-09-17 04:14:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 365
ERROR - 2025-09-17 04:14:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 366
ERROR - 2025-09-17 04:14:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 367
ERROR - 2025-09-17 04:14:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 368
ERROR - 2025-09-17 04:14:47 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 426
ERROR - 2025-09-17 04:14:47 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 110
ERROR - 2025-09-17 04:14:47 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 137
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property Home::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property Home::$Kelas_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property Home::$Free_class_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property Home::$Testimonial_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Kelas_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Free_class_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:14:47 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Testimonial_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\laragon\www\aset-academy\system\core\URI.php 102
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\laragon\www\aset-academy\system\core\Router.php 128
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property Documentation::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property Documentation::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property Documentation::$config is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property Documentation::$log is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property Documentation::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property Documentation::$uri is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property Documentation::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property Documentation::$router is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property Documentation::$output is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property Documentation::$security is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property Documentation::$input is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property Documentation::$lang is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property Documentation::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 397
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\laragon\www\aset-academy\system\database\DB_driver.php 372
ERROR - 2025-09-17 04:15:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 303
ERROR - 2025-09-17 04:15:02 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 328
ERROR - 2025-09-17 04:15:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 355
ERROR - 2025-09-17 04:15:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 365
ERROR - 2025-09-17 04:15:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 366
ERROR - 2025-09-17 04:15:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 367
ERROR - 2025-09-17 04:15:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 368
ERROR - 2025-09-17 04:15:02 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 426
ERROR - 2025-09-17 04:15:02 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 110
ERROR - 2025-09-17 04:15:02 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 137
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property Documentation::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property Documentation::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:02 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\laragon\www\aset-academy\system\core\URI.php 102
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\laragon\www\aset-academy\system\core\Router.php 128
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property Home::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 397
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\laragon\www\aset-academy\system\database\DB_driver.php 372
ERROR - 2025-09-17 04:15:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 303
ERROR - 2025-09-17 04:15:15 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 328
ERROR - 2025-09-17 04:15:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 355
ERROR - 2025-09-17 04:15:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 365
ERROR - 2025-09-17 04:15:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 366
ERROR - 2025-09-17 04:15:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 367
ERROR - 2025-09-17 04:15:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 368
ERROR - 2025-09-17 04:15:15 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 426
ERROR - 2025-09-17 04:15:15 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 110
ERROR - 2025-09-17 04:15:15 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 137
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property Home::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property Home::$Kelas_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property Home::$Free_class_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property Home::$Testimonial_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Kelas_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Free_class_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:15 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Testimonial_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:33 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\laragon\www\aset-academy\system\core\URI.php 102
ERROR - 2025-09-17 04:15:33 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\laragon\www\aset-academy\system\core\Router.php 128
ERROR - 2025-09-17 04:15:33 --> Severity: 8192 --> Creation of dynamic property Documentation::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:33 --> Severity: 8192 --> Creation of dynamic property Documentation::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:33 --> Severity: 8192 --> Creation of dynamic property Documentation::$config is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:33 --> Severity: 8192 --> Creation of dynamic property Documentation::$log is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:33 --> Severity: 8192 --> Creation of dynamic property Documentation::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:33 --> Severity: 8192 --> Creation of dynamic property Documentation::$uri is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:33 --> Severity: 8192 --> Creation of dynamic property Documentation::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:33 --> Severity: 8192 --> Creation of dynamic property Documentation::$router is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:33 --> Severity: 8192 --> Creation of dynamic property Documentation::$output is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property Documentation::$security is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property Documentation::$input is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property Documentation::$lang is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property Documentation::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 397
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\laragon\www\aset-academy\system\database\DB_driver.php 372
ERROR - 2025-09-17 04:15:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 303
ERROR - 2025-09-17 04:15:34 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 328
ERROR - 2025-09-17 04:15:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 355
ERROR - 2025-09-17 04:15:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 365
ERROR - 2025-09-17 04:15:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 366
ERROR - 2025-09-17 04:15:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 367
ERROR - 2025-09-17 04:15:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 368
ERROR - 2025-09-17 04:15:34 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 426
ERROR - 2025-09-17 04:15:34 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 110
ERROR - 2025-09-17 04:15:34 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 137
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property Documentation::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property Documentation::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:34 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\laragon\www\aset-academy\system\core\URI.php 102
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\laragon\www\aset-academy\system\core\Router.php 128
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property Home::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 397
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\laragon\www\aset-academy\system\database\DB_driver.php 372
ERROR - 2025-09-17 04:15:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 303
ERROR - 2025-09-17 04:15:45 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 328
ERROR - 2025-09-17 04:15:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 355
ERROR - 2025-09-17 04:15:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 365
ERROR - 2025-09-17 04:15:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 366
ERROR - 2025-09-17 04:15:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 367
ERROR - 2025-09-17 04:15:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 368
ERROR - 2025-09-17 04:15:45 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 426
ERROR - 2025-09-17 04:15:45 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 110
ERROR - 2025-09-17 04:15:45 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 137
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property Home::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property Home::$Kelas_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property Home::$Free_class_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property Home::$Testimonial_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Kelas_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Free_class_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:15:45 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Testimonial_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:18:42 --> Severity: Warning --> mkdir(): Invalid path C:\laragon\www\aset-academy\system\libraries\Session\drivers\Session_files_driver.php 137
ERROR - 2025-09-17 04:18:42 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2025-09-17 04:18:42 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) C:\laragon\www\aset-academy\system\libraries\Session\Session.php 137
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property Home::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property Home::$Kelas_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property Home::$Free_class_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property Home::$Testimonial_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Kelas_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Free_class_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:18:42 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Testimonial_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:19:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:19:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:19:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:19:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:19:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:19:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:19:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:19:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:19:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:19:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:19:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:19:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:19:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:19:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:20:53 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:21:18 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 141
ERROR - 2025-09-17 04:22:44 --> Severity: Warning --> Undefined property: CI_Loader::$load C:\laragon\www\aset-academy\application\views\home\index.php 1
ERROR - 2025-09-17 04:22:44 --> Severity: error --> Exception: Call to a member function view() on null C:\laragon\www\aset-academy\application\views\home\index.php 1
ERROR - 2025-09-17 04:23:11 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 943
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\laragon\www\aset-academy\system\core\URI.php 102
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\laragon\www\aset-academy\system\core\Router.php 128
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property Home::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 397
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\laragon\www\aset-academy\system\database\DB_driver.php 372
ERROR - 2025-09-17 04:26:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 303
ERROR - 2025-09-17 04:26:30 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 328
ERROR - 2025-09-17 04:26:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 355
ERROR - 2025-09-17 04:26:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 365
ERROR - 2025-09-17 04:26:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 366
ERROR - 2025-09-17 04:26:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 367
ERROR - 2025-09-17 04:26:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 368
ERROR - 2025-09-17 04:26:30 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 426
ERROR - 2025-09-17 04:26:30 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 110
ERROR - 2025-09-17 04:26:30 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 137
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property Home::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property Home::$Kelas_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property Home::$Free_class_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property Home::$Testimonial_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Kelas_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Free_class_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:30 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Testimonial_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\laragon\www\aset-academy\system\core\URI.php 102
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\laragon\www\aset-academy\system\core\Router.php 128
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property Home::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 397
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\laragon\www\aset-academy\system\database\DB_driver.php 372
ERROR - 2025-09-17 04:26:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 303
ERROR - 2025-09-17 04:26:39 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 328
ERROR - 2025-09-17 04:26:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 355
ERROR - 2025-09-17 04:26:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 365
ERROR - 2025-09-17 04:26:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 366
ERROR - 2025-09-17 04:26:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 367
ERROR - 2025-09-17 04:26:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 368
ERROR - 2025-09-17 04:26:39 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 426
ERROR - 2025-09-17 04:26:39 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 110
ERROR - 2025-09-17 04:26:39 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 137
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property Home::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property Home::$Kelas_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property Home::$Free_class_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property Home::$Testimonial_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Kelas_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Free_class_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:39 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Testimonial_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\laragon\www\aset-academy\system\core\URI.php 102
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\laragon\www\aset-academy\system\core\Router.php 128
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property Home::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 397
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\laragon\www\aset-academy\system\database\DB_driver.php 372
ERROR - 2025-09-17 04:26:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 303
ERROR - 2025-09-17 04:26:43 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 328
ERROR - 2025-09-17 04:26:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 355
ERROR - 2025-09-17 04:26:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 365
ERROR - 2025-09-17 04:26:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 366
ERROR - 2025-09-17 04:26:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 367
ERROR - 2025-09-17 04:26:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 368
ERROR - 2025-09-17 04:26:43 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 426
ERROR - 2025-09-17 04:26:43 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 110
ERROR - 2025-09-17 04:26:43 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 137
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property Home::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property Home::$Kelas_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property Home::$Free_class_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property Home::$Testimonial_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Kelas_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Free_class_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:26:43 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Testimonial_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\laragon\www\aset-academy\system\core\URI.php 102
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\laragon\www\aset-academy\system\core\Router.php 128
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property Home::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 397
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\laragon\www\aset-academy\system\database\DB_driver.php 372
ERROR - 2025-09-17 04:27:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 303
ERROR - 2025-09-17 04:27:09 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 328
ERROR - 2025-09-17 04:27:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 355
ERROR - 2025-09-17 04:27:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 365
ERROR - 2025-09-17 04:27:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 366
ERROR - 2025-09-17 04:27:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 367
ERROR - 2025-09-17 04:27:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 368
ERROR - 2025-09-17 04:27:09 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 426
ERROR - 2025-09-17 04:27:09 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 110
ERROR - 2025-09-17 04:27:09 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 137
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property Home::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property Home::$Kelas_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property Home::$Free_class_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property Home::$Testimonial_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Kelas_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Free_class_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:27:09 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Testimonial_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property Home::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property Home::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property Home::$config is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property Home::$log is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property Home::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property Home::$uri is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property Home::$router is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property Home::$output is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property Home::$security is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property Home::$input is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property Home::$lang is deprecated C:\laragon\www\aset-academy\system\core\Controller.php 83
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property Home::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 397
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\laragon\www\aset-academy\system\database\DB_driver.php 372
ERROR - 2025-09-17 04:28:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 303
ERROR - 2025-09-17 04:28:58 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 328
ERROR - 2025-09-17 04:28:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 355
ERROR - 2025-09-17 04:28:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 365
ERROR - 2025-09-17 04:28:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 366
ERROR - 2025-09-17 04:28:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 367
ERROR - 2025-09-17 04:28:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 368
ERROR - 2025-09-17 04:28:58 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 426
ERROR - 2025-09-17 04:28:58 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 110
ERROR - 2025-09-17 04:28:58 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\laragon\www\aset-academy\system\libraries\Session\Session.php 137
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property Home::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property Home::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 1284
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property Home::$Kelas_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property Home::$Free_class_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property Home::$Testimonial_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 359
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$form_validation is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Kelas_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Free_class_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:28:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$Testimonial_model is deprecated C:\laragon\www\aset-academy\system\core\Loader.php 932
ERROR - 2025-09-17 04:30:21 --> Severity: Warning --> mkdir(): Invalid path C:\laragon\www\aset-academy\system\libraries\Session\drivers\Session_files_driver.php 137
ERROR - 2025-09-17 04:30:21 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2025-09-17 04:30:21 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) C:\laragon\www\aset-academy\system\libraries\Session\Session.php 137
ERROR - 2025-09-17 04:30:23 --> Severity: Warning --> mkdir(): Invalid path C:\laragon\www\aset-academy\system\libraries\Session\drivers\Session_files_driver.php 137
ERROR - 2025-09-17 04:30:23 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2025-09-17 04:30:23 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) C:\laragon\www\aset-academy\system\libraries\Session\Session.php 137
ERROR - 2025-09-17 04:32:36 --> Severity: Warning --> mkdir(): Invalid path C:\laragon\www\aset-academy\system\libraries\Session\drivers\Session_files_driver.php 137
ERROR - 2025-09-17 04:32:36 --> Session: Configured save path '' is not a directory, doesn't exist or cannot be created.
ERROR - 2025-09-17 04:32:36 --> Severity: Warning --> session_start(): Failed to initialize storage module: user (path: ) C:\laragon\www\aset-academy\system\libraries\Session\Session.php 137
ERROR - 2025-09-17 06:04:34 --> 404 Page Not Found: Documentation/styles.css
ERROR - 2025-09-17 06:04:34 --> 404 Page Not Found: Documentation/image.jpg
ERROR - 2025-09-17 06:04:46 --> 404 Page Not Found: Documentation/placeholder.jpg
ERROR - 2025-09-17 16:37:51 --> Severity: error --> Exception: Call to undefined method Siswa_model::get_by_user_id() C:\laragon\www\aset-academy\application\controllers\Student_mobile.php 33
ERROR - 2025-09-17 16:45:30 --> Severity: error --> Exception: Call to undefined method Siswa_model::get_by_user_id() C:\laragon\www\aset-academy\application\controllers\Student_mobile.php 33
ERROR - 2025-09-17 16:50:04 --> Severity: error --> Exception: Call to undefined method Enrollment_model::get_active_enrollment() C:\laragon\www\aset-academy\application\controllers\Student_mobile.php 48
ERROR - 2025-09-17 16:51:45 --> Severity: error --> Exception: Call to undefined method Enrollment_model::get_active_enrollment() C:\laragon\www\aset-academy\application\controllers\Student_mobile.php 48
ERROR - 2025-09-17 16:52:30 --> Severity: error --> Exception: Call to undefined method Kelas_model::get_by_id() C:\laragon\www\aset-academy\application\controllers\Student_mobile.php 52
ERROR - 2025-09-17 16:53:09 --> Severity: Warning --> Undefined property: stdClass::$kelas_id C:\laragon\www\aset-academy\application\controllers\Student_mobile.php 52
ERROR - 2025-09-17 16:53:09 --> Severity: error --> Exception: Call to undefined method Kelas_model::get_available_for_enrollment() C:\laragon\www\aset-academy\application\controllers\Student_mobile.php 74
ERROR - 2025-09-17 16:55:07 --> Severity: Warning --> Undefined property: stdClass::$kelas_id C:\laragon\www\aset-academy\application\controllers\Student_mobile.php 52
ERROR - 2025-09-17 16:55:07 --> Severity: error --> Exception: Call to undefined method Enrollment_model::get_paid_classes() C:\laragon\www\aset-academy\application\controllers\Student_mobile.php 77
ERROR - 2025-09-17 16:56:26 --> Query error: Table 'academy_lite.premium_enrollments' doesn't exist - Invalid query: SELECT `pe`.*, `kp`.`nama_kelas`, `kp`.`deskripsi`, `kp`.`level`, `kp`.`harga`, `kp`.`diskon`, `kp`.`gambar`, `kp`.`slug`, `kp`.`mentor_id`, `u`.`nama` as `mentor_name`
FROM `premium_enrollments` `pe`
LEFT JOIN `kelas_programming` `kp` ON `kp`.`id` = `pe`.`class_id`
LEFT JOIN `users` `u` ON `u`.`id` = `kp`.`mentor_id`
WHERE `pe`.`student_id` = '5'
AND `pe`.`status` IN('active', 'completed')
ORDER BY `pe`.`enrolled_at` DESC
ERROR - 2025-09-17 16:58:33 --> Query error: Unknown column 'kp.diskon' in 'field list' - Invalid query: SELECT `pce`.*, `kp`.`nama_kelas`, `kp`.`deskripsi`, `kp`.`level`, `kp`.`harga`, `kp`.`diskon`, `kp`.`gambar`, `kp`.`slug`, `kp`.`mentor_id`, `u`.`nama` as `mentor_name`
FROM `premium_class_enrollments` `pce`
LEFT JOIN `kelas_programming` `kp` ON `kp`.`id` = `pce`.`class_id`
LEFT JOIN `users` `u` ON `u`.`id` = `kp`.`mentor_id`
WHERE `pce`.`student_id` = '5'
AND `pce`.`status` IN('active', 'completed')
ORDER BY `pce`.`enrolled_at` DESC
ERROR - 2025-09-17 16:58:35 --> Query error: Unknown column 'kp.diskon' in 'field list' - Invalid query: SELECT `pce`.*, `kp`.`nama_kelas`, `kp`.`deskripsi`, `kp`.`level`, `kp`.`harga`, `kp`.`diskon`, `kp`.`gambar`, `kp`.`slug`, `kp`.`mentor_id`, `u`.`nama` as `mentor_name`
FROM `premium_class_enrollments` `pce`
LEFT JOIN `kelas_programming` `kp` ON `kp`.`id` = `pce`.`class_id`
LEFT JOIN `users` `u` ON `u`.`id` = `kp`.`mentor_id`
WHERE `pce`.`student_id` = '5'
AND `pce`.`status` IN('active', 'completed')
ORDER BY `pce`.`enrolled_at` DESC
ERROR - 2025-09-17 16:59:04 --> Query error: Unknown column 'kp.slug' in 'field list' - Invalid query: SELECT `pce`.*, `kp`.`nama_kelas`, `kp`.`deskripsi`, `kp`.`level`, `kp`.`harga`, `kp`.`gambar`, `kp`.`slug`, `kp`.`mentor_id`, `u`.`nama` as `mentor_name`
FROM `premium_class_enrollments` `pce`
LEFT JOIN `kelas_programming` `kp` ON `kp`.`id` = `pce`.`class_id`
LEFT JOIN `users` `u` ON `u`.`id` = `kp`.`mentor_id`
WHERE `pce`.`student_id` = '5'
AND `pce`.`status` IN('active', 'completed')
ORDER BY `pce`.`enrolled_at` DESC
ERROR - 2025-09-17 16:59:39 --> Query error: Unknown column 'kp.mentor_id' in 'field list' - Invalid query: SELECT `pce`.*, `kp`.`nama_kelas`, `kp`.`deskripsi`, `kp`.`level`, `kp`.`harga`, `kp`.`gambar`, `kp`.`mentor_id`, `u`.`nama` as `mentor_name`
FROM `premium_class_enrollments` `pce`
LEFT JOIN `kelas_programming` `kp` ON `kp`.`id` = `pce`.`class_id`
LEFT JOIN `users` `u` ON `u`.`id` = `kp`.`mentor_id`
WHERE `pce`.`student_id` = '5'
AND `pce`.`status` IN('active', 'completed')
ORDER BY `pce`.`enrolled_at` DESC
ERROR - 2025-09-17 17:00:37 --> Query error: Unknown column 'kp.mentor_id' in 'field list' - Invalid query: SELECT `pce`.*, `kp`.`nama_kelas`, `kp`.`deskripsi`, `kp`.`level`, `kp`.`harga`, `kp`.`gambar`, `kp`.`mentor_id`, `u`.`nama` as `mentor_name`
FROM `premium_class_enrollments` `pce`
LEFT JOIN `kelas_programming` `kp` ON `kp`.`id` = `pce`.`class_id`
LEFT JOIN `users` `u` ON `u`.`id` = `kp`.`mentor_id`
WHERE `pce`.`student_id` = '5'
AND `pce`.`status` IN('active', 'completed')
ORDER BY `pce`.`enrolled_at` DESC
ERROR - 2025-09-17 17:03:14 --> Query error: Unknown column 'u.nama' in 'field list' - Invalid query: SELECT `pce`.*, `kp`.`nama_kelas`, `kp`.`deskripsi`, `kp`.`level`, `kp`.`harga`, `kp`.`gambar`, `u`.`nama` as `mentor_name`
FROM `premium_class_enrollments` `pce`
LEFT JOIN `kelas_programming` `kp` ON `kp`.`id` = `pce`.`class_id`
LEFT JOIN `users` `u` ON `u`.`id` = `kp`.`mentor_id`
WHERE `pce`.`student_id` = '5'
AND `pce`.`status` IN('active', 'completed')
ORDER BY `pce`.`enrolled_at` DESC
ERROR - 2025-09-17 17:03:55 --> Query error: Unknown column 'pce.enrolled_at' in 'order clause' - Invalid query: SELECT `pce`.*, `kp`.`nama_kelas`, `kp`.`deskripsi`, `kp`.`level`, `kp`.`harga`, `kp`.`gambar`, `u`.`nama_lengkap` as `mentor_name`
FROM `premium_class_enrollments` `pce`
LEFT JOIN `kelas_programming` `kp` ON `kp`.`id` = `pce`.`class_id`
LEFT JOIN `users` `u` ON `u`.`id` = 0
WHERE `pce`.`student_id` = '5'
AND `pce`.`status` IN('active', 'completed')
ORDER BY `pce`.`enrolled_at` DESC
ERROR - 2025-09-17 17:04:52 --> 404 Page Not Found: Assets/manifest.json
ERROR - 2025-09-17 17:04:52 --> 404 Page Not Found: Assets/favicon.ico
ERROR - 2025-09-17 17:05:26 --> 404 Page Not Found: Assets/favicon.ico
ERROR - 2025-09-17 17:05:28 --> Severity: error --> Exception: Call to undefined method Materi_model::get_by_kelas() C:\laragon\www\aset-academy\application\controllers\Student_mobile.php 292
ERROR - 2025-09-17 17:07:07 --> Severity: Warning --> Attempt to read property "nama_kelas" on null C:\laragon\www\aset-academy\application\controllers\Student_mobile.php 293
ERROR - 2025-09-17 17:07:08 --> Severity: Warning --> Attempt to read property "nama_kelas" on null C:\laragon\www\aset-academy\application\controllers\Student_mobile.php 293
ERROR - 2025-09-17 17:07:19 --> Severity: Warning --> Attempt to read property "nama_kelas" on null C:\laragon\www\aset-academy\application\controllers\Student_mobile.php 293
ERROR - 2025-09-17 17:11:06 --> Severity: error --> Exception: Call to undefined method Jadwal_model::get_student_schedule() C:\laragon\www\aset-academy\application\controllers\Student_mobile.php 168
ERROR - 2025-09-17 17:20:20 --> 404 Page Not Found: Student_mobile/forum
ERROR - 2025-09-17 17:22:12 --> 404 Page Not Found: Student_mobile/forum
ERROR - 2025-09-17 17:22:13 --> 404 Page Not Found: Student_mobile/forum
ERROR - 2025-09-17 17:56:28 --> Severity: error --> Exception: Call to undefined method Forum_model::get_recent_threads() C:\laragon\www\aset-academy\application\controllers\Student_mobile.php 420
ERROR - 2025-09-17 17:56:28 --> Severity: error --> Exception: Call to undefined method Forum_model::get_recent_threads() C:\laragon\www\aset-academy\application\controllers\Student_mobile.php 420
ERROR - 2025-09-17 17:57:52 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\aset-academy\application\views\student\mobile\forum.php 20
ERROR - 2025-09-17 17:57:52 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\aset-academy\application\views\student\mobile\forum.php 20
ERROR - 2025-09-17 17:58:46 --> Severity: Warning --> Undefined variable $has_more C:\laragon\www\aset-academy\application\views\student\mobile\forum.php 83
ERROR - 2025-09-17 17:58:46 --> Severity: Warning --> Undefined variable $has_more C:\laragon\www\aset-academy\application\views\student\mobile\forum.php 83
ERROR - 2025-09-17 17:59:26 --> Query error: Unknown column 'u.avatar' in 'field list' - Invalid query: SELECT `ft`.*, `u`.`nama_lengkap`, `u`.`username`, `u`.`avatar` as `author_avatar`, (SELECT COUNT(*) FROM forum_posts WHERE thread_id = ft.id) as post_count, (SELECT COUNT(*) FROM forum_likes WHERE thread_id = ft.id) as like_count, (SELECT name FROM forum_categories WHERE id = ft.category_id) as category_name, (SELECT COUNT(*) FROM forum_thread_views WHERE thread_id = ft.id) as views
FROM `forum_threads` `ft`
LEFT JOIN `users` `u` ON `u`.`id` = `ft`.`user_id`
ORDER BY `ft`.`is_pinned` DESC, `ft`.`updated_at` DESC, `ft`.`created_at` DESC
 LIMIT 10
ERROR - 2025-09-17 17:59:27 --> Query error: Unknown column 'u.avatar' in 'field list' - Invalid query: SELECT `ft`.*, `u`.`nama_lengkap`, `u`.`username`, `u`.`avatar` as `author_avatar`, (SELECT COUNT(*) FROM forum_posts WHERE thread_id = ft.id) as post_count, (SELECT COUNT(*) FROM forum_likes WHERE thread_id = ft.id) as like_count, (SELECT name FROM forum_categories WHERE id = ft.category_id) as category_name, (SELECT COUNT(*) FROM forum_thread_views WHERE thread_id = ft.id) as views
FROM `forum_threads` `ft`
LEFT JOIN `users` `u` ON `u`.`id` = `ft`.`user_id`
ORDER BY `ft`.`is_pinned` DESC, `ft`.`updated_at` DESC, `ft`.`created_at` DESC
 LIMIT 10
ERROR - 2025-09-17 18:00:46 --> Severity: error --> Exception: Too few arguments to function Forum_model::get_threads_by_category(), 1 passed in C:\laragon\www\aset-academy\application\controllers\Student_mobile.php on line 456 and exactly 3 expected C:\laragon\www\aset-academy\application\models\Forum_model.php 23
ERROR - 2025-09-17 18:03:09 --> 404 Page Not Found: Assets/manifest.json
ERROR - 2025-09-17 18:06:41 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\aset-academy\application\views\student\mobile\forum_create.php 31
