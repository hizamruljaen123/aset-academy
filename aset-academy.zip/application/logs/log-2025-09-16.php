ERROR - 2025-09-16 11:24:38 --> 404 Page Not Found: Uploads/payments
ERROR - 2025-09-16 11:25:39 --> 404 Page Not Found: admin/Permissions/create
ERROR - 2025-09-16 11:39:53 --> 404 Page Not Found: Assets/images
ERROR - 2025-09-16 11:39:53 --> 404 Page Not Found: Uploads/classes
ERROR - 2025-09-16 11:39:53 --> 404 Page Not Found: Uploads/classes
ERROR - 2025-09-16 11:39:53 --> 404 Page Not Found: Uploads/classes
ERROR - 2025-09-16 11:39:53 --> 404 Page Not Found: Uploads/classes
ERROR - 2025-09-16 11:39:53 --> 404 Page Not Found: Uploads/classes
ERROR - 2025-09-16 11:39:53 --> 404 Page Not Found: Uploads/classes
ERROR - 2025-09-16 11:39:54 --> 404 Page Not Found: Assets/images
ERROR - 2025-09-16 12:11:08 --> 404 Page Not Found: Uploads/kelas
ERROR - 2025-09-16 12:11:08 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:11:08 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:11:08 --> 404 Page Not Found: Uploads/testimonials
ERROR - 2025-09-16 12:11:08 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:11:08 --> 404 Page Not Found: Uploads/testimonials
ERROR - 2025-09-16 12:11:10 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:11:10 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:11:10 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:11:14 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:11:14 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:11:14 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:12:18 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:12:18 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:12:18 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:12:21 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:12:21 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:12:21 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:13:52 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:13:52 --> 404 Page Not Found: Internet_basicjpg/index
ERROR - 2025-09-16 12:13:52 --> 404 Page Not Found: Python_basicjpg/index
ERROR - 2025-09-16 12:14:04 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:14:36 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:14:36 --> 404 Page Not Found: 
ERROR - 2025-09-16 12:14:36 --> 404 Page Not Found: 
ERROR - 2025-09-16 12:19:46 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:19:46 --> 404 Page Not Found: 
ERROR - 2025-09-16 12:19:46 --> 404 Page Not Found: 
ERROR - 2025-09-16 12:20:41 --> 404 Page Not Found: 
ERROR - 2025-09-16 12:20:41 --> 404 Page Not Found: 
ERROR - 2025-09-16 12:21:26 --> 404 Page Not Found: 
ERROR - 2025-09-16 12:21:26 --> 404 Page Not Found: 
ERROR - 2025-09-16 12:21:31 --> 404 Page Not Found: Uploads/kelas
ERROR - 2025-09-16 12:21:31 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:21:31 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:21:31 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:21:31 --> 404 Page Not Found: Uploads/testimonials
ERROR - 2025-09-16 12:21:31 --> 404 Page Not Found: Uploads/testimonials
ERROR - 2025-09-16 12:24:59 --> 404 Page Not Found: Uploads/classes
ERROR - 2025-09-16 12:24:59 --> 404 Page Not Found: Uploads/testimonials
ERROR - 2025-09-16 12:24:59 --> 404 Page Not Found: Uploads/testimonials
ERROR - 2025-09-16 12:25:28 --> 404 Page Not Found: Uploads/classes
ERROR - 2025-09-16 12:26:13 --> 404 Page Not Found: Uploads/classes
ERROR - 2025-09-16 12:27:13 --> 404 Page Not Found: Uploads/kelas
ERROR - 2025-09-16 12:27:13 --> 404 Page Not Found: Uploads/kelas
ERROR - 2025-09-16 12:27:37 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:27:37 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:27:37 --> 404 Page Not Found: Uploads/free_class
ERROR - 2025-09-16 12:37:47 --> Severity: error --> Exception: C:\laragon\www\aset-academy\application\models/Partnership_model.php exists, but doesn't declare class Partnership_model C:\laragon\www\aset-academy\system\core\Loader.php 341
