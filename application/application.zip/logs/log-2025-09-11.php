<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-11 00:02:47 --> Query error: Unknown column 'ft.slug' in 'field list' - Invalid query: SELECT `ft`.`id`, `ft`.`title`, `ft`.`slug`, `ft`.`created_at`, `u`.`nama_lengkap` as `author_name`, `u`.`username`, (SELECT COUNT(*) FROM forum_posts fp WHERE fp.thread_id = ft.id) as reply_count
FROM `forum_threads` `ft`
JOIN `users` `u` ON `u`.`id` = `ft`.`user_id`
ORDER BY (SELECT COUNT(*) FROM forum_posts fp WHERE fp.thread_id = ft.id) DESC
 LIMIT 5
ERROR - 2025-09-11 00:04:40 --> Query error: Unknown column 'ft.slug' in 'field list' - Invalid query: SELECT `ft`.`id`, `ft`.`title`, `ft`.`slug`, `ft`.`created_at`, `u`.`nama_lengkap` as `author_name`, `u`.`username`, (SELECT COUNT(*) FROM forum_posts fp WHERE fp.thread_id = ft.id) as reply_count
FROM `forum_threads` `ft`
JOIN `users` `u` ON `u`.`id` = `ft`.`user_id`
ORDER BY (SELECT COUNT(*) FROM forum_posts fp WHERE fp.thread_id = ft.id) DESC
 LIMIT 5
ERROR - 2025-09-11 00:14:39 --> Query error: Unknown column 'ft.slug' in 'field list' - Invalid query: SELECT `ft`.`id`, `ft`.`title`, `ft`.`slug`, `ft`.`created_at`, `u`.`nama_lengkap` as `author_name`, `u`.`username`, (SELECT COUNT(*) FROM forum_posts fp WHERE fp.thread_id = ft.id) as reply_count
FROM `forum_threads` `ft`
JOIN `users` `u` ON `u`.`id` = `ft`.`user_id`
ORDER BY (SELECT COUNT(*) FROM forum_posts fp WHERE fp.thread_id = ft.id) DESC
 LIMIT 5
ERROR - 2025-09-11 00:20:01 --> Severity: error --> Exception: Call to undefined function timespan() C:\laragon\www\aset-academy\application\views\forum\index.php 71
ERROR - 2025-09-11 00:21:44 --> Severity: Compile Error --> Cannot redeclare Forum_model::create_thread() C:\laragon\www\aset-academy\application\models\Forum_model.php 206
ERROR - 2025-09-11 00:23:37 --> Query error: Unknown column 'u.avatar' in 'field list' - Invalid query: SELECT `fp`.*, `u`.`nama_lengkap`, `u`.`username`, `u`.`avatar`
FROM `forum_posts` `fp`
JOIN `users` `u` ON `u`.`id` = `fp`.`user_id`
WHERE `fp`.`thread_id` = '2'
AND `fp`.`parent_id` = 0
ORDER BY `fp`.`created_at` DESC
 LIMIT 2
ERROR - 2025-09-11 00:25:24 --> Severity: Warning --> Undefined property: stdClass::$is_solved C:\laragon\www\aset-academy\application\views\forum\category_view.php 43
ERROR - 2025-09-11 00:25:24 --> Severity: Warning --> Undefined property: stdClass::$is_solved C:\laragon\www\aset-academy\application\views\forum\category_view.php 44
ERROR - 2025-09-11 00:28:47 --> Severity: error --> Exception: Too few arguments to function Forum::thread(), 0 passed in C:\laragon\www\aset-academy\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\aset-academy\application\controllers\Forum.php 68
ERROR - 2025-09-11 00:29:32 --> 404 Page Not Found: 
ERROR - 2025-09-11 00:29:39 --> 404 Page Not Found: 
ERROR - 2025-09-11 00:30:32 --> 404 Page Not Found: 
ERROR - 2025-09-11 00:30:38 --> 404 Page Not Found: 
ERROR - 2025-09-11 00:32:53 --> 404 Page Not Found: 
ERROR - 2025-09-11 00:35:35 --> Query error: Unknown column 'u.avatar' in 'field list' - Invalid query: SELECT `fp`.*, `u`.`nama_lengkap`, `u`.`username`, `u`.`avatar`
FROM `forum_posts` `fp`
JOIN `users` `u` ON `u`.`id` = `fp`.`user_id`
WHERE `fp`.`thread_id` = '2'
AND `fp`.`parent_id` = 0
ORDER BY `fp`.`created_at` ASC
 LIMIT 10
ERROR - 2025-09-11 00:37:10 --> Query error: Unknown column 'item_id' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `forum_likes`
WHERE `item_id` = '2'
AND `item_type` = 'thread'
ERROR - 2025-09-11 05:23:12 --> 404 Page Not Found: Forum/toggle_pin
ERROR - 2025-09-11 05:31:55 --> 404 Page Not Found: 
ERROR - 2025-09-11 05:32:06 --> 404 Page Not Found: 
ERROR - 2025-09-11 05:32:34 --> 404 Page Not Found: 
ERROR - 2025-09-11 05:34:10 --> 404 Page Not Found: 
ERROR - 2025-09-11 05:34:11 --> 404 Page Not Found: 
ERROR - 2025-09-11 05:37:52 --> 404 Page Not Found: Uploads/aws_s3_guide.pdf
ERROR - 2025-09-11 05:38:22 --> 404 Page Not Found: Assets/images
ERROR - 2025-09-11 05:38:22 --> 404 Page Not Found: Assets/images
ERROR - 2025-09-11 05:48:23 --> 404 Page Not Found: Assets/images
ERROR - 2025-09-11 05:48:23 --> 404 Page Not Found: Assets/images
