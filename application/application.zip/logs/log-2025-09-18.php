<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-18 03:54:40 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\aset-academy\application\views\student\mobile\forum_create.php 31
ERROR - 2025-09-18 04:07:57 --> 404 Page Not Found: Auth/mobile_login
ERROR - 2025-09-18 04:07:58 --> 404 Page Not Found: Auth/mobile_login
ERROR - 2025-09-18 04:08:12 --> 404 Page Not Found: Auth/mobile_login
ERROR - 2025-09-18 04:08:13 --> 404 Page Not Found: Auth/mobile_login
ERROR - 2025-09-18 04:08:18 --> 404 Page Not Found: Auth/mobile_login
ERROR - 2025-09-18 04:08:30 --> 404 Page Not Found: Auth/mobile_login
ERROR - 2025-09-18 04:22:23 --> 404 Page Not Found: Register/index
ERROR - 2025-09-18 04:56:39 --> Severity: Warning --> Undefined property: stdClass::$rating C:\laragon\www\aset-academy\application\views\home\index.php 92
ERROR - 2025-09-18 04:56:39 --> Severity: Warning --> Undefined property: stdClass::$total_reviews C:\laragon\www\aset-academy\application\views\home\index.php 92
ERROR - 2025-09-18 04:56:39 --> Severity: Warning --> Undefined property: stdClass::$rating C:\laragon\www\aset-academy\application\views\home\index.php 92
ERROR - 2025-09-18 04:56:39 --> Severity: Warning --> Undefined property: stdClass::$total_reviews C:\laragon\www\aset-academy\application\views\home\index.php 92
ERROR - 2025-09-18 04:56:39 --> Severity: Warning --> Undefined property: stdClass::$rating C:\laragon\www\aset-academy\application\views\home\index.php 92
ERROR - 2025-09-18 04:56:39 --> Severity: Warning --> Undefined property: stdClass::$total_reviews C:\laragon\www\aset-academy\application\views\home\index.php 92
ERROR - 2025-09-18 04:56:40 --> 404 Page Not Found: Assets/uploads
ERROR - 2025-09-18 04:56:40 --> 404 Page Not Found: Assets/uploads
ERROR - 2025-09-18 05:08:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Testimoni_model C:\laragon\www\aset-academy\system\core\Loader.php 350
ERROR - 2025-09-18 05:09:53 --> Severity: Warning --> Undefined property: Home::$kelas_programming_model C:\laragon\www\aset-academy\application\controllers\Home.php 162
ERROR - 2025-09-18 05:09:53 --> Severity: error --> Exception: Call to a member function get_kelas_by_id() on null C:\laragon\www\aset-academy\application\controllers\Home.php 162
ERROR - 2025-09-18 05:10:38 --> Query error: Unknown column 'class_id' in 'where clause' - Invalid query: SELECT *
FROM `testimonials`
WHERE `class_id` = '1'
 LIMIT 3
ERROR - 2025-09-18 05:12:39 --> Query error: Unknown column 'kelas_id' in 'where clause' - Invalid query: SELECT AVG(`rating`) AS `rating`
FROM `testimonials`
WHERE `kelas_id` = '1'
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$id_kelas C:\laragon\www\aset-academy\application\controllers\Home.php 171
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$deskripsi_singkat C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 10
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$foto C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 68
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 69
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 72
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$jabatan C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 73
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$bio C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 74
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$diskon C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 86
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$diskon C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 94
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$foto C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 194
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 195
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 198
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$pekerjaan C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 199
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$testimoni C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 207
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$foto C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 194
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 195
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 198
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$pekerjaan C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 199
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$testimoni C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 207
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$foto C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 194
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 195
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 198
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$pekerjaan C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 199
ERROR - 2025-09-18 05:13:46 --> Severity: Warning --> Undefined property: stdClass::$testimoni C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 207
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$id_kelas C:\laragon\www\aset-academy\application\controllers\Home.php 176
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$foto C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 68
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 69
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 72
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$jabatan C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 73
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$bio C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 74
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$diskon C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 86
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$diskon C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 94
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$foto C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 194
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 195
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 198
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$pekerjaan C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 199
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$testimoni C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 207
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$foto C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 194
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 195
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 198
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$pekerjaan C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 199
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$testimoni C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 207
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$foto C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 194
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 195
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 198
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$pekerjaan C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 199
ERROR - 2025-09-18 05:14:34 --> Severity: Warning --> Undefined property: stdClass::$testimoni C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 207
ERROR - 2025-09-18 05:15:14 --> Severity: Warning --> Undefined property: stdClass::$mentor_id C:\laragon\www\aset-academy\application\controllers\Home.php 173
ERROR - 2025-09-18 05:15:14 --> Severity: Warning --> Undefined property: stdClass::$id_kelas C:\laragon\www\aset-academy\application\controllers\Home.php 176
ERROR - 2025-09-18 05:15:14 --> Severity: Warning --> Undefined property: stdClass::$diskon C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 86
ERROR - 2025-09-18 05:15:14 --> Severity: Warning --> Undefined property: stdClass::$diskon C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 94
ERROR - 2025-09-18 05:15:14 --> Severity: Warning --> Undefined property: stdClass::$foto C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 194
ERROR - 2025-09-18 05:15:14 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 195
ERROR - 2025-09-18 05:15:14 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 198
ERROR - 2025-09-18 05:15:14 --> Severity: Warning --> Undefined property: stdClass::$pekerjaan C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 199
ERROR - 2025-09-18 05:15:14 --> Severity: Warning --> Undefined property: stdClass::$testimoni C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 207
ERROR - 2025-09-18 05:15:14 --> Severity: Warning --> Undefined property: stdClass::$foto C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 194
ERROR - 2025-09-18 05:15:14 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 195
ERROR - 2025-09-18 05:15:14 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 198
ERROR - 2025-09-18 05:15:14 --> Severity: Warning --> Undefined property: stdClass::$pekerjaan C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 199
ERROR - 2025-09-18 05:15:14 --> Severity: Warning --> Undefined property: stdClass::$testimoni C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 207
ERROR - 2025-09-18 05:15:14 --> Severity: Warning --> Undefined property: stdClass::$foto C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 194
ERROR - 2025-09-18 05:15:14 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 195
ERROR - 2025-09-18 05:15:14 --> Severity: Warning --> Undefined property: stdClass::$nama C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 198
ERROR - 2025-09-18 05:15:14 --> Severity: Warning --> Undefined property: stdClass::$pekerjaan C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 199
ERROR - 2025-09-18 05:15:14 --> Severity: Warning --> Undefined property: stdClass::$testimoni C:\laragon\www\aset-academy\application\views\home\premium_class_view.php 207
ERROR - 2025-09-18 05:16:01 --> Severity: Warning --> Undefined property: stdClass::$mentor_id C:\laragon\www\aset-academy\application\controllers\Home.php 173
ERROR - 2025-09-18 05:16:01 --> Severity: Warning --> Undefined property: stdClass::$id_kelas C:\laragon\www\aset-academy\application\controllers\Home.php 176
ERROR - 2025-09-18 05:16:01 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 05:16:01 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 05:16:41 --> Severity: Warning --> Undefined property: stdClass::$id_kelas C:\laragon\www\aset-academy\application\controllers\Home.php 184
ERROR - 2025-09-18 05:16:41 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 05:16:41 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 05:17:05 --> Severity: Warning --> Undefined property: stdClass::$id_kelas C:\laragon\www\aset-academy\application\controllers\Home.php 184
ERROR - 2025-09-18 05:17:05 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 05:17:05 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 05:17:16 --> Severity: Warning --> Undefined property: stdClass::$id_kelas C:\laragon\www\aset-academy\application\controllers\Home.php 184
ERROR - 2025-09-18 05:17:17 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 05:17:17 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 05:18:08 --> Severity: Warning --> Undefined property: stdClass::$id_kelas C:\laragon\www\aset-academy\application\controllers\Home.php 184
ERROR - 2025-09-18 05:18:08 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 05:18:08 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 05:19:29 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 05:19:29 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 05:20:22 --> Query error: Unknown column 'is_featured' in 'where clause' - Invalid query: SELECT *
FROM `testimonials`
WHERE `is_featured` = 1
 LIMIT 5
ERROR - 2025-09-18 05:23:10 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 05:23:10 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 06:43:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '?) 'siswa'' at line 4 - Invalid query: SELECT *
FROM `users`
WHERE `username` = 'siswa'
OR `id` IN (SELECT id FROM siswa WHERE nis = ?) 'siswa'
ERROR - 2025-09-18 06:48:22 --> 404 Page Not Found: Assets/manifest.json
ERROR - 2025-09-18 06:53:44 --> 404 Page Not Found: Assets/manifest.json
ERROR - 2025-09-18 10:45:51 --> 404 Page Not Found: Workshop/index
ERROR - 2025-09-18 10:45:58 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:45:58 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:45:58 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:45:58 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:45:58 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:45:58 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:46:16 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:46:16 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:46:16 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:46:16 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:46:16 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:46:16 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:49:43 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:49:43 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:49:43 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:49:43 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:49:43 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:49:43 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:50:53 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:50:53 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:50:53 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:50:53 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:50:53 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:50:53 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:51:40 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:51:40 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:51:40 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:51:40 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:51:40 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 10:51:40 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:14:22 --> Severity: error --> Exception: Call to undefined method CI_Input::is_mobile() C:\laragon\www\aset-academy\application\controllers\Auth.php 64
ERROR - 2025-09-18 11:15:50 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:15:50 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:15:50 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:15:50 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:15:50 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:15:50 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:15:50 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:15:50 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:15:50 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:15:50 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:15:50 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:15:50 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:18:36 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:18:36 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:18:36 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:18:36 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:18:36 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:18:36 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:18:36 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:18:36 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:18:36 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:18:36 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:18:36 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:18:36 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:18:37 --> 404 Page Not Found: admin/Login/index
ERROR - 2025-09-18 11:18:59 --> 404 Page Not Found: admin/Admin_workshop_guests/index
ERROR - 2025-09-18 11:19:52 --> 404 Page Not Found: admin/Admin_workshop_guests/index
ERROR - 2025-09-18 11:19:55 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:19:55 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:19:55 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:19:55 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:19:55 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:19:55 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:19:55 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:19:55 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:19:55 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:19:55 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:19:55 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:19:55 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:19:57 --> 404 Page Not Found: admin/Login/index
ERROR - 2025-09-18 11:22:00 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:22:00 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:22:00 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:22:00 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:22:00 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:22:00 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:22:00 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:22:00 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:22:00 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:22:00 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:22:00 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:22:00 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 11:22:02 --> 404 Page Not Found: admin/Login/index
ERROR - 2025-09-18 11:23:12 --> 404 Page Not Found: admin/Login/index
ERROR - 2025-09-18 11:29:05 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 11:29:06 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 11:30:20 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 11:30:20 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 11:30:28 --> Query error: Unknown column 'workshop_guests.district_id' in 'on clause' - Invalid query: SELECT `workshop_guests`.*, `reg_provinces`.`name` as `province_name`, `reg_regencies`.`name` as `regency_name`, `reg_districts`.`name` as `district_name`
FROM `workshop_guests`
LEFT JOIN `reg_provinces` ON `reg_provinces`.`id` = `workshop_guests`.`province_id`
LEFT JOIN `reg_regencies` ON `reg_regencies`.`id` = `workshop_guests`.`regency_id`
LEFT JOIN `reg_districts` ON `reg_districts`.`id` = `workshop_guests`.`district_id`
WHERE `workshop_guests`.`workshop_id` = '1'
ORDER BY `workshop_guests`.`registered_at` DESC
ERROR - 2025-09-18 11:35:42 --> Query error: Unknown column 'workshop_guests.district_id' in 'on clause' - Invalid query: SELECT `workshop_guests`.*, `reg_provinces`.`name` as `province_name`, `reg_regencies`.`name` as `regency_name`, `reg_districts`.`name` as `district_name`
FROM `workshop_guests`
LEFT JOIN `reg_provinces` ON `reg_provinces`.`id` = `workshop_guests`.`province_id`
LEFT JOIN `reg_regencies` ON `reg_regencies`.`id` = `workshop_guests`.`regency_id`
LEFT JOIN `reg_districts` ON `reg_districts`.`id` = `workshop_guests`.`district_id`
WHERE `workshop_guests`.`workshop_id` = '1'
ORDER BY `workshop_guests`.`registered_at` DESC
ERROR - 2025-09-18 11:38:02 --> Query error: Unknown column 'workshop_guests.district_id' in 'on clause' - Invalid query: SELECT `workshop_guests`.*, `reg_provinces`.`name` as `province_name`, `reg_regencies`.`name` as `regency_name`, `reg_districts`.`name` as `district_name`
FROM `workshop_guests`
LEFT JOIN `reg_provinces` ON `reg_provinces`.`id` = `workshop_guests`.`province_id`
LEFT JOIN `reg_regencies` ON `reg_regencies`.`id` = `workshop_guests`.`regency_id`
LEFT JOIN `reg_districts` ON `reg_districts`.`id` = `workshop_guests`.`district_id`
WHERE `workshop_guests`.`workshop_id` = '1'
ORDER BY `workshop_guests`.`registered_at` DESC
ERROR - 2025-09-18 11:39:58 --> Query error: Unknown column 'workshop_guests.district_id' in 'on clause' - Invalid query: SELECT `workshop_guests`.*, `reg_provinces`.`name` as `province_name`, `reg_regencies`.`name` as `regency_name`, `reg_districts`.`name` as `district_name`
FROM `workshop_guests`
LEFT JOIN `reg_provinces` ON `reg_provinces`.`id` = `workshop_guests`.`province_id`
LEFT JOIN `reg_regencies` ON `reg_regencies`.`id` = `workshop_guests`.`regency_id`
LEFT JOIN `reg_districts` ON `reg_districts`.`id` = `workshop_guests`.`district_id`
WHERE `workshop_guests`.`workshop_id` = '1'
ORDER BY `workshop_guests`.`registered_at` DESC
ERROR - 2025-09-18 11:44:09 --> Query error: Unknown column 'workshop_guests.district_id' in 'on clause' - Invalid query: SELECT `workshop_guests`.*, `reg_provinces`.`name` as `province_name`, `reg_regencies`.`name` as `regency_name`, `reg_districts`.`name` as `district_name`
FROM `workshop_guests`
LEFT JOIN `reg_provinces` ON `reg_provinces`.`id` = `workshop_guests`.`province_id`
LEFT JOIN `reg_regencies` ON `reg_regencies`.`id` = `workshop_guests`.`regency_id`
LEFT JOIN `reg_districts` ON `reg_districts`.`id` = `workshop_guests`.`district_id`
WHERE `workshop_guests`.`workshop_id` = '1'
ORDER BY `workshop_guests`.`registered_at` DESC
ERROR - 2025-09-18 11:47:15 --> Query error: Unknown column 'workshop_guests.district_id' in 'on clause' - Invalid query: SELECT `workshop_guests`.*, `reg_provinces`.`name` as `province_name`, `reg_regencies`.`name` as `regency_name`, `reg_districts`.`name` as `district_name`
FROM `workshop_guests`
LEFT JOIN `reg_provinces` ON `reg_provinces`.`id` = `workshop_guests`.`province_id`
LEFT JOIN `reg_regencies` ON `reg_regencies`.`id` = `workshop_guests`.`regency_id`
LEFT JOIN `reg_districts` ON `reg_districts`.`id` = `workshop_guests`.`district_id`
WHERE `workshop_guests`.`workshop_id` = '1'
ORDER BY `workshop_guests`.`registered_at` DESC
ERROR - 2025-09-18 13:28:31 --> Query error: Unknown column 'workshop_guests.district_id' in 'on clause' - Invalid query: SELECT `workshop_guests`.*, `reg_provinces`.`name` as `province_name`, `reg_regencies`.`name` as `regency_name`, `reg_districts`.`name` as `district_name`
FROM `workshop_guests`
LEFT JOIN `reg_provinces` ON `reg_provinces`.`id` = `workshop_guests`.`province_id`
LEFT JOIN `reg_regencies` ON `reg_regencies`.`id` = `workshop_guests`.`regency_id`
LEFT JOIN `reg_districts` ON `reg_districts`.`id` = `workshop_guests`.`district_id`
WHERE `workshop_guests`.`workshop_id` = '1'
ORDER BY `workshop_guests`.`registered_at` DESC
ERROR - 2025-09-18 13:52:37 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:37 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:37 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:37 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:37 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:37 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:37 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:37 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:37 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:37 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:37 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:37 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:38 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:38 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:38 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:38 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:38 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:38 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:38 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:38 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:38 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:38 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:38 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 13:52:38 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:26:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:26:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:26:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:26:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:26:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:26:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:26:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:26:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:26:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:26:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:26:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:26:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:27:01 --> 404 Page Not Found: Uploads/payments
ERROR - 2025-09-18 14:27:08 --> 404 Page Not Found: Uploads/payments
ERROR - 2025-09-18 14:37:24 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 14:37:24 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 14:37:53 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 14:37:53 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 14:37:59 --> Severity: Warning --> Undefined property: CI_Loader::$Free_class_model C:\laragon\www\aset-academy\application\views\home\free_class_view.php 313
ERROR - 2025-09-18 14:37:59 --> Severity: error --> Exception: Call to a member function get_recent_free_classes() on null C:\laragon\www\aset-academy\application\views\home\free_class_view.php 313
ERROR - 2025-09-18 14:40:16 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:40:16 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:40:16 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:40:16 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:40:16 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:40:16 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:40:44 --> 404 Page Not Found: admin/Dashboard/index
ERROR - 2025-09-18 14:42:33 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:42:33 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:42:33 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:42:33 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:42:33 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:42:33 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:42:34 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:42:34 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:42:34 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:42:34 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:42:34 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:42:34 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:47:27 --> Query error: Table 'academy_lite.pembayaran' doesn't exist - Invalid query: SELECT SUM(`jumlah_pembayaran`) AS `jumlah_pembayaran`
FROM `pembayaran`
ERROR - 2025-09-18 14:48:03 --> Query error: Table 'academy_lite.student_enrollment' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows` FROM `student_enrollment`
ERROR - 2025-09-18 14:51:39 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:39 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:39 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:39 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:39 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:39 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:39 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:39 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:39 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:39 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:39 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:39 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 14:51:41 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:12:05 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:12:05 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:12:05 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:12:05 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:12:05 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:12:05 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:12:07 --> 404 Page Not Found: 
ERROR - 2025-09-18 16:12:58 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:12:58 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:12:58 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:12:58 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:12:59 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:12:59 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:14:10 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:14:10 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:14:10 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:14:10 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:14:10 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:14:10 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:14:12 --> 404 Page Not Found: 
ERROR - 2025-09-18 16:20:59 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:20:59 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:20:59 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:20:59 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:20:59 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:20:59 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:22:39 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:22:39 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:22:39 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:22:39 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:22:39 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:22:39 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:25:18 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:25:18 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:25:18 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:25:18 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:28:28 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:28:28 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:28:36 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:28:36 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:28:43 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:28:43 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:28:43 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:28:43 --> 404 Page Not Found: Uploads/workshops
ERROR - 2025-09-18 16:33:34 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 16:33:34 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 16:37:05 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 16:37:05 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 16:39:52 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 16:39:52 --> 404 Page Not Found: Assets/img
ERROR - 2025-09-18 16:42:08 --> 404 Page Not Found: Auth/login
ERROR - 2025-09-18 16:42:17 --> 404 Page Not Found: Auth/login
ERROR - 2025-09-18 16:42:43 --> 404 Page Not Found: Auth/login
ERROR - 2025-09-18 16:43:53 --> 404 Page Not Found: Auth/login
ERROR - 2025-09-18 16:43:58 --> 404 Page Not Found: Auth/login
ERROR - 2025-09-18 16:45:32 --> Invalid encrypted Workshop ID: 4
ERROR - 2025-09-18 16:45:32 --> 404 Page Not Found: 
