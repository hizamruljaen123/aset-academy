ERROR - 2025-09-10 09:22:08 --> The upload path does not appear to be valid.
ERROR - 2025-09-10 09:31:15 --> Severity: error --> Exception: syntax error, unexpected token "endif", expecting end of file C:\laragon\www\aset-academy\application\views\student\premium.php 81
ERROR - 2025-09-10 09:46:29 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 09:46:29 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 09:46:32 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 09:46:32 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 09:46:44 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 09:46:44 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 09:50:51 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 09:50:52 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 09:51:00 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 09:51:00 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 09:55:28 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 09:55:29 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 10:01:37 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 10:01:37 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 10:03:32 --> 404 Page Not Found: Teacher/assignments
ERROR - 2025-09-10 10:05:14 --> 404 Page Not Found: Teacher/Assignments
ERROR - 2025-09-10 10:05:19 --> 404 Page Not Found: Teacher/Assignments
ERROR - 2025-09-10 10:09:46 --> 404 Page Not Found: Teacher/assignments
ERROR - 2025-09-10 10:10:39 --> 404 Page Not Found: Teacher/Assignments
ERROR - 2025-09-10 10:12:03 --> 404 Page Not Found: Teacher/Assignments
ERROR - 2025-09-10 10:12:41 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\laragon\www\aset-academy\system\core\URI.php 102
ERROR - 2025-09-10 10:12:41 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\laragon\www\aset-academy\system\core\Router.php 128
ERROR - 2025-09-10 10:12:41 --> Not Found: Tools/check_teacher_user
ERROR - 2025-09-10 10:12:46 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\laragon\www\aset-academy\system\core\URI.php 102
ERROR - 2025-09-10 10:12:46 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\laragon\www\aset-academy\system\core\Router.php 128
ERROR - 2025-09-10 10:12:46 --> Not Found: Tools/check_error_logs
ERROR - 2025-09-10 10:14:06 --> 404 Page Not Found: Teacher/Assignments
ERROR - 2025-09-10 10:15:24 --> 404 Page Not Found: Teacher/Assignments
ERROR - 2025-09-10 10:24:18 --> 404 Page Not Found: Teacher/Assignments
ERROR - 2025-09-10 10:37:26 --> 404 Page Not Found: Teacher/Assignments
ERROR - 2025-09-10 10:38:05 --> 404 Page Not Found: Teacher/assignments
ERROR - 2025-09-10 12:09:34 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 12:09:34 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 12:09:36 --> 404 Page Not Found: Teacher/Assignments
ERROR - 2025-09-10 12:10:51 --> 404 Page Not Found: Teacher/Assignments
ERROR - 2025-09-10 12:11:16 --> 404 Page Not Found: Teacher/Assignments
ERROR - 2025-09-10 12:12:44 --> 404 Page Not Found: Teacher/Assignments
ERROR - 2025-09-10 12:22:55 --> Severity: Warning --> Undefined property: stdClass::$nama_kelas C:\laragon\www\aset-academy\application\views\teacher\assignments\index.php 38
ERROR - 2025-09-10 12:22:55 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\aset-academy\application\views\teacher\assignments\index.php 38
ERROR - 2025-09-10 12:24:07 --> Severity: Warning --> Undefined property: stdClass::$nama_kelas C:\laragon\www\aset-academy\application\views\teacher\assignments\index.php 38
ERROR - 2025-09-10 12:24:07 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\aset-academy\application\views\teacher\assignments\index.php 38
ERROR - 2025-09-10 12:24:08 --> Query error: Table 'academy_lite.kelas_premium' doesn't exist - Invalid query: SELECT *
FROM `kelas_premium`
WHERE `id` = '2'
ERROR - 2025-09-10 12:24:48 --> Query error: Table 'academy_lite.kelas_premium' doesn't exist - Invalid query: SELECT *
FROM `kelas_premium`
WHERE `id` = '1'
ERROR - 2025-09-10 12:28:32 --> Query error: Table 'academy_lite.assignments' doesn't exist - Invalid query: SELECT *
FROM `assignments`
WHERE `class_id` = '1'
AND `class_type` = 'premium'
ERROR - 2025-09-10 12:29:50 --> Query error: Table 'academy_lite.assignments' doesn't exist - Invalid query: SELECT *
FROM `assignments`
WHERE `class_id` = '1'
AND `class_type` = 'gratis'
ERROR - 2025-09-10 12:31:51 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 12:31:51 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 12:31:55 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 12:31:55 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 23:12:27 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 23:12:27 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 23:12:37 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 23:12:37 --> 404 Page Not Found: Uploads/siswa
ERROR - 2025-09-10 23:13:47 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\aset-academy\application\views\dashboard\index.php 88
ERROR - 2025-09-10 23:14:20 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\aset-academy\application\views\dashboard\index.php 88
ERROR - 2025-09-10 23:14:23 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\aset-academy\application\views\dashboard\index.php 88
ERROR - 2025-09-10 23:14:37 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\laragon\www\aset-academy\application\views\dashboard\index.php 88
ERROR - 2025-09-10 23:16:09 --> 404 Page Not Found: Assets/images
ERROR - 2025-09-10 23:16:09 --> 404 Page Not Found: Assets/images
ERROR - 2025-09-10 23:22:26 --> Severity: error --> Exception: Call to undefined method Assignment_model::get_submissions() C:\laragon\www\aset-academy\application\controllers\admin\Assignments.php 33
ERROR - 2025-09-10 23:24:11 --> Severity: Warning --> Undefined property: stdClass::$class_name C:\laragon\www\aset-academy\application\views\admin\assignments\submissions.php 20
ERROR - 2025-09-10 23:24:11 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\aset-academy\application\views\admin\assignments\submissions.php 20
ERROR - 2025-09-10 23:24:11 --> Severity: Warning --> Undefined property: stdClass::$teacher_name C:\laragon\www\aset-academy\application\views\admin\assignments\submissions.php 24
ERROR - 2025-09-10 23:24:11 --> Severity: 8192 --> htmlspecialchars(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\aset-academy\application\views\admin\assignments\submissions.php 24
ERROR - 2025-09-10 23:24:11 --> Severity: Warning --> Undefined property: stdClass::$file_path C:\laragon\www\aset-academy\application\views\admin\assignments\submissions.php 117
ERROR - 2025-09-10 23:25:16 --> Severity: Warning --> Undefined property: stdClass::$file_path C:\laragon\www\aset-academy\application\views\admin\assignments\submissions.php 117
ERROR - 2025-09-10 23:26:05 --> Query error: Unknown column 'ss.file_path' in 'field list' - Invalid query: SELECT `ss`.*, `u`.`nama_lengkap` as `student_name`, `u`.`email` as `student_email`, `ss`.`file_path` as `file_path`
FROM `student_submissions` `ss`
JOIN `users` `u` ON `ss`.`student_id` = `u`.`id`
WHERE `ss`.`assignment_id` = '2'
ORDER BY `ss`.`submitted_at` DESC
ERROR - 2025-09-10 23:26:14 --> Query error: Unknown column 'ss.file_path' in 'field list' - Invalid query: SELECT `ss`.*, `u`.`nama_lengkap` as `student_name`, `u`.`email` as `student_email`, `ss`.`file_path` as `file_path`
FROM `student_submissions` `ss`
JOIN `users` `u` ON `ss`.`student_id` = `u`.`id`
WHERE `ss`.`assignment_id` = '2'
ORDER BY `ss`.`submitted_at` DESC
ERROR - 2025-09-10 23:27:42 --> Query error: Unknown column 'ss.file_name' in 'field list' - Invalid query: SELECT `ss`.*, `u`.`nama_lengkap` as `student_name`, `u`.`email` as `student_email`, `ss`.`file_name` as `file_path`
FROM `student_submissions` `ss`
JOIN `users` `u` ON `ss`.`student_id` = `u`.`id`
WHERE `ss`.`assignment_id` = '2'
ORDER BY `ss`.`submitted_at` DESC
ERROR - 2025-09-10 23:30:07 --> 404 Page Not Found: Assets/images
ERROR - 2025-09-10 23:30:07 --> 404 Page Not Found: Assets/images
ERROR - 2025-09-10 23:35:36 --> 404 Page Not Found: Uploads/payment_proofs
ERROR - 2025-09-10 23:40:56 --> Severity: Warning --> Undefined property: stdClass::$user_email C:\laragon\www\aset-academy\application\views\admin\payment\verify.php 37
ERROR - 2025-09-10 23:41:13 --> Severity: Warning --> Undefined property: stdClass::$user_email C:\laragon\www\aset-academy\application\views\admin\payment\verify.php 37
ERROR - 2025-09-10 23:42:17 --> Severity: Warning --> Undefined property: stdClass::$user_email C:\laragon\www\aset-academy\application\views\admin\payment\verify.php 37
ERROR - 2025-09-10 23:55:26 --> 404 Page Not Found: Assets/images
ERROR - 2025-09-10 23:55:26 --> 404 Page Not Found: Assets/images
ERROR - 2025-09-10 23:59:50 --> Query error: Unknown column 'ft.slug' in 'field list' - Invalid query: SELECT `ft`.`id`, `ft`.`title`, `ft`.`slug`, `ft`.`created_at`, `u`.`nama_lengkap` as `author_name`, `u`.`username`, (SELECT COUNT(*) FROM forum_posts fp WHERE fp.thread_id = ft.id) as reply_count
FROM `forum_threads` `ft`
JOIN `users` `u` ON `u`.`id` = `ft`.`user_id`
ORDER BY (SELECT COUNT(*) FROM forum_posts fp WHERE fp.thread_id = ft.id) DESC
 LIMIT 5
